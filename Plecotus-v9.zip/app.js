/* Browser-only review UI. No recording or CSV is transmitted. */
(() => {
  'use strict';
  const C = window.BatReviewCore;
  const A = window.BatClassification;
  const N = window.BatSpeciesNames;
  const P = window.BatReviewPlan;
  const V = window.BatActivityChart;
  const B = window.BatBulkConfirmation;
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const checked = status => ['confirmed','corrected','uncertain','noise'].includes(status);
  const state = {source:null,data:null,parsed:null,rowById:new Map(),guided:[],speciesLabels:[],labelOptions:[],reviews:{},drafts:{},selections:{},reviewer:'',minimal:true,minimalStarted:false,resultsView:false,activityChartMode:'pie',tab:'pending',species:'',search:'',sort:'guided',selected:null,page:0,autoNext:true,undo:[],encodingWarning:'',policy:A.normalizePolicy(),classification:null,reviewPlan:null};
  const STORAGE = 'plecotus.project.v1';
  const PREFERENCES = 'plecotus.preferences.v1';
  let reviewerPreferenceSet=false;
  const PAGE_SIZE = 50;
  let toastTimer, saveTimer, pendingOpen;
  const num = n => n == null ? '—' : Number(n).toLocaleString('fr-BE', {maximumFractionDigits:3});
  const ratio = n => n == null ? '—' : (n * 100).toLocaleString('fr-BE', {minimumFractionDigits:1, maximumFractionDigits:1}) + ' %';
  // Translate interface outcomes while keeping source cells and species labels intact.
  const outcomeLabel = label => ({'Noise':'Bruit','No ID':'Sans identification (NoID)','NoID':'Sans identification (NoID)','Unclassified':'Non classé','Unidentified bat':'Chauve-souris non identifiée','Pending classification':'Classification en attente','Uncertain / unresolved':'Identification incertaine / non résolue'}[label] || label);
  const autoLabel = row => row.kind==='noise'?'Bruit (Noise)':row.kind==='noid'?'Sans identification (NoID)':row.kind==='unclassified'?'Non classé':row.autoId;
  const review = row => state.reviews[row.id] || {status:row.manualId ? 'imported' : 'unreviewed',label:row.manualId || '',notes:'',reviewer:'',timestamp:''};
  const assignment = row => state.classification?.byId.get(row.id);
  const statusLabel = result => result?.origin==='pending' && result.role==='waiting' ? 'En attente des contrôles' : ({'inferred':result?.method==='proportion'?'Répartition au prorata':'Auto-ID validé','inferred-noise':'Bruit au prorata','ignored-noise':'Bruit ignoré','inferred-uncertain':'Incertitude au prorata','needs-review':'À vérifier','imported':'Manuel importé','draft':'Brouillon','confirmed':'Confirmé','corrected':'Attribué manuellement','uncertain':'Incertain','noise':'Bruit vérifié'}[result?.status] || 'À vérifier');
  function recalculate() {
    if(!state.data) return;
    state.classification=A.classify(state.data,state.reviews,state.policy,state.drafts,state.selections);
    state.reviewPlan=P.summarize(state.classification);
    const groupOrder=new Map(state.classification.groups.map((g,i)=>[g.key,i]));
    const priority=r=>{const a=assignment(r);return a.origin==='manual'?5:a.origin==='inferred'?4:a.role==='waiting'?3:a.role==='reference'?0:a.role==='audit'?1:2;};
    state.guided=[...state.data.rows].sort((a,b)=>groupOrder.get(assignment(a).groupKey)-groupOrder.get(assignment(b).groupKey)||priority(a)-priority(b)||assignment(a).rank-assignment(b).rank||a.index-b.index);
  }
  function toast(message) { $('toast').textContent=message; $('toast').hidden=false; clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('toast').hidden=true,5000); }
  function renderReviewerPreference() { $('reviewer-settings').textContent=state.reviewer?'Vérificateur : '+state.reviewer:'Définir le vérificateur'; }
  function setReviewerDefault(value) {
    state.reviewer=String(value || '').trim();reviewerPreferenceSet=true;renderReviewerPreference();
    try{localStorage.setItem(PREFERENCES,JSON.stringify({reviewer:state.reviewer}));return true;}
    catch{toast('Le nom est retenu pour cette session. Le navigateur ne permet pas de mémoriser cette préférence ; conservez votre projet JSON.');return false;}
  }
  try{const preferences=JSON.parse(localStorage.getItem(PREFERENCES) || 'null');if(preferences && typeof preferences.reviewer==='string'){state.reviewer=preferences.reviewer;reviewerPreferenceSet=true;}}catch{}
  renderReviewerPreference();
  function setViewMode(minimal) {
    state.minimal=minimal;state.resultsView=false;
    if(minimal)state.minimalStarted=false;
    document.body.classList.toggle('minimal-mode',minimal);
    document.body.classList.remove('results-view');
    $('view-mode').textContent=minimal?'Vue complète':'Mode minimaliste';
    $('view-mode').setAttribute('aria-pressed',String(!minimal));
    if(state.data){
      if(!minimal){const rows=visibleRows();if(!rows.some(r=>r.id===state.selected))state.selected=rows[0]?.id || null;}
      render();
    }
  }
  function project() { return {format:'plecotus-review',version:3,source:state.source,reviews:state.reviews,drafts:state.drafts,selections:state.selections,reviewer:state.reviewer,policy:state.policy,encodingWarning:state.encodingWarning,exportedAt:new Date().toISOString()}; }
  function persist() {
    if (!state.source) return;
    try { localStorage.setItem(STORAGE,JSON.stringify(project())); $('save-status').textContent='Enregistré dans ce navigateur'; }
    catch { $('save-status').textContent='Enregistrer une sauvegarde du projet'; toast('Le stockage du navigateur est indisponible ou plein. Utilisez « Enregistrer le projet » pour conserver vos décisions.'); }
  }
  function schedulePersist() { clearTimeout(saveTimer); $('save-status').textContent='Enregistrement du brouillon…'; saveTimer=setTimeout(()=>{recalculate();renderCounters();renderSummary();renderSpeciesWorkflow();renderQueue();renderMinimalOverview();renderReviewProgress();updateDetailClassification();persist();},350); }
  function download(name,body,type) {
    const url=URL.createObjectURL(new Blob([body],{type})); const a=document.createElement('a'); a.href=url; a.download=name; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  const baseName = () => (state.source?.name || 'id.csv').replace(/\.[^.]+$/,'');
  function saveProject() { if(!state.source) return; download(baseName()+'.plecotus.json',JSON.stringify(project(),null,2),'application/json'); toast('Sauvegarde téléchargée : elle contient le CSV, les décisions et les brouillons.'); }
  function requestOpen(callback) {
    if(state.source && (Object.keys(state.reviews).length || Object.keys(state.drafts).length)) {pendingOpen=callback;$('replace-dialog').showModal();} else callback();
  }
  function acceptSource(source,extras={}) {
    if(!source || typeof source.text!=='string' || typeof source.name!=='string') throw new Error('Le projet ne contient aucun CSV source valide.');
    const parsed=C.parseCSV(source.text); const data=C.analyze(parsed.headers,parsed.records);data.headers=parsed.headers;
    if(parsed.headers.filter(h=>h.toUpperCase().replace(/[^A-Z0-9]/g,'')==='SEMIMANUALID').length>1)throw new Error('Plusieurs colonnes désignent SEMIMANUAL ID. Gardez une seule colonne avant l’import.');
    const policy=A.normalizePolicy(extras.version && extras.version<3 ? extras.policy || {version:1} : extras.policy || state.policy);
    if(!data.rows.length) throw new Error('Ce CSV ne contient aucun contact.');
    if(data.columns.file < 0) throw new Error('La colonne IN FILE (ou File) est introuvable. Importez un id.csv ou un export Kaleidoscope compatible.');
    const reviews={}; const drafts={}; const rowById=new Map(data.rows.map(r=>[r.id,r]));
    for(const [id,r] of Object.entries(extras.reviews || {})) {
      if(!rowById.has(id) || !r || !checked(r.status) || typeof r.label!=='string' || !r.label.trim()) throw new Error('Le projet contient une décision de vérification invalide.');
      const row=rowById.get(id);
      if(r.status==='confirmed' && (row.kind!=='species' || r.label.trim()!==row.autoId)) throw new Error('Une étiquette confirmée du projet ne correspond pas à la suggestion source.');
      if(r.status==='noise' && r.label!=='Noise') throw new Error('Une décision « Bruit » contient une étiquette incohérente.');
      reviews[id]={status:r.status,label:r.label,notes:String(r.notes || ''),reviewer:String(r.reviewer || ''),timestamp:String(r.timestamp || '')};
    }
    for(const [id,d] of Object.entries(extras.drafts || {})) if(rowById.has(id) && d && typeof d==='object') drafts[id]={status:['confirmed','corrected','uncertain','noise'].includes(d.status)?d.status:'',label:String(d.label || ''),notes:String(d.notes || ''),reviewer:String(d.reviewer || '')};
    const guided=[];
    const speciesLabels=[...new Set(data.rows.filter(r=>r.kind==='species').map(r=>r.autoId))].sort();
    const labelOptions=[...new Set([...speciesLabels,'Chauve-souris non identifiée','Myotis sp.','Plecotus sp.','Pipistrellus sp.','Groupe Nyctalus / Eptesicus / Vespertilio'])].sort();
    const selections=extras.version===3 && extras.selections && typeof extras.selections==='object' && !Array.isArray(extras.selections)?extras.selections:{};
    const reviewerDefault=reviewerPreferenceSet?state.reviewer:String(extras.reviewer || state.reviewer || '');
    Object.assign(state,{source,parsed,data,rowById,guided,speciesLabels,labelOptions,reviews,drafts,selections,policy,reviewer:reviewerDefault,minimalStarted:false,resultsView:false,encodingWarning:String(extras.encodingWarning || ''),tab:'pending',species:'',search:'',selected:null,page:0,undo:[]});
    document.body.classList.remove('results-view');
    if(reviewerDefault && !reviewerPreferenceSet)setReviewerDefault(reviewerDefault);
    renderReviewerPreference();
    recalculate();
    state.selected=visibleRows()[0]?.id || data.rows[0].id;
    $('search').value=''; $('sort').value=state.sort; $('welcome').hidden=true; $('workspace').hidden=false;
    ['save-project','export'].forEach(id=>$(id).disabled=false); render(); persist();
  }
  async function loadCSV(file) {
    if(!file) return;
    try {
      if(file.size>50*1024*1024) throw new Error('Cette version dans le navigateur accepte les CSV de moins de 50 Mo.');
      const bytes=new Uint8Array(await file.arrayBuffer()); let text,warning='';
      if(bytes[0]===255 && bytes[1]===254) text=new TextDecoder('utf-16le').decode(bytes);
      else if(bytes[0]===254 && bytes[1]===255) text=new TextDecoder('utf-16be').decode(bytes);
      else { try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{text=new TextDecoder('windows-1252').decode(bytes);warning='CSV décodé en Windows-1252. Les exports utilisent UTF-8 ; vérifiez les accents avant de rouvrir le fichier.';} }
      acceptSource({name:file.name,text},{encodingWarning:warning});
      toast(`${state.data.rows.length.toLocaleString('fr-BE')} contacts importés. Commencez par les vérifications obligatoires ; les attributions éligibles seront disponibles une fois ces contrôles validés.`);
    } catch(error) {toast(error.message);} finally {$('csv-file').value='';}
  }
  async function loadProject(file) {
    if(!file) return;
    try {
      if(file.size>75*1024*1024) throw new Error('Ce projet est trop volumineux pour cette première version.');
      let p;try{p=JSON.parse(await file.text());}catch{throw new Error('Le fichier de projet ne contient pas un JSON valide.');}
      if(!p || p.format!=='plecotus-review'||![1,2,3].includes(p.version)) throw new Error('Choisissez un fichier JSON de projet Plecotus version 1, 2 ou 3.');
      acceptSource(p.source,p);toast(p.version<3?'Projet ouvert : décisions conservées, ancienne règle prudente remplacée par la procédure par espèce.':'Projet ouvert avec ses décisions, ses sélections et ses règles.');
    }catch(error){toast(error.message);}finally{$('project-file').value='';}
  }
  function visibleRows() {
    if(!state.data) return [];
    if(state.minimal)return state.guided.filter(r=>assignment(r).requiresReview);
    const query=state.search.toLowerCase();
    return (state.sort==='source'?state.data.rows:state.guided).filter(r=>{
      const rev=review(r);const a=assignment(r);
      if(state.species && a.groupKey!==state.species) return false;
      if(query && ![r.file,r.folder,r.autoId,autoLabel(r),rev.label,outcomeLabel(rev.label),a?.label,outcomeLabel(a?.label),rev.notes,r.date,r.time,r.offset].join(' ').toLowerCase().includes(query)) return false;
      if(state.tab==='pending') return a.requiresReview;
      if(state.tab==='reviewed') return a.origin==='manual';
      if(state.tab==='anchors') return a.isAnchor;
      if(state.tab==='audits') return a.role==='audit';
      if(state.tab==='waiting') return a.role==='waiting' && a.origin==='pending';
      if(state.tab==='inferred') return a.origin==='inferred';
      if(state.tab==='noid') return ['noid','unclassified'].includes(r.kind);
      if(state.tab==='noise') return r.kind==='noise';
      return true;
    });
  }
  function render() {
    if(!state.data) return;
    recalculate();
    const rows=state.data.rows; const metrics=state.classification.metrics;
    $('dataset-name').textContent=state.source.name;
    $('dataset-caption').textContent=`${state.source.name} · ${rows.length.toLocaleString('fr-BE')} contacts · ${state.source.name==='example-id.csv'?'Données fictives de démonstration · ':''}${metrics.waiting} contacts en attente des contrôles de leur groupe`;
    renderCounters();
    renderSummary();
    renderSpeciesWorkflow();
    $('species-list').innerHTML=state.classification.groups.map(group=>`<button class="nav-button ${state.species===group.key?'active':''}" data-species="${esc(group.key)}"><b>${esc(outcomeLabel(group.autoId))}</b><span>${group.requiredCount} / ${group.total}</span></button>`).join('');
    $('all-groups').classList.toggle('active',!state.species);
    document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===state.tab));
    const warnings=[...(state.parsed.warnings || []),...(state.data.warnings || []),...(state.encodingWarning?[state.encodingWarning]:[])].map(w=>typeof w==='string'?w:JSON.stringify(w));
    const imported=rows.filter(r=>review(r).status==='imported').length;
    if(imported) warnings.push(`${imported} valeurs MANUAL ID importées sont utilisées comme décisions manuelles existantes. Leur provenance reste indiquée « Manuel importé ».`);
    $('data-banner').hidden=!warnings.length;
    if(warnings.length) $('data-banner').innerHTML=`<details><summary>${warnings.length} remarque${warnings.length>1?'s':''} sur les données ou leur import — à examiner avant de se fier au classement</summary><ul>${warnings.slice(0,50).map(w=>`<li>${esc(w)}</li>`).join('')}</ul>${warnings.length>50?'<p>Les 50 premières remarques sont affichées. Les anomalies propres à chaque contact figurent dans sa fiche et dans le journal de vérification.</p>':''}</details>`;
    renderQueue();renderMinimalOverview();renderFocusedContact();
  }
  function planGroupName(group) {
    const name=N.resolve(group.autoId);
    return name.known && name.isSpecies?name.frenchName:outcomeLabel(group.autoId);
  }
  const planGroupCode = group => ({noise:'Bruit',noid:'NoID',unclassified:'Non classé'}[group.kind] || group.autoId);
  function renderMinimalOverview() {
    if(!state.reviewPlan)return;
    const groups=state.reviewPlan.groups.filter(g=>g.remaining>0);
    const max=Math.max(1,...groups.map(g=>g.remaining));
    const ignored=state.classification.metrics.ignored;
    $('overview-note').textContent=`${num(state.reviewPlan.remaining)} contrôles manuels restants.${ignored?' '+num(ignored)+' contacts Noise ignorés.':''} Les objectifs sont ajustés après la vérification des références et les changements d’échantillon.`;
    $('review-chart').innerHTML=`<div class="review-chart-columns" role="list" aria-label="Contrôles manuels restants par identification automatique">${groups.map(g=>`<div class="review-chart-column" role="listitem" title="${esc(planGroupName(g))} : ${num(g.remaining)} contrôle(s) restant(s)${g.conditional?' · un échantillon pourra être requis après la référence':''}"><div class="review-chart-value">${num(g.remaining)}</div><div class="review-chart-bar-track" aria-hidden="true"><div class="review-chart-bar" style="height:${100*g.remaining/max}%"></div></div><div class="review-chart-label">${esc(planGroupCode(g))}${planGroupName(g)!==planGroupCode(g)?`<span class="review-chart-name">${esc(planGroupName(g))}</span>`:''}</div></div>`).join('')}</div>`;
    $('minimal-start').disabled=!state.guided.some(r=>assignment(r).requiresReview);
  }
  function progressMarkup(title,group,subtitle='') {
    const progress=group.total?Math.max(0,Math.min(100,100*group.completed/group.total)):100;
    return `<div class="review-progress-title"><div class="review-progress-label"><strong>${esc(title)}</strong>${subtitle?`<small>${esc(subtitle)}</small>`:''}</div><div class="review-progress-count">${num(group.remaining)}<small>restant${group.remaining===1?'':'s'}</small></div></div><div class="review-progress-track" role="progressbar" aria-label="${esc(subtitle || title)} · contrôles manuels effectués" aria-valuemin="0" aria-valuemax="${group.total}" aria-valuenow="${group.completed}" aria-valuetext="${num(group.completed)} sur ${num(group.total)} effectués ; ${num(group.remaining)} restants"><div class="review-progress-fill" style="width:${progress}%"></div><span class="review-progress-tick" style="left:${progress}%" aria-hidden="true"></span></div><p class="review-progress-note">${num(group.completed)} / ${num(group.total)} contrôles effectués</p>`;
  }
  function renderReviewProgress() {
    const row=state.rowById.get(state.selected);
    if(!row || !state.reviewPlan)return;
    const group=state.reviewPlan.groups.find(g=>g.key===assignment(row).groupKey);
    $('species-progress').innerHTML=progressMarkup(planGroupCode(group),group,planGroupName(group)!==planGroupCode(group)?planGroupName(group):'');
    $('total-progress').innerHTML=progressMarkup('Au total',state.reviewPlan,'Ensemble du fichier');
  }
  function renderFocusedContact() {
    const next=state.minimal?state.guided.find(r=>assignment(r).requiresReview):null;
    const ready=state.classification.metrics.pending===0;
    if(!ready)state.resultsView=false;
    const overview=state.minimal && !state.minimalStarted && !ready && !!next;
    const active=state.minimal && state.minimalStarted && !!next && !state.resultsView;
    document.body.classList.toggle('results-view',state.minimal && state.resultsView);
    document.body.classList.toggle('review-active',active);
    $('minimal-overview').hidden=!overview;
    $('minimal-progress').hidden=!active;
    $('minimal-complete').hidden=!state.minimal || !!next || state.resultsView || overview;
    $('minimal-focus-caption').hidden=!active;
    document.querySelector('.review-layout').hidden=state.minimal && !active;
    if(!state.minimal){renderDetail();return;}
    if(overview){$('detail').innerHTML='';return;}
    if(next){
      state.selected=next.id;const a=assignment(next);
      const step=a.role==='reference'?'Référence de l’espèce':a.role==='audit'?'Contrôle de l’échantillon':'Identification manuelle';
      const name=N.resolve(next.autoId);const caption=name.known && name.isSpecies?name.frenchName:autoLabel(next);
      $('minimal-focus-caption').innerHTML=`<strong>${esc(step)} · ${esc(caption)}</strong><span>Prochain contact à vérifier</span>`;
      renderDetail();renderReviewProgress();return;
    }
    // An intentionally shortened selection can leave a quota deficit without a next pick.
    // Keep the explicit selection intact and lead the reviewer to its controls.
    const card=$('minimal-complete');const m=state.classification.metrics;
    card.querySelector('.completion-mark').textContent=ready?'✓':'!';
    card.querySelector('.eyebrow').textContent=ready?'CONTRÔLES TERMINÉS':'ÉCHANTILLON À COMPLÉTER';
    card.querySelector('h2').textContent=ready?'Vos contrôles sont terminés.':'L’objectif manuel n’est pas encore atteint.';
    card.querySelector('p').textContent=ready?'Consultez le tableau des activités ou vérifiez d’autres contacts.'+(m.unresolved?' '+num(m.unresolved)+' identification(s) restent non résolues.':''):'Complétez votre sélection ou adaptez son objectif dans la vue complète pour attribuer les '+num(m.pending)+' contacts en attente.';
    $('minimal-results').textContent=ready?'Voir le tableau final':'Adapter l’échantillon';
    $('minimal-all').hidden=!ready;
    $('minimal-undo').hidden=!state.undo.length;
    $('detail').innerHTML='';
  }
  function renderCounters() {
    if(!state.classification)return;const metrics=state.classification.metrics;const done=metrics.manual+metrics.inferred+metrics.ignored;
    $('sidebar-count').textContent=metrics.total.toLocaleString('fr-BE'); $('progress-label').textContent=`${done.toLocaleString('fr-BE')} / ${metrics.total.toLocaleString('fr-BE')}`; $('progress-fill').style.width=(100*done/metrics.total)+'%';
    $('pending-count').textContent=metrics.required;
    $('stats').innerHTML=[['Contacts',metrics.total,'≋',''],[state.minimal?'À vérifier':'Vérifications obligatoires restantes',state.minimal?state.reviewPlan.remaining:metrics.required,'◇','amber'],[state.minimal?'Semi-manuels':'Attribués par les règles',metrics.inferred,'↗',''],[state.minimal?'Vérifiés':'Vérifiés manuellement',metrics.manual,'✓','']].map(([label,value,symbol,cls])=>`<div class="stat ${cls}"><div><div class="value">${value.toLocaleString('fr-BE')}</div><div class="label">${label}</div></div><span class="symbol">${symbol}</span></div>`).join('');
  }
  function renderSummary() {
    const c=state.classification;const m=c.metrics;const complete=m.required===0 && m.waiting===0;
    $('summary-state').textContent=complete?`Vérifications terminées${m.unresolved?' · '+m.unresolved+' identifications non résolues':''} · les totaux issus des règles restent des estimations`:'Incomplet · vérifications restantes';
    $('summary-state').className=complete?'summary-complete':'summary-pending';
    $('summary-explanation').textContent=`${m.manual} décisions manuelles + ${m.inferred} attributions semi-manuelles + ${m.ignored} Noise ignorés + ${m.pending} en attente = ${m.total} contacts. ${m.unresolved-m.pending} résultats attribués restent incertains ou sans identification. Le prorata est une extrapolation statistique ; une ligne ainsi remplie n’a pas été identifiée acoustiquement. Toute décision manuelle prime dans ce bilan.`;
    const categories={taxon:'Étiquette d’espèce ou de groupe',uncertain:'Identification de chauve-souris non résolue',unresolved:'Chauve-souris non identifiée',noise:'Bruit / exclu',pending:'Résultat en attente'};
    $('summary-body').innerHTML=c.summary.map(s=>`<tr class="summary-${esc(s.category)}"><td><b>${esc(outcomeLabel(s.label))}</b><small>${esc(categories[s.category] || s.category)}</small></td><td>${s.manual.toLocaleString('fr-BE')}</td><td>${s.inferred.toLocaleString('fr-BE')}</td><td>${s.ignored.toLocaleString('fr-BE')}</td><td><strong>${s.total.toLocaleString('fr-BE')}</strong></td></tr>`).join('');
    $('summary-footer').innerHTML=`<tr><td>Tous les contacts</td><td>${m.manual}</td><td>${m.inferred}</td><td>${m.ignored}</td><td>${m.total}</td></tr>`;
    $('policy-caption').textContent=`Procédure par espèce · majorité stricte > 50 % avec rapport > 0,6 · échantillon par défaut ${num(state.policy.samplePercent)} % · objectifs individuels modifiables`;
    renderActivities();
  }
  function renderActivities() {
    const c=state.classification;const rows=N.activityRows(c.summary);const ready=c.metrics.pending===0;
    const excluded=c.summary.filter(s=>s.category!=='taxon' || ['noise','pending','uncertain','unidentified'].includes(N.resolve(s.label).category));
    const outside=excluded.map(s=>`${num(s.total)} ${outcomeLabel(s.label)}`).join(' · ');
    const unknown=rows.some(row=>!row.known);
    $('activities-state').textContent=ready?'Tableau final · contrôles terminés':'Provisoire · classification à terminer';
    $('activities-state').className=ready?'summary-complete':'summary-pending';
    $('activities-noise-count').textContent=num(c.metrics.ignored);
    $('activities-noise-label').textContent=c.metrics.ignored===1?'contact Noise ignoré':'contacts Noise ignorés';
    $('activities-note').textContent=(ready?'Les contacts attribués à une espèce ou un groupe sont totalisés ci-dessous.':'Ce tableau évolue pendant les contrôles. Son export sera disponible lorsque tous les contrôles seront terminés.')+(outside?' Hors tableau : '+outside+'.':'')+(unknown?' Les libellés libres non reconnus sont conservés sans leur inventer un nom scientifique.':'');
    $('activities-body').innerHTML=rows.map(row=>`<tr><td>${row.isSpecies?`<i>${esc(row.scientificName)}</i>`:`<span class="unknown-label">${esc(row.scientificName)}</span>`}</td><td>${esc(row.frenchName)}</td><td><strong>${num(row.contacts)}</strong></td></tr>`).join('') || '<tr><td colspan="3">Aucun contact attribué à une espèce ou un groupe.</td></tr>';
    $('activities-footer').innerHTML=`<tr><td colspan="2">Total des contacts du tableau</td><td>${num(rows.reduce((total,row)=>total+row.contacts,0))}</td></tr>`;
    $('activities-export').disabled=$('export-activities').disabled=!ready;
    renderActivityChart(rows);
  }
  function renderActivityChart(rows) {
    if(!state.classification)return;
    rows=rows || N.activityRows(state.classification.summary);
    const total=rows.reduce((sum,row)=>sum+row.contacts,0);
    $('activities-chart-pie').setAttribute('aria-pressed',String(state.activityChartMode==='pie'));
    $('activities-chart-bar').setAttribute('aria-pressed',String(state.activityChartMode==='bar'));
    $('activities-chart-note').textContent=total?`Parts calculées sur les ${num(total)} contacts du tableau, sans les Noise ni les identifications non résolues.`:'Aucun contact attribué à une espèce ou un groupe pour le moment.';
    $('activities-chart').innerHTML=V.render(rows,state.activityChartMode);
  }
  const speciesGroup = key => state.classification.groups.find(group=>group.key===key);
  function setSelection(key, value) {
    const candidate={...state.selections,[key]:value};
    try{A.classify(state.data,state.reviews,state.policy,state.drafts,candidate);state.selections=candidate;render();persist();}
    catch(error){toast(error.message);}
  }
  function renderSpeciesWorkflow() {
    if(!state.classification)return;
    const groups=state.classification.groups.filter(g=>g.kind==='species');
    $('species-workflow').innerHTML=`<div class="species-workflow-grid">${groups.map(g=>{
      const selected=g.selectedIds || [];const anchor=state.rowById.get(g.anchorId);
      const title=g.mode==='reference'?'1 · Vérifier le meilleur contact':g.mode==='autoid'?'2 · Auto-ID validé pour l’espèce':g.canInfer?'3 · Répartition au prorata disponible':'2 · Compléter l’échantillon';
      const distribution=(g.distribution || []).map(d=>`${esc(outcomeLabel(d.label))} : ${num(d.manualCount)} manuel(s), ${ratio(d.share)} → ${num(d.inferredCount)} attribution(s)`).join('<br>');
      const target=g.sampleTarget;const manual=g.manualCount;const deficit=Math.max(0,target-manual);
      const strata=g.strata || [];
      return `<article class="species-card ${g.mode==='autoid' || g.canInfer?'complete':''}"><div class="species-card-title"><h3>${esc(g.autoId)}</h3><span>${num(g.total)} contacts</span></div><div class="species-card-state">${title}</div><div class="species-card-note">${num(g.ratioAboveThresholdCount)} / ${num(g.total)} contacts avec un rapport > 0,6 (${ratio(g.ratioAboveThresholdShare)}) · majorité ${g.majorityPass?'atteinte':'non atteinte'}<br>${g.excluded?'Espèce dans la liste d’exclusion : échantillon requis.':'Espèce hors liste d’exclusion.'}<br>Référence ${g.referenceMatches?'confirmée conforme':g.mode==='reference'?'à vérifier':'différente ou incertaine'}${anchor?' · '+esc(anchor.file):''}</div><div class="species-card-counts">${num(manual)} manuel(s) · ${num(g.inferredCount)} semi-manuel(s) · ${num(g.requiredCount)} à vérifier</div><div class="species-card-actions"><button data-workflow="${esc(g.key)}">${g.requiredCount?'Vérifier cette espèce':'Afficher tous les contacts'}</button>${g.mode!=='autoid'?`<label>Objectif manuel en contacts<input data-target="${esc(g.key)}" type="number" min="1" max="${g.total}" step="1" value="${target}"></label><button data-apply-target="${esc(g.key)}">Appliquer l’objectif</button><button data-adapt="${esc(g.key)}">Adapter l’objectif à ma sélection (${selected.length})</button><button data-reset-sample="${esc(g.key)}">Reprendre la sélection proposée</button>`:''}</div>${g.mode!=='autoid'?`<p class="species-card-note">${selected.length} contacts sélectionnés, référence comprise · objectif ${num(target)} (${ratio(target/g.total)})${deficit?' · encore '+num(deficit)+' décision(s) pour atteindre l’objectif':''}. Vous pouvez remplacer, ajouter ou retirer des contacts depuis leur fiche. Toute vérification supplémentaire contribue au prorata.</p>`:''}${strata.length?`<details class="species-card-note"><summary>Classes de rapport et échantillon</summary><table><thead><tr><th>Rapport</th><th>Contacts</th><th>Sélection</th><th>Manuels</th></tr></thead><tbody>${strata.map(s=>`<tr><td>${esc(s.label)}</td><td>${s.total}</td><td>${s.selectedCount}</td><td>${s.manualCount}</td></tr>`).join('')}</tbody></table></details>`:''}${distribution?`<details class="species-card-note" ${g.canInfer && g.mode==='proportion'?'open':''}><summary>Résultats manuels et répartition estimée</summary><p>${distribution}</p></details>`:''}</article>`;
    }).join('')}</div>${groups.length?'':'<p>Aucune suggestion d’espèce : les contacts restent à identifier manuellement.</p>'}`;
    $('species-workflow').querySelectorAll('[data-workflow]').forEach(button=>button.onclick=()=>{state.species=button.dataset.workflow;const g=speciesGroup(state.species);state.tab=g.requiredCount?'pending':'all';state.search='';$('search').value='';filterChanged();});
    $('species-workflow').querySelectorAll('[data-target]').forEach(input=>input.onchange=()=>{const n=Number(input.value);if(!Number.isInteger(n)||n<1||n>speciesGroup(input.dataset.target).total){toast('L’objectif doit être un entier entre 1 et le nombre de contacts de cette espèce.');renderSpeciesWorkflow();return;}setSelection(input.dataset.target,{sampleTarget:n});});
    $('species-workflow').querySelectorAll('[data-apply-target]').forEach(button=>button.onclick=()=>{const input=[...$('species-workflow').querySelectorAll('[data-target]')].find(i=>i.dataset.target===button.dataset.applyTarget);input?.onchange();});
    $('species-workflow').querySelectorAll('[data-adapt]').forEach(button=>button.onclick=()=>{const g=speciesGroup(button.dataset.adapt);setSelection(g.key,{selectedIds:[...g.selectedIds],sampleTarget:g.selectedIds.length});toast('Objectif adapté à votre sélection. La référence reste incluse.');});
    $('species-workflow').querySelectorAll('[data-reset-sample]').forEach(button=>button.onclick=()=>{delete state.selections[button.dataset.resetSample];render();persist();toast('Sélection représentative et objectif par défaut rétablis pour cette espèce.');});
  }
  function renderQueue() {
    const rows=visibleRows(); const pages=Math.max(1,Math.ceil(rows.length/PAGE_SIZE)); state.page=Math.min(state.page,pages-1);
    $('queue-count').textContent=`${rows.length.toLocaleString('fr-BE')} contacts${state.species?' · '+speciesGroup(state.species)?.autoId:''}`;
    $('page-label').textContent=rows.length?`${state.page*PAGE_SIZE+1}–${Math.min((state.page+1)*PAGE_SIZE,rows.length)} sur ${rows.length.toLocaleString('fr-BE')}`:'Aucun contact pour ce filtre';
    $('prev-page').disabled=state.page===0; $('next-page').disabled=state.page>=pages-1;
    $('queue-body').innerHTML=rows.slice(state.page*PAGE_SIZE,(state.page+1)*PAGE_SIZE).map(r=>{const a=assignment(r);return `<tr class="${state.selected===r.id?'selected':''}" data-row="${r.id}"><td><button class="contact-button" data-select="${r.id}" title="${esc(r.file)}">${esc(r.file)}</button><div class="row-meta">${esc(autoLabel(r))} ${a.role==='reference'?'<span class="pick-dot">RÉFÉRENCE</span>':a.role==='audit'?'<span class="pick-dot audit">CONTRÔLE</span>':''}${r.issues.length?'<span title="Données à examiner">⚑</span>':''}</div><div class="row-sub">Ligne ${r.index+1} · ${esc(r.night || 'date manquante')} · canal ${esc(r.channel || '—')} · décalage ${esc(r.offset || '0')} s</div></td><td>${num(r.matching)}</td><td title="Impulsions concordantes / impulsions ; ce rapport ne mesure pas la certitude de l’identification">${ratio(r.ratio)}</td><td><span class="badge ${esc(a.status)}">${esc(statusLabel(a))}</span>${a.label && a.origin!=='pending'?`<div class="row-sub">${esc(outcomeLabel(a.label))}</div>`:''}${state.drafts[r.id]?'<div class="row-sub">Brouillon</div>':''}</td></tr>`;}).join('') || '<tr><td colspan="4"><div class="empty-state">Aucun contact ici. Choisissez un autre filtre pour continuer.</div></td></tr>';
  }
  function locator(row) {
    const indir=state.data.columns.indir>=0?row.raw[state.data.columns.indir]:'';
    const folder=row.rawFolder || '';
    const separator=indir.includes('/') && !indir.includes('\\')?'/':'\\';
    const parts=[indir,folder,row.file].filter(Boolean);
    // Preserve leading UNC \\server and never duplicate the display fallback folder.
    return parts.map((part,i)=>i===0?part.replace(/[\\/]+$/,''):part.replace(/^[\\/]+|[\\/]+$/g,'')).join(separator);
  }
  function draft(row) {
    if(state.drafts[row.id]) return {...state.drafts[row.id],reviewer:state.reviewer};
    const rev=review(row);return {status:checked(rev.status)?rev.status:'',label:rev.label,notes:rev.notes,reviewer:state.reviewer};
  }
  function updateDetailClassification() {
    const row=state.rowById.get(state.selected);const badge=$('detail').querySelector('.detail-top .badge');
    if(!row || !badge)return;const a=assignment(row);
    badge.className='badge '+a.status;badge.textContent=statusLabel(a);
    $('detail').querySelector('.suggestion > span').textContent=a.origin==='inferred'?'Attribué selon les règles actuelles':a.origin==='manual'?'Résultat manuel : '+outcomeLabel(a.label):a.origin==='ignored'?'Noise ignoré selon les règles':'Résultat du classificateur';
    let callout=$('detail').querySelector('.classification-callout');
    if(!callout){callout=document.createElement('div');$('detail').prepend(callout);}
    callout.className='classification-callout '+(a.groupBlocked?'blocked':a.origin==='inferred'?'inferred':'');
    callout.innerHTML=`<b>${a.origin==='inferred'?'Attribution par les règles : '+esc(outcomeLabel(a.label)):a.requiresReview?'Vérification manuelle obligatoire':a.origin==='manual'?'Résultat manuel : '+esc(outcomeLabel(a.label)):a.origin==='ignored'?'Contact Noise ignoré':'En attente des contrôles du groupe'}</b><span>${esc(a.reason || a.reasons.join(' · '))}</span>`;
    if($('semi-label'))$('semi-label').textContent=a.semimanualLabel || 'Vide';
  }
  function renderDetail() {
    const row=state.rowById.get(state.selected);
    $('detail').classList.remove('needs-manual-label');
    if(!row){$('detail').innerHTML='<div class="empty-state">Sélectionnez un contact à vérifier.</div>';return;}
    const rev=review(row); const d=draft(row);const a=assignment(row);const g=speciesGroup(a.groupKey);
    $('detail').classList.toggle('needs-manual-label',['corrected','uncertain'].includes(d.status));
    const options=state.labelOptions;
    const issues=row.issues.map(i=>typeof i==='string'?i:JSON.stringify(i));
    const alternate=[row.alternate1,row.alternate2].filter(Boolean);
    $('detail').innerHTML=`<div class="detail-top"><span class="eyebrow">CONTACT ${row.index+1} · RANG POUR CET AUTO-ID ${a.rank}</span><span class="badge ${esc(rev.status)}">${esc(rev.status==='unreviewed'?'À vérifier':rev.status)}</span></div><h2 class="detail-file">${esc(row.file)}</h2><div class="locator">${esc(row.folder || '(dossier source)')}<br>${esc(row.date || 'Date manquante')} ${esc(row.time || '')} · canal ${esc(row.channel || '—')} · décalage ${esc(row.offset || '0')} s</div><div class="locator-actions"><button id="copy-locator">Copier les coordonnées du fichier ↗</button><button id="inspect-guide">Comment vérifier</button></div>${a.isAnchor?'<div class="detail-callout">Meilleur contact pour cette espèce AUTO-ID sur l’ensemble du CSV. Sa décision détermine la validation directe ou le passage à un échantillon manuel.</div>':''}${alternate.length?`<div class="detail-callout warning">Suggestions alternatives : ${alternate.map(esc).join(', ')}. Vérifiez une éventuelle ambiguïté ou la présence de plusieurs chauves-souris.</div>`:''}${issues.length?`<div class="detail-callout warning">${issues.map(esc).join('<br>')}</div>`:''}<div class="metrics"><div><strong>${num(row.matching)}</strong><small>Impulsions concordantes</small></div><div><strong>${num(row.pulses)}</strong><small>Impulsions</small></div><div><strong>${ratio(row.ratio)}</strong><small>Rapport de concordance${row.ratioSource==='derived'?' (calculé)':''}</small></div><div><strong>${num(row.margin)}</strong><small>Marge</small></div></div><div class="suggestion"><div><span class="label">SUGGESTION AUTOMATIQUE</span><strong>${esc(autoLabel(row))}</strong></div><span>Espèce encore non vérifiée</span></div><div class="form-heading">Votre décision manuelle</div><div class="decision-grid"><button type="button" data-decision="confirmed" class="${d.status==='confirmed'?'chosen':''}" ${row.kind!=='species'?'disabled':''}>✓ Confirmer la suggestion</button><button type="button" data-decision="corrected" class="${d.status==='corrected'?'chosen':''}">↗ Attribuer une étiquette</button><button type="button" data-decision="uncertain" class="${d.status==='uncertain'?'chosen':''}">? Identification incertaine</button><button type="button" data-decision="noise" class="${d.status==='noise'?'chosen':''}">∅ Bruit / aucun cri de chauve-souris</button></div><label class="field-label" for="manual-label">Étiquette manuelle · espèce, groupe ou identification non résolue</label><input id="manual-label" list="species-options" value="${esc(d.label)}" placeholder="Choisissez une décision, puis saisissez une étiquette" ${['confirmed','noise'].includes(d.status)?'readonly':''}><datalist id="species-options">${options.map(o=>`<option value="${esc(o)}"></option>`).join('')}</datalist><div class="form-row"><label><span class="field-label">Vérificateur par défaut</span><input id="reviewer" value="${esc(d.reviewer)}" placeholder="Nom / initiales"><small class="reviewer-default-note">Nom mémorisé pour les prochains contacts.</small></label></div><details class="contact-extra" ${!state.minimal || d.notes ? 'open' : ''}><summary>Notes de vérification</summary><textarea id="notes" aria-label="Notes de vérification" placeholder="Forme des cris, ambiguïté, autres espèces…">${esc(d.notes)}</textarea></details><p class="draft-note">Enregistrez uniquement après avoir examiné ce contact dans Kaleidoscope. « Identification incertaine » conserve une identification non résolue.</p><button class="primary detail-save" id="save-decision">Enregistrer${state.minimal || state.autoNext?' et suivant':''}</button><div class="detail-options"><label><input id="auto-next" type="checkbox" ${state.autoNext?'checked':''}>Passer au suivant après enregistrement</label><button class="text-button" id="undo" ${state.undo.length?'':'disabled'}>Annuler le dernier enregistrement</button><button class="text-button" id="reset-decision">Remettre à vérifier</button></div>${state.drafts[row.id]?'<p class="unsaved">Brouillon enregistré localement · décision non validée</p>':''}${rev.timestamp?`<p class="draft-note">Enregistré le ${esc(new Date(rev.timestamp).toLocaleString('fr-BE'))}${rev.reviewer?' · '+esc(rev.reviewer):''}</p>`:''}<details class="raw-fields"><summary>Tous les champs CSV d’origine (${state.parsed.headers.length})</summary><dl>${state.parsed.headers.map((h,i)=>`<dt>${esc(h)}</dt><dd>${esc(row.raw[i]) || '—'}</dd>`).join('')}</dl></details>`;
    updateDetailClassification();
    const sampleControl=document.createElement('div');sampleControl.className='sample-control';
    sampleControl.innerHTML=`<p><b>SEMIMANUAL ID :</b> <span id="semi-label">${esc(a.semimanualLabel || 'Vide')}</span></p>${a.origin==='manual'?'<p>Le résultat final conserve votre MANUAL ID en priorité.</p>':''}${g?.kind==='species' && g.mode!=='autoid'?`<label><input id="sample-toggle" type="checkbox" ${g.selectedIds.includes(row.id)?'checked':''} ${a.isAnchor?'disabled':''}>Inclure ce contact dans mon échantillon</label><p>${g.selectedIds.length} sélectionnés · objectif ${g.sampleTarget}. La référence est obligatoire. Pour vérifier moins de contacts, retirez-les puis adaptez l’objectif dans le parcours par espèce.</p>`:''}`;
    $('detail').querySelector('.classification-callout').after(sampleControl);
    if($('sample-toggle'))$('sample-toggle').onchange=()=>{const ids=new Set(g.selectedIds);if($('sample-toggle').checked)ids.add(row.id);else ids.delete(row.id);setSelection(g.key,{selectedIds:[...ids],sampleTarget:g.sampleTarget});};
    $('copy-locator').onclick=async()=>{const value=`${locator(row)}\nLigne de données CSV : ${row.index+1}\nCanal : ${row.channel || '(manquant)'}\nDécalage : ${row.offset || '0'} s`;
      try{await navigator.clipboard.writeText(value);toast('Chemin du fichier, ligne CSV, canal et décalage copiés.');}catch{const input=document.createElement('textarea');input.value=value;document.body.append(input);input.select();const copied=document.execCommand('copy');input.remove();toast(copied?'Coordonnées du fichier copiées.':'Presse-papiers indisponible. Consultez les coordonnées et les champs d’origine ci-dessus.');}};
    $('inspect-guide').onclick=()=>{toast('Dans Kaleidoscope : File → Open Results… → votre CSV d’origine. Retrouvez ce fichier avec le même canal et décalage, puis examinez le spectrogramme et la vue par passage à zéro.');};
    document.querySelectorAll('[data-decision]').forEach(b=>b.onclick=()=>{
      captureDraft(); const selected=state.drafts[row.id];selected.status=b.dataset.decision;
      if(selected.status==='confirmed') selected.label=row.autoId;
      else if(selected.status==='noise') selected.label='Noise';
      else if(selected.status==='uncertain') selected.label='Chauve-souris non identifiée';
      else if(['Noise','NoID','Unidentified bat','Chauve-souris non identifiée',row.autoId].includes(selected.label)) selected.label='';
      renderDetail();schedulePersist();
      if(['corrected','uncertain'].includes(selected.status)) $('manual-label').focus();
    });
    ['manual-label','notes','reviewer'].forEach(id=>$(id).addEventListener('input',()=>{if(id==='reviewer')setReviewerDefault($('reviewer').value);captureDraft();schedulePersist();}));
    $('auto-next').onchange=()=>{state.autoNext=$('auto-next').checked;$('save-decision').textContent='Enregistrer'+(state.autoNext?' et suivant':'');};
    $('save-decision').onclick=saveDecision; $('undo').onclick=undo;
    if(state.minimal && row.kind==='species') {
      const bulk=document.createElement('div');bulk.className='minimal-bulk-confirmation';
      bulk.innerHTML=`<button type="button" id="confirm-species-all">Confirmer tous les contacts pour cette espèce</button><p>${num(g.total)} contacts · ${esc(g.autoId)}. Confirme l’AUTO-ID sur toutes les lignes de ce groupe, y compris les décisions existantes.</p>`;
      $('save-decision').after(bulk);
      $('confirm-species-all').onclick=confirmSpecies;
    }
    $('reset-decision').textContent=row.manualId?'Restaurer le MANUAL ID source':'Retirer ma décision';
    $('reset-decision').onclick=()=>{state.undo.push({id:row.id,previous:state.reviews[row.id] || null});delete state.reviews[row.id];delete state.drafts[row.id];render();persist();toast(row.manualId?'Décision locale retirée ; le MANUAL ID source redevient la décision manuelle active.':'Décision retirée. La procédure de cette espèce a été recalculée.');};
  }
  function captureDraft() {
    const row=state.rowById.get(state.selected);if(!row || !$('manual-label')) return;
    const existing=draft(row);
    state.drafts[row.id]={status:existing.status,label:$('manual-label').value,notes:$('notes').value,reviewer:state.reviewer};
  }
  function saveDecision() {
    const row=state.rowById.get(state.selected);if(!row || !$('manual-label')) return;
    captureDraft();const d=state.drafts[row.id];
    if(!checked(d.status)){toast('Choisissez une décision manuelle avant d’enregistrer.');return;}
    if(!d.label.trim()){toast('Saisissez une espèce, un groupe ou une étiquette non résolue.');$('manual-label').focus();return;}
    if(d.status==='confirmed' && row.kind!=='species'){toast('Ce contact ne possède aucune suggestion d’espèce à confirmer. Attribuez-lui une étiquette.');return;}
    state.undo.push({id:row.id,previous:state.reviews[row.id] || null});
    state.reviews[row.id]={...d,label:d.status==='confirmed'?row.autoId:d.status==='noise'?'Noise':d.label.trim(),timestamp:new Date().toISOString()};delete state.drafts[row.id];
    recalculate();const next=visibleRows().find(r=>assignment(r).requiresReview);
    if((state.minimal || state.autoNext) && next) {state.selected=next.id;const remaining=visibleRows();state.page=Math.floor(Math.max(0,remaining.findIndex(r=>r.id===next.id))/PAGE_SIZE);}
    render();persist();toast(d.status==='uncertain'?'Identification incertaine enregistrée. Elle contribue à la part non résolue du prorata.':'Décision enregistrée. Les totaux et les vérifications restantes ont été recalculés.');
  }
  function confirmSpecies() {
    const row=state.rowById.get(state.selected);
    if(!state.minimal || !row || row.kind!=='species' || !$('confirm-species-all'))return;
    const group=speciesGroup(assignment(row).groupKey);
    const result=B.apply({rows:state.data.rows,reviews:state.reviews,drafts:state.drafts,groupKey:group.key,reviewer:state.reviewer,timestamp:new Date().toISOString()});
    clearTimeout(saveTimer);
    state.undo.push({id:row.id,changes:result.changes});
    state.reviews=result.reviews;state.drafts=result.drafts;
    recalculate();const next=visibleRows().find(r=>assignment(r).requiresReview);
    if(next)state.selected=next.id;
    render();persist();
    toast(`${num(result.changes.length)} contacts confirmés pour ${outcomeLabel(group.autoId)}. Vous pouvez annuler cette confirmation globale.`);
  }
  function undo() {
    const item=state.undo.pop();if(!item)return;
    clearTimeout(saveTimer);
    const restored=B.restore({reviews:state.reviews,drafts:state.drafts,changes:item.changes || [{id:item.id,previous:item.previous,previousDraft:null}]});
    state.reviews=restored.reviews;state.drafts=restored.drafts;state.selected=item.id;
    render();persist();toast(item.changes?'Confirmation globale annulée ; décisions et brouillons précédents restaurés.':'Dernier enregistrement annulé.');
  }
  function selectRow(id) {state.selected=id;renderQueue();renderDetail();}
  function filterChanged() {state.page=0;const rows=visibleRows();if(!rows.some(r=>r.id===state.selected)) state.selected=rows[0]?.id || null;render();}
  const sidecarHeaders=['SOURCE ROW','INDIR','FOLDER','IN FILE','CHANNEL','OFFSET','DATE','TIME','NIGHT','AUTO ID','ORIGINAL MANUAL ID','REVIEW STATUS','REVIEW LABEL','REVIEWER','REVIEWED AT','NOTES','GROUP RANK','REFERENCE PICK','MATCHING','PULSES','MATCH RATIO','MARGIN','DATA ISSUES','ASSIGNED LABEL','ASSIGNMENT ORIGIN','ASSIGNMENT STATUS','REQUIRED MANUAL CHECK','CHECK ROLE','ASSIGNMENT REASON','CLASSIFICATION POLICY','SEMIMANUAL ID','SEMIMANUAL METHOD','GLOBAL GROUP','SAMPLE SELECTED','SAMPLE TARGET'];
  function sidecarRecord(row) {const rev=review(row);const a=assignment(row);const g=speciesGroup(a.groupKey);return [row.index+1,state.data.columns.indir>=0?row.raw[state.data.columns.indir]:'',row.rawFolder || '',row.file,row.channel,row.offset,row.date,row.time,row.night,row.autoId,row.manualId,rev.status,rev.label,rev.reviewer,rev.timestamp,rev.notes,a.rank,a.isAnchor?'yes':'no',row.matching??'',row.pulses??'',row.ratio??'',row.margin??'',row.issues.join(' | '),a.label,a.origin,a.status,a.requiresReview?'yes':'no',a.role,a.reason || a.reasons.join(' | '),JSON.stringify(state.policy),a.semimanualLabel,a.semimanualMethod,a.groupKey,g.selectedIds.includes(row.id)?'yes':'no',g.sampleTarget];}
  // Spreadsheet-safe text in sidecars; source CSV values must remain unchanged.
  const safe = value => /^[\t\r\n ]*[=+@-]/.test(String(value)) ? "'"+value : value;
  function exportSidecar(pending=false) {recalculate();const rows=pending?state.data.rows.filter(r=>assignment(r).requiresReview):state.data.rows;download(baseName()+(pending?'-verifications-obligatoires.csv':'-journal-verification.csv'),'\ufeff'+C.stringifyCSV(sidecarHeaders,rows.map(r=>sidecarRecord(r).map(safe)),','),'text/csv;charset=utf-8');}
  function exportSummary() {
    if(!state.data)return;recalculate();const c=state.classification;const complete=c.metrics.required===0 && c.metrics.waiting===0;
    const headers=['LIBELLÉ','CATÉGORIE','CONTACTS VÉRIFIÉS MANUELLEMENT','CONTACTS ATTRIBUÉS PAR LES RÈGLES','CONTACTS IGNORÉS','TOTAL DES CONTACTS','FICHIER SOURCE','VÉRIFICATIONS TERMINÉES','RÈGLES','DATE DE GÉNÉRATION'];
    const categories={taxon:'taxon',noise:'bruit',uncertain:'incertain',unresolved:'non résolu',pending:'en attente'};
    const time=new Date().toISOString();const records=c.summary.map(s=>[outcomeLabel(s.label),categories[s.category],s.manual,s.inferred,s.ignored,s.total,state.source.name,complete?'oui':'non',JSON.stringify(state.policy),time].map(safe));
    download(baseName()+'-synthese-especes.csv','\ufeff'+C.stringifyCSV(headers,records,','),'text/csv;charset=utf-8');
  }
  function exportActivities() {
    if(!state.data)return;recalculate();renderActivities();
    if(state.classification.metrics.pending){toast('Terminez les contrôles avant d’exporter le tableau final des activités.');return;}
    const headers=['Nom scientifique','Nom vernaculaire','Nombre de contacts'];
    const records=N.activityRows(state.classification.summary).map(row=>[row.scientificName,row.frenchName,row.contacts].map(safe));
    download('activites_chiropteres.csv','\ufeff'+C.stringifyCSV(headers,records,';'),'text/csv;charset=utf-8');
  }
  function exportClassified() {
    recalculate();const metadata=['PLECOTUS SOURCE ROW','PLECOTUS ASSIGNED LABEL','PLECOTUS ORIGIN','PLECOTUS STATUS','PLECOTUS CHECK REQUIRED','PLECOTUS CHECK ROLE','PLECOTUS REASON','PLECOTUS POLICY','PLECOTUS SEMIMANUAL ID','PLECOTUS SEMIMANUAL METHOD','PLECOTUS GLOBAL GROUP','PLECOTUS SAMPLE SELECTED','PLECOTUS SAMPLE TARGET'];
    const headers=[...state.parsed.headers];metadata.forEach(name=>{let unique=name;while(headers.some(h=>h.toUpperCase()===unique.toUpperCase()))unique+=' (new)';headers.push(unique);});
    const records=state.data.rows.map(row=>{const a=assignment(row);const g=speciesGroup(a.groupKey);return [...row.raw,...[row.index+1,a.label,a.origin,a.status,a.requiresReview?'yes':'no',a.role,a.reason || a.reasons.join(' | '),JSON.stringify(state.policy),a.semimanualLabel,a.semimanualMethod,a.groupKey,g.selectedIds.includes(row.id)?'yes':'no',g.sampleTarget].map(safe)];});
    download(baseName()+'-contacts-classes.csv','\ufeff'+C.stringifyCSV(headers,records,state.parsed.delimiter),'text/csv;charset=utf-8');
  }
  function putPolicyInForm(policy) {
    $('policy-sample').value=policy.samplePercent;
    $('policy-ignore-noise').checked=policy.ignoreNoise;
  }
  function readPolicyForm() {
    return A.normalizePolicy({version:2,samplePercent:Number($('policy-sample').value),ignoreNoise:$('policy-ignore-noise').checked});
  }
  function previewPolicy() {
    if(!$('rules-form').checkValidity()){$('policy-preview').textContent='Saisissez des valeurs valides pour afficher l’effet de ces règles.';return;}
    try{const policy=readPolicyForm();if(!state.data){$('policy-preview').textContent='Ces règles seront utilisées à l’import. Les objectifs individuels explicites restent prioritaires.';return;}const m=A.classify(state.data,state.reviews,policy,state.drafts,state.selections).metrics;$('policy-preview').textContent=`${m.required} vérifications restantes · ${m.waiting} contacts en attente · ${m.inferred} semi-manuels · ${m.manual} manuels · ${m.ignored} Noise ignorés. Les objectifs individuels explicites restent prioritaires.`;}catch(e){$('policy-preview').textContent=e.message;}
  }
  function exportID() {
    const headers=[...state.parsed.headers];let col=state.data.columns.manualId;if(col<0){col=headers.length;headers.push('MANUAL ID');}
    const records=state.data.rows.map(row=>{const raw=[...row.raw];while(raw.length<headers.length)raw.push('');const rev=review(row);if(checked(rev.status))raw[col]=rev.label;return raw;});
    download(baseName()+'-etiquettes-manuelles.csv','\ufeff'+C.stringifyCSV(headers,records,state.parsed.delimiter),'text/csv;charset=utf-8');toast('CSV des étiquettes manuelles exporté. Conservez l’original et vérifiez cette copie dans Kaleidoscope.');
  }
  function exportSemimanual() {
    recalculate();const headers=[...state.parsed.headers];let manualCol=state.data.columns.manualId;
    if(manualCol<0){manualCol=headers.length;headers.push('MANUAL ID');}
    let semiCol=headers.findIndex(h=>h.toUpperCase().replace(/[^A-Z0-9]/g,'')==='SEMIMANUALID');
    if(semiCol<0){semiCol=headers.length;headers.push('SEMIMANUAL ID');}
    const records=state.data.rows.map(row=>{const raw=[...row.raw];while(raw.length<headers.length)raw.push('');const rev=review(row);if(checked(rev.status))raw[manualCol]=rev.label;raw[semiCol]=assignment(row).semimanualLabel;return raw;});
    download(baseName()+'-semi-manuel.csv','\ufeff'+C.stringifyCSV(headers,records,state.parsed.delimiter),'text/csv;charset=utf-8');toast('CSV semi-manuel exporté : décisions humaines dans MANUAL ID, remplissage des règles dans SEMIMANUAL ID.');
  }
  function demo() {
    const headers=['INDIR','FOLDER','IN FILE','CHANNEL','OFFSET','DURATION','DATE','TIME','DATE-12','AUTO ID','PULSES','MATCHING','MATCH RATIO','MARGIN','ALTERNATE 1','ALTERNATE 2','MANUAL ID','Fc','Sc','Dur','Fmax','Fmin','Qual'];
    const specs=[];
    for(let i=0;i<24;i++){const p=40-i%20;specs.push(['PIPPIP',p,p-1,Number(((p-1)/p).toFixed(6)),2-i*.02,'']);}
    for(let i=0;i<10;i++){const p=18+i%5;specs.push(['PIPNAT',p,p-1,Number(((p-1)/p).toFixed(6)),1.5+i*.03,'']);}
    specs.push(['MYODAU',14,9,.642857,.8,'MYOMYS'],['MYODAU',4,2,.5,.3,''],['MYODAU',8,5,.625,.6,''],['PIPPIP',3,3,1,.5,'PIPNAT']);
    for(let i=0;i<4;i++)specs.push(['NoID',8+i,0,0,0,'']);
    for(let i=0;i<10;i++)specs.push(['Noise',0,0,'',0,'']);
    specs.push(['Noise',2,0,0,0,''],['',5,'','','','']);
    for(let i=0;i<50;i++){const r=[.1,.3,.5,.7,.9][Math.floor(i/10)];const p=i===49?200:40;specs.push(['NYCNOC',p,Math.round(p*r),r,.2,'']);}
    const records=specs.map(([id,p,m,r,margin,alt],i)=>{const hour=21+Math.floor(i/60);const minute=String(i%60).padStart(2,'0');return ['C:\\BatSurvey\\Example',i%2?'site-B':'site-A',`REC_${String(i+1).padStart(4,'0')}_20260918_${hour}${minute}00.wav`,0,0,5,'2026-09-18',`${hour}:${minute}:00`,'2026-09-18',id,p,m,r,margin,alt,'',i===35?'Myotis sp.':'',id==='PIPPIP'?45.2:'',.5,3.2,72,41,8];});
    acceptSource({name:'example-id.csv',text:C.stringifyCSV(headers,records,',')});toast('Exemple fictif chargé. Ces chiffres illustrent le fonctionnement ; ils ne proviennent pas d’enregistrements réels.');
  }
  $('upload').onclick=$('welcome-import').onclick=()=>requestOpen(()=>$('csv-file').click());
  $('csv-file').onchange=e=>loadCSV(e.target.files[0]);$('project-file').onchange=e=>loadProject(e.target.files[0]);
  $('open-project').onclick=()=>requestOpen(()=>$('project-file').click());
  $('load-demo').onclick=$('welcome-demo').onclick=()=>requestOpen(demo);
  $('save-project').onclick=saveProject;$('method').onclick=()=>$('guide-dialog').showModal();
  $('view-mode').onclick=()=>setViewMode(!state.minimal);
  $('minimal-start').onclick=()=>{state.minimalStarted=true;render();};
  $('minimal-overview-back').onclick=()=>{state.minimalStarted=false;state.resultsView=false;render();};
  $('minimal-results').onclick=()=>{
    if(state.classification.metrics.pending){setViewMode(false);$('species-workflow-panel').open=true;$('species-workflow-panel').scrollIntoView({block:'start'});return;}
    state.resultsView=true;$('activities-panel').open=true;render();
  };
  $('minimal-all').onclick=()=>{state.tab='all';state.species='';state.search='';$('search').value='';setViewMode(false);};
  $('minimal-undo').onclick=undo;
  $('reviewer-settings').onclick=()=>{$('default-reviewer').value=state.reviewer;$('reviewer-dialog').showModal();$('default-reviewer').focus();};
  $('reviewer-form').onsubmit=e=>{e.preventDefault();const stored=setReviewerDefault($('default-reviewer').value);$('reviewer-dialog').close();if(state.data){renderFocusedContact();persist();}if(stored)toast('Vérificateur mémorisé pour les prochains contacts et CSV.');};
  $('rules').onclick=()=>{putPolicyInForm(state.policy);previewPolicy();$('rules-dialog').showModal();};
  $('policy-sample').oninput=previewPolicy;
  $('policy-ignore-noise').onchange=previewPolicy;
  $('rules-form').onsubmit=e=>{e.preventDefault();if(!$('rules-form').reportValidity())return;try{state.policy=readPolicyForm();$('rules-dialog').close();if(state.data){recalculate();filterChanged();persist();}toast('Règles appliquées. Les décisions manuelles sont conservées ; les attributions par les règles et les vérifications obligatoires ont été recalculées.');}catch(error){toast(error.message);}};
  $('export').onclick=()=>{recalculate();const m=state.classification.metrics;const drafts=Object.keys(state.drafts).length;$('export-caption').textContent=`${m.manual} vérifiés manuellement · ${m.inferred} attribués par les règles · ${m.ignored} Noise ignorés · ${m.required} vérifications obligatoires restantes · ${m.waiting} en attente des contrôles.${drafts?' '+drafts+' brouillons non terminés ne sont pas des décisions validées.':''}`;$('export-dialog').showModal();};
  $('activities-export').onclick=$('export-activities').onclick=exportActivities;$('export-id').onclick=exportID;$('export-semimanual').onclick=exportSemimanual;$('export-audit').onclick=()=>exportSidecar();$('export-pending').onclick=()=>exportSidecar(true);$('export-summary').onclick=$('summary-export').onclick=exportSummary;$('export-classified').onclick=exportClassified;
  $('activities-chart-pie').onclick=()=>{state.activityChartMode='pie';renderActivityChart();};
  $('activities-chart-bar').onclick=()=>{state.activityChartMode='bar';renderActivityChart();};
  document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$(b.dataset.close).close());
  $('cancel-replace').onclick=()=>{pendingOpen=null;$('replace-dialog').close();};
  function continueOpen(backup){if(backup)saveProject();const fn=pendingOpen;pendingOpen=null;$('replace-dialog').close();fn?.();}
  $('backup-replace').onclick=()=>continueOpen(true);$('continue-replace').onclick=()=>continueOpen(false);
  document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;filterChanged();});
  $('species-list').onclick=e=>{const button=e.target.closest('[data-species]');if(button){state.species=button.dataset.species;filterChanged();}};
  $('all-groups').onclick=()=>{state.species='';filterChanged();};
  $('search').oninput=e=>{state.search=e.target.value;filterChanged();};$('sort').onchange=e=>{state.sort=e.target.value;filterChanged();};
  $('queue-body').onclick=e=>{const row=e.target.closest('[data-row]');if(row)selectRow(row.dataset.row);};
  $('prev-page').onclick=()=>{state.page--;renderQueue();};$('next-page').onclick=()=>{state.page++;renderQueue();};
  document.addEventListener('keydown',e=>{
    if(!state.data || document.querySelector('dialog[open]'))return;
    if(e.ctrlKey && e.key==='Enter'){e.preventDefault();saveDecision();return;}
    if(state.minimal)return;
    if(e.ctrlKey||e.altKey||e.metaKey||['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))return;
    if(e.key.toLowerCase()==='j'||e.key.toLowerCase()==='k'){const rows=visibleRows();const at=rows.findIndex(r=>r.id===state.selected);const next=rows[at+(e.key.toLowerCase()==='j'?1:-1)];if(next){e.preventDefault();state.page=Math.floor(rows.indexOf(next)/PAGE_SIZE);selectRow(next.id);}}
  });
  window.addEventListener('pagehide',()=>{clearTimeout(saveTimer);if(state.source)persist();});
  try{const saved=localStorage.getItem(STORAGE);if(saved){const p=JSON.parse(saved);if(p.format==='plecotus-review'&&[1,2,3].includes(p.version)){acceptSource(p.source,p);toast(p.version<3?'Projet local restauré ; ancienne règle prudente remplacée, décisions conservées.':'Projet local restauré avec ses décisions et sa sélection.');}}}catch(error){$('save-status').textContent='Restauration depuis le navigateur indisponible';}
})();
