/* Browser-only review UI. No recording or CSV is transmitted. */
(() => {
  'use strict';
  const C = window.BatReviewCore;
  const A = window.BatClassification;
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const checked = status => ['confirmed','corrected','uncertain','noise'].includes(status);
  const state = {source:null,data:null,parsed:null,rowById:new Map(),guided:[],speciesLabels:[],labelOptions:[],reviews:{},drafts:{},reviewer:'',tab:'pending',species:'',search:'',sort:'guided',selected:null,page:0,autoNext:true,undo:[],encodingWarning:'',policy:A.normalizePolicy({preset:'cautious'}),classification:null};
  const STORAGE = 'plecotus.project.v1';
  const PAGE_SIZE = 50;
  let toastTimer, saveTimer, pendingOpen;
  const num = n => n == null ? '—' : Number(n).toLocaleString('fr-BE', {maximumFractionDigits:3});
  const ratio = n => n == null ? '—' : (n * 100).toLocaleString('fr-BE', {minimumFractionDigits:1, maximumFractionDigits:1}) + ' %';
  const policyName = preset => ({cautious:'Prudent',balanced:'Équilibré',faster:'Rapide',custom:'Personnalisé'}[preset] || 'Personnalisé');
  // Translate interface outcomes while keeping source cells and species labels intact.
  const outcomeLabel = label => ({'Noise':'Bruit','No ID':'Sans identification (NoID)','NoID':'Sans identification (NoID)','Unclassified':'Non classé','Unidentified bat':'Chauve-souris non identifiée','Pending classification':'Classification en attente','Uncertain / unresolved':'Identification incertaine / non résolue'}[label] || label);
  const autoLabel = row => row.kind==='noise'?'Bruit (Noise)':row.kind==='noid'?'Sans identification (NoID)':row.kind==='unclassified'?'Non classé':row.autoId;
  const review = row => state.reviews[row.id] || {status:row.manualId ? 'imported' : 'unreviewed',label:row.manualId || '',notes:'',reviewer:'',timestamp:''};
  const assignment = row => state.classification?.byId.get(row.id);
  const statusLabel = result => result?.origin==='pending' && result.role==='waiting' ? 'En attente des contrôles' : ({'inferred':'Attribué par les règles','inferred-noise':'Bruit selon les règles','needs-review':'À vérifier','imported':'Importé','draft':'Brouillon','confirmed':'Confirmé','corrected':'Attribué manuellement','uncertain':'Incertain','noise':'Bruit vérifié'}[result?.status] || 'À vérifier');
  function recalculate() {
    if(!state.data) return;
    state.classification=A.classify(state.data,state.reviews,state.policy,state.drafts);
    const priority=r=>{const a=assignment(r);return a.origin==='manual'?5:a.origin==='inferred'?4:a.role==='waiting'?3:a.role==='reference'?0:a.role==='audit'?1:2;};
    state.guided=[...state.data.rows].sort((a,b)=>priority(a)-priority(b)||a.autoId.localeCompare(b.autoId)||a.groupKey.localeCompare(b.groupKey)||a.rank-b.rank||a.index-b.index);
  }
  function toast(message) { $('toast').textContent=message; $('toast').hidden=false; clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('toast').hidden=true,5000); }
  function project() { return {format:'plecotus-review',version:2,source:state.source,reviews:state.reviews,drafts:state.drafts,reviewer:state.reviewer,policy:state.policy,encodingWarning:state.encodingWarning,exportedAt:new Date().toISOString()}; }
  function persist() {
    if (!state.source) return;
    try { localStorage.setItem(STORAGE,JSON.stringify(project())); $('save-status').textContent='Enregistré dans ce navigateur'; }
    catch { $('save-status').textContent='Enregistrer une sauvegarde du projet'; toast('Le stockage du navigateur est indisponible ou plein. Utilisez « Enregistrer le projet » pour conserver vos décisions.'); }
  }
  function schedulePersist() { clearTimeout(saveTimer); $('save-status').textContent='Enregistrement du brouillon…'; saveTimer=setTimeout(()=>{recalculate();renderCounters();renderSummary();renderQueue();updateDetailClassification();persist();},350); }
  function download(name,body,type) {
    const url=URL.createObjectURL(new Blob([body],{type})); const a=document.createElement('a'); a.href=url; a.download=name; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  const baseName = () => (state.source?.name || 'id.csv').replace(/\.[^.]+$/,'');
  function saveProject() { if(!state.source) return; download(baseName()+'.plecotus.json',JSON.stringify(project(),null,2),'application/json'); toast('Sauvegarde téléchargée : elle contient le CSV, les décisions et les brouillons.'); }
  function requestOpen(callback) {
    if(state.source && (Object.keys(state.reviews).length || Object.keys(state.drafts).length)) {pendingOpen=callback;$('replace-dialog').showModal();} else callback();
  }
  function acceptSource(source,extras={}) {
    if(!source || typeof source.text!=='string' || typeof source.name!=='string') throw new Error('Le projet ne contient aucun CSV source valide.');
    const parsed=C.parseCSV(source.text); const data=C.analyze(parsed.headers,parsed.records);data.headers=parsed.headers;
    const policy=A.normalizePolicy(extras.policy || state.policy);
    if(!data.rows.length) throw new Error('Ce CSV ne contient aucun contact.');
    if(data.columns.file < 0) throw new Error('La colonne IN FILE (ou File) est introuvable. Importez un id.csv ou un export Kaleidoscope compatible.');
    const reviews={}; const drafts={}; const rowById=new Map(data.rows.map(r=>[r.id,r]));
    for(const [id,r] of Object.entries(extras.reviews || {})) {
      if(!rowById.has(id) || !r || !checked(r.status) || typeof r.label!=='string' || !r.label.trim()) throw new Error('Le projet contient une décision de vérification invalide.');
      const row=rowById.get(id);
      if(r.status==='confirmed' && (row.kind!=='species' || r.label.trim()!==row.autoId)) throw new Error('Une étiquette confirmée du projet ne correspond pas à la suggestion source.');
      if(r.status==='noise' && r.label!=='Noise') throw new Error('Une décision « Bruit » contient une étiquette incohérente.');
      reviews[id]={status:r.status,label:r.label,notes:String(r.notes || ''),reviewer:String(r.reviewer || ''),timestamp:String(r.timestamp || '')};
    }
    for(const [id,d] of Object.entries(extras.drafts || {})) if(rowById.has(id) && d && typeof d==='object') drafts[id]={status:['confirmed','corrected','uncertain','noise'].includes(d.status)?d.status:'',label:String(d.label || ''),notes:String(d.notes || ''),reviewer:String(d.reviewer || '')};
    const priority=r=>r.isAnchor?0:['noid','unclassified'].includes(r.kind)?1:r.kind==='species'?2:3;
    const guided=[...data.rows].sort((a,b)=>priority(a)-priority(b)||a.autoId.localeCompare(b.autoId)||a.groupKey.localeCompare(b.groupKey)||a.rank-b.rank||a.index-b.index);
    const speciesLabels=[...new Set(data.rows.filter(r=>r.kind==='species').map(r=>r.autoId))].sort();
    const labelOptions=[...new Set([...speciesLabels,'Chauve-souris non identifiée','Myotis sp.','Plecotus sp.','Pipistrellus sp.','Groupe Nyctalus / Eptesicus / Vespertilio'])].sort();
    Object.assign(state,{source,parsed,data,rowById,guided,speciesLabels,labelOptions,reviews,drafts,policy,reviewer:String(extras.reviewer || ''),encodingWarning:String(extras.encodingWarning || ''),tab:'pending',species:'',search:'',selected:null,page:0,undo:[]});
    recalculate();
    state.selected=visibleRows()[0]?.id || data.rows[0].id;
    $('search').value=''; $('sort').value=state.sort; $('welcome').hidden=true; $('workspace').hidden=false;
    ['save-project','export'].forEach(id=>$(id).disabled=false); render(); persist();
  }
  async function loadCSV(file) {
    if(!file) return;
    try {
      if(file.size>50*1024*1024) throw new Error('Cette version dans le navigateur accepte les CSV de moins de 50 Mo.');
      const bytes=new Uint8Array(await file.arrayBuffer()); let text,warning='';
      if(bytes[0]===255 && bytes[1]===254) text=new TextDecoder('utf-16le').decode(bytes);
      else if(bytes[0]===254 && bytes[1]===255) text=new TextDecoder('utf-16be').decode(bytes);
      else { try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{text=new TextDecoder('windows-1252').decode(bytes);warning='CSV décodé en Windows-1252. Les exports utilisent UTF-8 ; vérifiez les accents avant de rouvrir le fichier.';} }
      acceptSource({name:file.name,text},{encodingWarning:warning});
      toast(`${state.data.rows.length.toLocaleString('fr-BE')} contacts importés. Commencez par les vérifications obligatoires ; les attributions éligibles seront disponibles une fois ces contrôles validés.`);
    } catch(error) {toast(error.message);} finally {$('csv-file').value='';}
  }
  async function loadProject(file) {
    if(!file) return;
    try {
      if(file.size>75*1024*1024) throw new Error('Ce projet est trop volumineux pour cette première version.');
      let p;try{p=JSON.parse(await file.text());}catch{throw new Error('Le fichier de projet ne contient pas un JSON valide.');}
      if(!p || p.format!=='plecotus-review'||![1,2].includes(p.version)) throw new Error('Choisissez un fichier JSON de projet Plecotus version 1 ou 2.');
      acceptSource(p.source,p);toast('Projet ouvert avec ses décisions et ses brouillons.');
    }catch(error){toast(error.message);}finally{$('project-file').value='';}
  }
  function visibleRows() {
    if(!state.data) return [];
    const query=state.search.toLowerCase();
    return (state.sort==='source'?state.data.rows:state.guided).filter(r=>{
      const rev=review(r);const a=assignment(r);
      if(state.species && r.autoId!==state.species) return false;
      if(query && ![r.file,r.folder,r.autoId,autoLabel(r),rev.label,outcomeLabel(rev.label),a?.label,outcomeLabel(a?.label),rev.notes,r.date,r.time,r.offset].join(' ').toLowerCase().includes(query)) return false;
      if(state.tab==='pending') return a.requiresReview;
      if(state.tab==='reviewed') return checked(rev.status);
      if(state.tab==='anchors') return r.isAnchor;
      if(state.tab==='audits') return a.role==='audit';
      if(state.tab==='waiting') return a.role==='waiting' && a.origin==='pending';
      if(state.tab==='inferred') return a.origin==='inferred';
      if(state.tab==='noid') return ['noid','unclassified'].includes(r.kind);
      if(state.tab==='noise') return r.kind==='noise';
      return true;
    });
  }
  function render() {
    if(!state.data) return;
    recalculate();
    const rows=state.data.rows; const metrics=state.classification.metrics;
    const species=state.speciesLabels;
    const counts=new Map();for(const row of rows){if(!counts.has(row.autoId))counts.set(row.autoId,{total:0,pending:0});const count=counts.get(row.autoId);count.total++;if(assignment(row).requiresReview)count.pending++;}
    $('dataset-name').textContent=state.source.name;
    $('dataset-caption').textContent=`${state.source.name} · ${rows.length.toLocaleString('fr-BE')} contacts · ${state.source.name==='example-id.csv'?'Données fictives de démonstration · ':''}${metrics.waiting} contacts en attente des contrôles de leur groupe`;
    renderCounters();
    renderSummary();
    const labels=[...species,...[...new Set(rows.filter(r=>r.kind!=='species').map(r=>r.autoId))].sort()];
    $('species-list').innerHTML=labels.map(label=>{const count=counts.get(label);return `<button class="nav-button ${state.species===label?'active':''}" data-species="${esc(label)}"><b>${esc(outcomeLabel(label))}</b><span>${count.pending} / ${count.total}</span></button>`;}).join('');
    $('all-groups').classList.toggle('active',!state.species);
    document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===state.tab));
    const warnings=[...(state.parsed.warnings || []),...(state.data.warnings || []),...(state.encodingWarning?[state.encodingWarning]:[])].map(w=>typeof w==='string'?w:JSON.stringify(w));
    const imported=rows.filter(r=>review(r).status==='imported').length;
    if(imported) warnings.push(`${imported} étiquettes manuelles existantes ont été conservées comme données importées ; elles ne comptent pas comme vérifiées dans ce projet.`);
    $('data-banner').hidden=!warnings.length;
    if(warnings.length) $('data-banner').innerHTML=`<details><summary>${warnings.length} remarque${warnings.length>1?'s':''} sur les données ou leur import — à examiner avant de se fier au classement</summary><ul>${warnings.slice(0,50).map(w=>`<li>${esc(w)}</li>`).join('')}</ul>${warnings.length>50?'<p>Les 50 premières remarques sont affichées. Les anomalies propres à chaque contact figurent dans sa fiche et dans le journal de vérification.</p>':''}</details>`;
    renderQueue();renderDetail();
  }
  function renderCounters() {
    if(!state.classification)return;const metrics=state.classification.metrics;const done=metrics.manual+metrics.inferred;
    $('sidebar-count').textContent=metrics.total.toLocaleString('fr-BE'); $('progress-label').textContent=`${done.toLocaleString('fr-BE')} / ${metrics.total.toLocaleString('fr-BE')}`; $('progress-fill').style.width=(100*done/metrics.total)+'%';
    $('pending-count').textContent=metrics.required;
    $('stats').innerHTML=[['Contacts',metrics.total,'≋',''],['Vérifications obligatoires restantes',metrics.required,'◇','amber'],['Attribués par les règles',metrics.inferred,'↗',''],['Vérifiés manuellement',metrics.manual,'✓','']].map(([label,value,symbol,cls])=>`<div class="stat ${cls}"><div><div class="value">${value.toLocaleString('fr-BE')}</div><div class="label">${label}</div></div><span class="symbol">${symbol}</span></div>`).join('');
  }
  function renderSummary() {
    const c=state.classification;const m=c.metrics;const complete=m.required===0 && m.waiting===0;
    $('summary-state').textContent=complete?`Vérifications terminées${m.unresolved?' · '+m.unresolved+' identifications non résolues':''} · les totaux issus des règles restent des estimations`:'Incomplet · vérifications restantes';
    $('summary-state').className=complete?'summary-complete':'summary-pending';
    $('summary-explanation').textContent=`${m.manual} vérifiés manuellement + ${m.inferred} attribués par les règles + ${m.pending} en attente = ${m.total} contacts. ${m.unresolved-m.pending} contacts vérifiés restent incertains ou sans identification. Les totaux couvrent toutes les données, quels que soient les filtres.`;
    const categories={taxon:'Étiquette d’espèce ou de groupe',uncertain:'Identification de chauve-souris non résolue',unresolved:'Chauve-souris non identifiée',noise:'Bruit / exclu',pending:'Résultat en attente'};
    $('summary-body').innerHTML=c.summary.map(s=>`<tr class="summary-${esc(s.category)}"><td><b>${esc(outcomeLabel(s.label))}</b><small>${esc(categories[s.category] || s.category)}</small></td><td>${s.manual.toLocaleString('fr-BE')}</td><td>${s.inferred.toLocaleString('fr-BE')}</td><td><strong>${s.total.toLocaleString('fr-BE')}</strong></td></tr>`).join('');
    $('summary-footer').innerHTML=`<tr><td>Tous les contacts</td><td>${m.manual}</td><td>${m.inferred}</td><td>${m.total}</td></tr>`;
    $('policy-caption').textContent=`Règles : ${policyName(state.policy.preset)} · impulsions concordantes ≥ ${num(state.policy.minMatching)} · rapport ≥ ${num(Math.round(state.policy.minRatio*1000)/10)} % · contrôle ${num(state.policy.auditPercent)} % / min. ${num(state.policy.auditMinimum)}`;
  }
  function renderQueue() {
    const rows=visibleRows(); const pages=Math.max(1,Math.ceil(rows.length/PAGE_SIZE)); state.page=Math.min(state.page,pages-1);
    $('queue-count').textContent=`${rows.length.toLocaleString('fr-BE')} contacts${state.species?' · '+state.species:''}`;
    $('page-label').textContent=rows.length?`${state.page*PAGE_SIZE+1}–${Math.min((state.page+1)*PAGE_SIZE,rows.length)} sur ${rows.length.toLocaleString('fr-BE')}`:'Aucun contact pour ce filtre';
    $('prev-page').disabled=state.page===0; $('next-page').disabled=state.page>=pages-1;
    $('queue-body').innerHTML=rows.slice(state.page*PAGE_SIZE,(state.page+1)*PAGE_SIZE).map(r=>{const a=assignment(r);return `<tr class="${state.selected===r.id?'selected':''}" data-row="${r.id}"><td><button class="contact-button" data-select="${r.id}" title="${esc(r.file)}">${esc(r.file)}</button><div class="row-meta">${esc(autoLabel(r))} ${a.role==='reference'?'<span class="pick-dot">RÉFÉRENCE</span>':a.role==='audit'?'<span class="pick-dot audit">CONTRÔLE</span>':''}${r.issues.length?'<span title="Données à examiner">⚑</span>':''}</div><div class="row-sub">Ligne ${r.index+1} · ${esc(r.night || 'date manquante')} · canal ${esc(r.channel || '—')} · décalage ${esc(r.offset || '0')} s</div></td><td>${num(r.matching)}</td><td title="Impulsions concordantes / impulsions ; ce rapport ne mesure pas la certitude de l’identification">${ratio(r.ratio)}</td><td><span class="badge ${esc(a.status)}">${esc(statusLabel(a))}</span>${a.label && a.origin!=='pending'?`<div class="row-sub">${esc(outcomeLabel(a.label))}</div>`:''}${state.drafts[r.id]?'<div class="row-sub">Brouillon</div>':''}</td></tr>`;}).join('') || '<tr><td colspan="4"><div class="empty-state">Aucun contact ici. Choisissez un autre filtre pour continuer.</div></td></tr>';
  }
  function locator(row) {
    const indir=state.data.columns.indir>=0?row.raw[state.data.columns.indir]:'';
    const folder=row.rawFolder || '';
    const separator=indir.includes('/') && !indir.includes('\\')?'/':'\\';
    const parts=[indir,folder,row.file].filter(Boolean);
    // Preserve leading UNC \\server and never duplicate the display fallback folder.
    return parts.map((part,i)=>i===0?part.replace(/[\\/]+$/,''):part.replace(/^[\\/]+|[\\/]+$/g,'')).join(separator);
  }
  function draft(row) {
    if(state.drafts[row.id]) return state.drafts[row.id];
    const rev=review(row);return {status:checked(rev.status)?rev.status:'',label:rev.label,notes:rev.notes,reviewer:rev.reviewer || state.reviewer};
  }
  function updateDetailClassification() {
    const row=state.rowById.get(state.selected);const badge=$('detail').querySelector('.detail-top .badge');
    if(!row || !badge)return;const a=assignment(row);
    badge.className='badge '+a.status;badge.textContent=statusLabel(a);
    $('detail').querySelector('.suggestion > span').textContent=a.origin==='inferred'?'Attribué selon les règles actuelles':a.origin==='manual'?'Résultat manuel : '+outcomeLabel(a.label):'Résultat du classificateur';
    let callout=$('detail').querySelector('.classification-callout');
    if(!callout){callout=document.createElement('div');$('detail').prepend(callout);}
    callout.className='classification-callout '+(a.groupBlocked?'blocked':a.origin==='inferred'?'inferred':'');
    callout.innerHTML=`<b>${a.origin==='inferred'?'Attribution par les règles : '+esc(outcomeLabel(a.label)):a.requiresReview?'Vérification manuelle obligatoire':a.origin==='manual'?'Résultat manuel : '+esc(outcomeLabel(a.label)):'En attente des contrôles du groupe'}</b><span>${esc(a.reason || a.reasons.join(' · '))}</span>`;
  }
  function renderDetail() {
    const row=state.rowById.get(state.selected);
    if(!row){$('detail').innerHTML='<div class="empty-state">Sélectionnez un contact à vérifier.</div>';return;}
    const rev=review(row); const d=draft(row);const a=assignment(row);
    const options=state.labelOptions;
    const issues=row.issues.map(i=>typeof i==='string'?i:JSON.stringify(i));
    const alternate=[row.alternate1,row.alternate2].filter(Boolean);
    $('detail').innerHTML=`<div class="detail-top"><span class="eyebrow">CONTACT ${row.index+1} · RANG DANS LE GROUPE ${row.rank}</span><span class="badge ${esc(rev.status)}">${esc(rev.status==='unreviewed'?'À vérifier':rev.status)}</span></div><h2 class="detail-file">${esc(row.file)}</h2><div class="locator">${esc(row.folder || '(dossier source)')}<br>${esc(row.date || 'Date manquante')} ${esc(row.time || '')} · canal ${esc(row.channel || '—')} · décalage ${esc(row.offset || '0')} s</div><div class="locator-actions"><button id="copy-locator">Copier les coordonnées du fichier ↗</button><button id="inspect-guide">Comment vérifier</button></div>${row.isAnchor?'<div class="detail-callout">Contact de référence pour cette étiquette automatique, ce dossier et cette nuit. Examinez-le pour orienter la vérification ; d’autres contacts doivent encore être contrôlés.</div>':''}${alternate.length?`<div class="detail-callout warning">Suggestions alternatives : ${alternate.map(esc).join(', ')}. Vérifiez une éventuelle ambiguïté ou la présence de plusieurs chauves-souris.</div>`:''}${issues.length?`<div class="detail-callout warning">${issues.map(esc).join('<br>')}</div>`:''}<div class="metrics"><div><strong>${num(row.matching)}</strong><small>Impulsions concordantes</small></div><div><strong>${num(row.pulses)}</strong><small>Impulsions</small></div><div><strong>${ratio(row.ratio)}</strong><small>Rapport de concordance${row.ratioSource==='derived'?' (calculé)':''}</small></div><div><strong>${num(row.margin)}</strong><small>Marge</small></div></div><div class="suggestion"><div><span class="label">SUGGESTION AUTOMATIQUE</span><strong>${esc(autoLabel(row))}</strong></div><span>Espèce encore non vérifiée</span></div><div class="form-heading">Votre décision manuelle</div><div class="decision-grid"><button type="button" data-decision="confirmed" class="${d.status==='confirmed'?'chosen':''}" ${row.kind!=='species'?'disabled':''}>✓ Confirmer la suggestion</button><button type="button" data-decision="corrected" class="${d.status==='corrected'?'chosen':''}">↗ Attribuer une étiquette</button><button type="button" data-decision="uncertain" class="${d.status==='uncertain'?'chosen':''}">? Identification incertaine</button><button type="button" data-decision="noise" class="${d.status==='noise'?'chosen':''}">∅ Bruit / aucun cri de chauve-souris</button></div><label class="field-label" for="manual-label">Étiquette manuelle · espèce, groupe ou identification non résolue</label><input id="manual-label" list="species-options" value="${esc(d.label)}" placeholder="Choisissez une décision, puis saisissez une étiquette" ${['confirmed','noise'].includes(d.status)?'readonly':''}><datalist id="species-options">${options.map(o=>`<option value="${esc(o)}"></option>`).join('')}</datalist><div class="form-row"><label><span class="field-label">Vérificateur</span><input id="reviewer" value="${esc(d.reviewer)}" placeholder="Nom / initiales"></label></div><label class="field-label" for="notes">Notes de vérification</label><textarea id="notes" placeholder="Forme des cris, ambiguïté, autres espèces…">${esc(d.notes)}</textarea><p class="draft-note">Enregistrez uniquement après avoir examiné ce contact dans Kaleidoscope. « Identification incertaine » conserve une identification non résolue.</p><button class="primary detail-save" id="save-decision">Enregistrer${state.autoNext?' et suivant':''}</button><div class="detail-options"><label><input id="auto-next" type="checkbox" ${state.autoNext?'checked':''}>Passer au suivant après enregistrement</label><button class="text-button" id="undo" ${state.undo.length?'':'disabled'}>Annuler le dernier enregistrement</button><button class="text-button" id="reset-decision">Remettre à vérifier</button></div>${state.drafts[row.id]?'<p class="unsaved">Brouillon enregistré localement · décision non validée</p>':''}${rev.timestamp?`<p class="draft-note">Enregistré le ${esc(new Date(rev.timestamp).toLocaleString('fr-BE'))}${rev.reviewer?' · '+esc(rev.reviewer):''}</p>`:''}<details class="raw-fields"><summary>Tous les champs CSV d’origine (${state.parsed.headers.length})</summary><dl>${state.parsed.headers.map((h,i)=>`<dt>${esc(h)}</dt><dd>${esc(row.raw[i]) || '—'}</dd>`).join('')}</dl></details>`;
    updateDetailClassification();
    if(row.isAnchor) $('detail').querySelector('.detail-callout').textContent='Contact de référence pour cette espèce, ce dossier et cette nuit. Ce contact et l’échantillon de contrôle doivent confirmer la suggestion avant d’attribuer les autres contacts éligibles.';
    $('copy-locator').onclick=async()=>{const value=`${locator(row)}\nLigne de données CSV : ${row.index+1}\nCanal : ${row.channel || '(manquant)'}\nDécalage : ${row.offset || '0'} s`;
      try{await navigator.clipboard.writeText(value);toast('Chemin du fichier, ligne CSV, canal et décalage copiés.');}catch{const input=document.createElement('textarea');input.value=value;document.body.append(input);input.select();const copied=document.execCommand('copy');input.remove();toast(copied?'Coordonnées du fichier copiées.':'Presse-papiers indisponible. Consultez les coordonnées et les champs d’origine ci-dessus.');}};
    $('inspect-guide').onclick=()=>{toast('Dans Kaleidoscope : File → Open Results… → votre CSV d’origine. Retrouvez ce fichier avec le même canal et décalage, puis examinez le spectrogramme et la vue par passage à zéro.');};
    document.querySelectorAll('[data-decision]').forEach(b=>b.onclick=()=>{
      captureDraft(); const selected=state.drafts[row.id];selected.status=b.dataset.decision;
      if(selected.status==='confirmed') selected.label=row.autoId;
      else if(selected.status==='noise') selected.label='Noise';
      else if(selected.status==='uncertain') selected.label='Chauve-souris non identifiée';
      else if(['Noise','NoID','Unidentified bat','Chauve-souris non identifiée',row.autoId].includes(selected.label)) selected.label='';
      renderDetail();schedulePersist();
      if(['corrected','uncertain'].includes(selected.status)) $('manual-label').focus();
    });
    ['manual-label','notes','reviewer'].forEach(id=>$(id).addEventListener('input',()=>{captureDraft();schedulePersist();}));
    $('auto-next').onchange=()=>{state.autoNext=$('auto-next').checked;$('save-decision').textContent='Enregistrer'+(state.autoNext?' et suivant':'');};
    $('save-decision').onclick=saveDecision; $('undo').onclick=undo;
    $('reset-decision').onclick=()=>{state.undo.push({id:row.id,previous:state.reviews[row.id] || null});delete state.reviews[row.id];delete state.drafts[row.id];render();persist();toast('Contact remis à vérifier. Son étiquette manuelle importée reste conservée.');};
  }
  function captureDraft() {
    const row=state.rowById.get(state.selected);if(!row || !$('manual-label')) return;
    const existing=draft(row);
    state.drafts[row.id]={status:existing.status,label:$('manual-label').value,notes:$('notes').value,reviewer:$('reviewer').value};
    state.reviewer=$('reviewer').value;
  }
  function saveDecision() {
    const row=state.rowById.get(state.selected);if(!row) return;
    captureDraft();const d=state.drafts[row.id];
    if(!checked(d.status)){toast('Choisissez une décision manuelle avant d’enregistrer.');return;}
    if(!d.label.trim()){toast('Saisissez une espèce, un groupe ou une étiquette non résolue.');$('manual-label').focus();return;}
    if(d.status==='confirmed' && row.kind!=='species'){toast('Ce contact ne possède aucune suggestion d’espèce à confirmer. Attribuez-lui une étiquette.');return;}
    state.undo.push({id:row.id,previous:state.reviews[row.id] || null});
    state.reviews[row.id]={...d,label:d.status==='confirmed'?row.autoId:d.status==='noise'?'Noise':d.label.trim(),timestamp:new Date().toISOString()};delete state.drafts[row.id];
    recalculate();const next=visibleRows().find(r=>assignment(r).requiresReview);
    if(state.autoNext && next) {state.selected=next.id;const remaining=visibleRows();state.page=Math.floor(Math.max(0,remaining.findIndex(r=>r.id===next.id))/PAGE_SIZE);}
    render();persist();toast(d.status==='uncertain'?'Identification incertaine enregistrée. Les attributions par les règles sont suspendues pour ce groupe.':'Décision enregistrée. Les totaux et les vérifications restantes ont été recalculés.');
  }
  function undo() {const item=state.undo.pop();if(!item) return;if(item.previous) state.reviews[item.id]=item.previous;else delete state.reviews[item.id];delete state.drafts[item.id];state.selected=item.id;render();persist();toast('Dernier enregistrement annulé.');}
  function selectRow(id) {state.selected=id;renderQueue();renderDetail();}
  function filterChanged() {state.page=0;const rows=visibleRows();if(!rows.some(r=>r.id===state.selected)) state.selected=rows[0]?.id || null;render();}
  const sidecarHeaders=['SOURCE ROW','INDIR','FOLDER','IN FILE','CHANNEL','OFFSET','DATE','TIME','NIGHT','AUTO ID','ORIGINAL MANUAL ID','REVIEW STATUS','REVIEW LABEL','REVIEWER','REVIEWED AT','NOTES','GROUP RANK','REFERENCE PICK','MATCHING','PULSES','MATCH RATIO','MARGIN','DATA ISSUES','ASSIGNED LABEL','ASSIGNMENT ORIGIN','ASSIGNMENT STATUS','REQUIRED MANUAL CHECK','CHECK ROLE','ASSIGNMENT REASON','CLASSIFICATION POLICY'];
  function sidecarRecord(row) {const rev=review(row);const a=assignment(row);return [row.index+1,state.data.columns.indir>=0?row.raw[state.data.columns.indir]:'',row.rawFolder || '',row.file,row.channel,row.offset,row.date,row.time,row.night,row.autoId,row.manualId,rev.status,rev.label,rev.reviewer,rev.timestamp,rev.notes,row.rank,row.isAnchor?'yes':'no',row.matching??'',row.pulses??'',row.ratio??'',row.margin??'',row.issues.join(' | '),a.label,a.origin,a.status,a.requiresReview?'yes':'no',a.role,a.reason || a.reasons.join(' | '),JSON.stringify(state.policy)];}
  // Spreadsheet-safe text in sidecars; source CSV values must remain unchanged.
  const safe = value => /^[\t\r\n ]*[=+@-]/.test(String(value)) ? "'"+value : value;
  function exportSidecar(pending=false) {recalculate();const rows=pending?state.data.rows.filter(r=>assignment(r).requiresReview):state.data.rows;download(baseName()+(pending?'-verifications-obligatoires.csv':'-journal-verification.csv'),'\ufeff'+C.stringifyCSV(sidecarHeaders,rows.map(r=>sidecarRecord(r).map(safe)),','),'text/csv;charset=utf-8');}
  function exportSummary() {
    if(!state.data)return;recalculate();const c=state.classification;const complete=c.metrics.required===0 && c.metrics.waiting===0;
    const headers=['LIBELLÉ','CATÉGORIE','CONTACTS VÉRIFIÉS MANUELLEMENT','CONTACTS ATTRIBUÉS PAR LES RÈGLES','TOTAL DES CONTACTS','FICHIER SOURCE','VÉRIFICATIONS TERMINÉES','RÈGLES','DATE DE GÉNÉRATION'];
    const categories={taxon:'taxon',noise:'bruit',uncertain:'incertain',unresolved:'non résolu',pending:'en attente'};
    const time=new Date().toISOString();const records=c.summary.map(s=>[outcomeLabel(s.label),categories[s.category],s.manual,s.inferred,s.total,state.source.name,complete?'oui':'non',JSON.stringify(state.policy),time].map(safe));
    download(baseName()+'-synthese-especes.csv','\ufeff'+C.stringifyCSV(headers,records,','),'text/csv;charset=utf-8');
  }
  function exportClassified() {
    recalculate();const metadata=['PLECOTUS SOURCE ROW','PLECOTUS ASSIGNED LABEL','PLECOTUS ORIGIN','PLECOTUS STATUS','PLECOTUS CHECK REQUIRED','PLECOTUS CHECK ROLE','PLECOTUS REASON','PLECOTUS POLICY'];
    const headers=[...state.parsed.headers];metadata.forEach(name=>{let unique=name;while(headers.some(h=>h.toUpperCase()===unique.toUpperCase()))unique+=' (new)';headers.push(unique);});
    const records=state.data.rows.map(row=>{const a=assignment(row);return [...row.raw,...[row.index+1,a.label,a.origin,a.status,a.requiresReview?'yes':'no',a.role,a.reason || a.reasons.join(' | '),JSON.stringify(state.policy)].map(safe)];});
    download(baseName()+'-contacts-classes.csv','\ufeff'+C.stringifyCSV(headers,records,state.parsed.delimiter),'text/csv;charset=utf-8');
  }
  function putPolicyInForm(policy) {
    $('policy-preset').value=policy.preset || 'custom';$('policy-matching').value=policy.minMatching;$('policy-ratio').value=Number((policy.minRatio*100).toFixed(2));$('policy-audit').value=policy.auditPercent;$('policy-minimum').value=policy.auditMinimum;$('policy-species').checked=policy.enableSpecies;$('policy-noise').checked=policy.enableNoise;
  }
  function readPolicyForm() {
    return A.normalizePolicy({preset:$('policy-preset').value,minMatching:Number($('policy-matching').value),minRatio:Number($('policy-ratio').value)/100,auditPercent:Number($('policy-audit').value),auditMinimum:Number($('policy-minimum').value),enableSpecies:$('policy-species').checked,enableNoise:$('policy-noise').checked});
  }
  function previewPolicy() {
    if(!$('rules-form').checkValidity()){$('policy-preview').textContent='Saisissez des valeurs valides pour afficher l’effet de ces règles.';return;}
    try{const policy=readPolicyForm();if(!state.data){$('policy-preview').textContent='Ces règles seront appliquées lors de l’import d’un CSV.';return;}const m=A.classify(state.data,state.reviews,policy,state.drafts).metrics;$('policy-preview').textContent=`Avec ces règles : ${m.required} vérifications obligatoires · ${m.waiting} contacts en attente des contrôles · ${m.inferred} attribués par les règles · ${m.manual} vérifiés manuellement.`;}catch(e){$('policy-preview').textContent=e.message;}
  }
  function exportID() {
    const headers=[...state.parsed.headers];let col=state.data.columns.manualId;if(col<0){col=headers.length;headers.push('MANUAL ID');}
    const records=state.data.rows.map(row=>{const raw=[...row.raw];while(raw.length<headers.length)raw.push('');const rev=review(row);if(checked(rev.status))raw[col]=rev.label;return raw;});
    download(baseName()+'-etiquettes-manuelles.csv','\ufeff'+C.stringifyCSV(headers,records,state.parsed.delimiter),'text/csv;charset=utf-8');toast('CSV des étiquettes manuelles exporté. Conservez l’original et vérifiez cette copie dans Kaleidoscope.');
  }
  function demo() {
    const headers=['INDIR','FOLDER','IN FILE','CHANNEL','OFFSET','DURATION','DATE','TIME','DATE-12','AUTO ID','PULSES','MATCHING','MATCH RATIO','MARGIN','ALTERNATE 1','ALTERNATE 2','MANUAL ID','Fc','Sc','Dur','Fmax','Fmin','Qual'];
    const specs=[];
    for(let i=0;i<24;i++){const p=40-i%20;specs.push(['PIPPIP',p,p-1,Number(((p-1)/p).toFixed(6)),2-i*.02,'']);}
    for(let i=0;i<10;i++){const p=18+i%5;specs.push(['PIPNAT',p,p-1,Number(((p-1)/p).toFixed(6)),1.5+i*.03,'']);}
    specs.push(['MYODAU',14,9,.642857,.8,'MYOMYS'],['MYODAU',4,2,.5,.3,''],['MYODAU',8,5,.625,.6,''],['PIPPIP',3,3,1,.5,'PIPNAT']);
    for(let i=0;i<4;i++)specs.push(['NoID',8+i,0,0,0,'']);
    for(let i=0;i<10;i++)specs.push(['Noise',0,0,'',0,'']);
    specs.push(['Noise',2,0,0,0,''],['',5,'','','','']);
    const records=specs.map(([id,p,m,r,margin,alt],i)=>['C:\\BatSurvey\\Example','site-A',`REC_${String(i+1).padStart(4,'0')}_20260918_21${String(i).padStart(2,'0')}00.wav`,0,0,5,'2026-09-18',`21:${String(i).padStart(2,'0')}:00`,'2026-09-18',id,p,m,r,margin,alt,'',i===35?'Myotis sp.':'',id==='PIPPIP'?45.2:'',.5,3.2,72,41,8]);
    acceptSource({name:'example-id.csv',text:C.stringifyCSV(headers,records,',')});toast('Exemple fictif chargé. Ces chiffres illustrent le fonctionnement ; ils ne proviennent pas d’enregistrements réels.');
  }
  $('upload').onclick=$('welcome-import').onclick=()=>requestOpen(()=>$('csv-file').click());
  $('csv-file').onchange=e=>loadCSV(e.target.files[0]);$('project-file').onchange=e=>loadProject(e.target.files[0]);
  $('open-project').onclick=()=>requestOpen(()=>$('project-file').click());
  $('load-demo').onclick=$('welcome-demo').onclick=()=>requestOpen(demo);
  $('save-project').onclick=saveProject;$('method').onclick=()=>$('guide-dialog').showModal();
  $('rules').onclick=()=>{putPolicyInForm(state.policy);previewPolicy();$('rules-dialog').showModal();};
  $('policy-preset').onchange=()=>{if($('policy-preset').value!=='custom')putPolicyInForm(A.normalizePolicy({preset:$('policy-preset').value}));previewPolicy();};
  ['policy-matching','policy-ratio','policy-audit','policy-minimum','policy-species','policy-noise'].forEach(id=>$(id).oninput=()=>{$('policy-preset').value='custom';previewPolicy();});
  $('rules-form').onsubmit=e=>{e.preventDefault();if(!$('rules-form').reportValidity())return;try{state.policy=readPolicyForm();$('rules-dialog').close();if(state.data){recalculate();filterChanged();persist();}toast('Règles appliquées. Les décisions manuelles sont conservées ; les attributions par les règles et les vérifications obligatoires ont été recalculées.');}catch(error){toast(error.message);}};
  $('export').onclick=()=>{recalculate();const m=state.classification.metrics;const drafts=Object.keys(state.drafts).length;$('export-caption').textContent=`${m.manual} vérifiés manuellement · ${m.inferred} attribués par les règles · ${m.required} vérifications obligatoires restantes · ${m.waiting} en attente des contrôles.${drafts?' '+drafts+' brouillons non terminés ne sont pas des décisions validées.':''}`;$('export-dialog').showModal();};
  $('export-id').onclick=exportID;$('export-audit').onclick=()=>exportSidecar();$('export-pending').onclick=()=>exportSidecar(true);$('export-summary').onclick=$('summary-export').onclick=exportSummary;$('export-classified').onclick=exportClassified;
  document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$(b.dataset.close).close());
  $('cancel-replace').onclick=()=>{pendingOpen=null;$('replace-dialog').close();};
  function continueOpen(backup){if(backup)saveProject();const fn=pendingOpen;pendingOpen=null;$('replace-dialog').close();fn?.();}
  $('backup-replace').onclick=()=>continueOpen(true);$('continue-replace').onclick=()=>continueOpen(false);
  document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;filterChanged();});
  $('species-list').onclick=e=>{const button=e.target.closest('[data-species]');if(button){state.species=button.dataset.species;filterChanged();}};
  $('all-groups').onclick=()=>{state.species='';filterChanged();};
  $('search').oninput=e=>{state.search=e.target.value;filterChanged();};$('sort').onchange=e=>{state.sort=e.target.value;filterChanged();};
  $('queue-body').onclick=e=>{const row=e.target.closest('[data-row]');if(row)selectRow(row.dataset.row);};
  $('prev-page').onclick=()=>{state.page--;renderQueue();};$('next-page').onclick=()=>{state.page++;renderQueue();};
  document.addEventListener('keydown',e=>{
    if(!state.data || document.querySelector('dialog[open]'))return;
    if(e.ctrlKey && e.key==='Enter'){e.preventDefault();saveDecision();return;}
    if(e.ctrlKey||e.altKey||e.metaKey||['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))return;
    if(e.key.toLowerCase()==='j'||e.key.toLowerCase()==='k'){const rows=visibleRows();const at=rows.findIndex(r=>r.id===state.selected);const next=rows[at+(e.key.toLowerCase()==='j'?1:-1)];if(next){e.preventDefault();state.page=Math.floor(rows.indexOf(next)/PAGE_SIZE);selectRow(next.id);}}
  });
  window.addEventListener('pagehide',()=>{clearTimeout(saveTimer);if(state.source)persist();});
  try{const saved=localStorage.getItem(STORAGE);if(saved){const p=JSON.parse(saved);if(p.format==='plecotus-review'&&[1,2].includes(p.version)){acceptSource(p.source,p);toast('Projet local restauré. Les attributions ont été recalculées selon ses règles enregistrées.');}}}catch(error){$('save-status').textContent='Restauration depuis le navigateur indisponible';}
})();
