# Classification des contacts de chauves-souris : méthode du prototype

L'objectif est **un nombre de contacts par espèce pour des enregistrements réalisés en Belgique**, avec une étiquette pour chaque contact et un sous-ensemble obligatoirement examiné à la main. L'outil combine les suggestions `AUTO-ID` existantes de Kaleidoscope, des règles d'admissibilité réglables et des contrôles manuels par échantillonnage. Il n'analyse pas les sons et n'identifie pas une espèce indépendamment à partir des mesures du CSV. Chaque résultat conserve une provenance explicite : manuel, déduit par les règles, en attente ou non résolu.

L'interface et cette documentation sont en français. Les noms de champs source, les codes `AUTO-ID` et le texte des étiquettes importées restent inchangés. Les colonnes du bilan destiné à l'utilisateur sont traduites ; les catégories internes et les données techniques des exports sont conservées pour maintenir leur compatibilité.

## Ce que fournit Kaleidoscope

Kaleidoscope Lite est gratuit et permet la visualisation des spectrogrammes, les mesures, les étiquettes manuelles, la conversion et le filtrage du bruit pour les chauves-souris. La production de nouvelles identifications automatiques d'espèces nécessite Pro. Un CSV Auto-ID existant peut servir à cette procédure de validation ; l'outil ne produit pas et ne remplace pas le classificateur Pro. Voir le [comparatif officiel des fonctionnalités](https://www.wildlifeacoustics.com/products/kaleidoscope-pro).

Pour la Belgique, vérifiez que l'analyse automatique en amont utilisait le classificateur européen et une sélection adaptée de région et d'espèces. Conservez la version du classificateur et les paramètres de traitement, idéalement le `settings.ini` original. La [liste officielle des codes d'espèces européens](https://answers.wildlifeacoustics.com/r/en-US/Bat-Auto-ID-Performance-and-Supported-Species/Bat-Auto-ID-Supported-Species-and-Abbreviated-Codes) décrit les espèces couvertes ; figurer dans cette liste ne prouve pas la présence de l'espèce au lieu d'enregistrement.

Un contact dans `id.csv` peut représenter un enregistrement entier **ou un segment**. Un nom de fichier n'est donc pas un identifiant unique de contact : le canal et le décalage comptent aussi. L'outil conserve chaque ligne source séparément, y compris les repères d'enregistrements répétés. Les mesures par passage à zéro résument les cris détectés ; elles ne décrivent pas tous les détails visibles sur un spectrogramme en spectre complet. Ces caractéristiques officielles du format sont décrites dans le [guide utilisateur de 2025](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope03192025.pdf).

## Classement : l'ordre de contrôle proposé

La première version regroupe les contacts par **répertoire d'entrée + dossier + nuit + AUTO-ID suggéré**. Elle utilise `DATE-12` pour définir la nuit, puis `DATE` si ce champ manque. Une date absente crée un groupe explicitement associé à une nuit inconnue. Le dossier représente concrètement un déploiement ; il doit contenir un seul site/déploiement si leur séparation est importante. Ce regroupement est un choix de procédure, et non une règle d'identification de Kaleidoscope. Utiliser `DATE` peut diviser une nuit à minuit ; l'outil signale ce repli.

Dans chaque groupe, les clés suivantes sont comparées dans l'ordre :

1. `MATCHING`, décroissant.
2. `MATCH RATIO`, décroissant.
3. `MARGIN`, décroissant.
4. Numéro de ligne source, croissant, pour départager les égalités de manière reproductible.

La première clé différente décide de l'ordre ; il ne s'agit pas d'un score pondéré. Le tri historique de Kaleidoscope utilisait l'`AUTO-ID`, puis le nombre de cris correspondants et le ratio de correspondance décroissants ([guide officiel 4.3.1, p. 50](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope.pdf)). Les groupes par nuit/dossier et les critères de départage par marge et ligne source sont nos ajouts. Les marges sont comparées uniquement au sein d'une même espèce suggérée.

Le premier contact d'espèce d'un groupe est un **contact de référence** : un enregistrement utile à examiner tôt pour établir une référence visuelle. Son rang indique les éléments les plus forts selon ces champs, sans garantir une identification correcte ni la meilleure qualité acoustique. Par exemple, 20 cris correspondants sur 40 passent avant 2 sur 2. Le premier présente davantage de cris favorables, mais peut contenir plusieurs chauves-souris ; examinez aussi son ratio et ses alternatives.

Les champs numériques manquants sont placés après les valeurs exploitables ; les clés suivantes restent applicables. Un ratio absent peut être calculé pour le classement si les deux nombres sont exploitables, si `PULSES` est positif et si `MATCHING` ne le dépasse pas. La cellule source reste inchangée. Les valeurs mal formées et les nombres incohérents sont signalés. Aucun nombre de cris, seuil de ratio, seuil de marge ou pourcentage de confiance universel n'est affirmé.

## Dictionnaire des champs

Les en-têtes varient selon la version de Kaleidoscope et le MetaForm de l'utilisateur. L'outil reconnaît les variantes courantes, conserve les colonnes originales et affiche les champs supplémentaires sans les interpréter. Les tableaux suivants décrivent les champs courants d'`id.csv`, sans prétendre couvrir tous les champs personnalisables du schéma.

**Emplacement et temps** — définitions officielles du [guide utilisateur de 2025](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope03192025.pdf). Ces champs servent à retrouver et regrouper les contacts ; aucun n'est un score de confiance.

| Champ | Signification |
|---|---|
| `INDIR`, `OUTDIR` | Chemins racines d'entrée et de sortie |
| `FOLDER` | Sous-dossier d'entrée relatif à la racine |
| `IN FILE` | Nom du fichier d'entrée |
| `CHANNEL` | Canal d'entrée ; 0 à gauche, 1 à droite |
| `OFFSET` | Début du segment, en secondes depuis le début du fichier |
| `DURATION` | Durée du fichier ou du segment, en secondes |
| `OUT FILE FS`, `OUT FILE ZC` | Nom du fichier de sortie en spectre complet ou par passage à zéro |
| `DATE`, `TIME`, `HOUR` | Date, heure et heure entière de l'enregistrement |
| `DATE-12`, `TIME-12`, `HOUR-12` | Horodatage de l'enregistrement décalé de 12 heures en arrière |

**Identification et mesures des cris** — définitions du [guide officiel historique, p. 19–22](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope.pdf) et de la [spécification des métadonnées Wildlife Acoustics](https://www.wildlifeacoustics.com/SCHEMA/GUANO.html). Le sens du classement décrit notre implémentation, sauf lorsqu'une interprétation officielle est indiquée.

| Champ | Signification | Utilisation pour le contrôle |
|---|---|---|
| `AUTO-ID` / `AUTO ID` | Espèce suggérée pour le fichier | Groupe et étiquette proposée pour l'attribution par les règles |
| `PULSES` | Nombre de cris utilisé dans le résumé du classificateur | Contexte ; dénominateur du ratio |
| `MATCHING` | Cris favorables à l'`AUTO-ID` | Décroissant |
| `MATCH RATIO` | `MATCHING` divisé par `PULSES` | Décroissant |
| `MARGIN` | Indicateur de confiance non calibré | Décroissant au sein d'une même espèce uniquement |
| `ALTERNATE 1`, `ALTERNATE 2`, ancien `ALTERNATES` | Autres candidats ; plusieurs chauves-souris possibles | Examiner l'ambiguïté |
| `N` | Cris détectés utilisés pour les moyennes | Contexte |
| `Fc` | Fréquence caractéristique, en kHz | Forme du cri |
| `Sc` | Pente du corps du cri, en octaves/seconde | Forme du cri |
| `Dur` | Durée moyenne d'un cri, en ms | Forme du cri |
| `Fmax`, `Fmin` | Moyennes des fréquences maximale et minimale des cris, en kHz | Forme du cri |
| `Fmean` | Moyenne de la fréquence des cris pondérée par le temps, en kHz | Forme du cri |
| `TBC` | Intervalle moyen entre les débuts des cris, en ms | Séquence de cris |
| `Fk`, `Tk` | Fréquence du coude, en kHz, et temps correspondant, en ms | Forme du cri |
| `S1` | Pente initiale, en octaves/seconde | Forme du cri |
| `Tc` | Temps jusqu'au point caractéristique | Forme du cri ; vérifier l'unité |
| `Qual` | Mesure de régularité du cri | Une valeur faible signifie un cri plus régulier ; inutilisé pour le classement |
| `FILES` | Constante 1 destinée au comptage | Comptage uniquement |
| `MANUAL ID` | Identification attribuée par une personne | Conserver et vérifier |

La fréquence, la durée, la pente et les temps n'ont **aucun sens universel « meilleur »**. Ils varient selon l'espèce et le comportement vocal. `Qual` n'est pas une probabilité, en pourcentage, d'identification correcte. `DURATION` et `Dur` décrivent des objets différents.

Les guides décrivent `PULSES` tantôt comme tous les cris détectés exploitables, tantôt comme les cris classés par espèce ; `N` désigne explicitement le nombre total de détections. Ne supposez pas leur égalité. Les anciens documents CSV/métadonnées indiquent `Tc` en millisecondes, alors que des libellés de schémas de base de données plus récents peuvent utiliser les secondes. Conservez l'en-tête et la valeur ; vérifiez les unités avant comparaison. Ces différences expliquent pourquoi la première version ne construit pas de scores supplémentaires à partir des moyennes acoustiques.

**Autres métadonnées courantes** — [définitions officielles des métadonnées](https://www.wildlifeacoustics.com/SCHEMA/GUANO.html). Elles documentent la provenance ou le contexte de l'enregistrement ; aucune n'influence le classement.

| Champs / variantes | Signification |
|---|---|
| `LAT`, `LON`, `LATITUDE`, `LONGITUDE` | Coordonnées de l'enregistrement |
| `MODEL`, `SERIAL`, `FIRMWARE`, `PREFIX` | Modèle, numéro de série, micrologiciel et préfixe de fichier de l'enregistreur |
| `NOTES` / `NOTE` | Notes libres sur l'enregistrement |
| `ORGID`, `USERID` | Organisation et utilisateur source |
| `REVIEW ORGID`, `REVIEW USERID` | Organisation et utilisateur chargés du contrôle |
| `INPATHMD5` | Empreinte interne de recherche du chemin d'entrée |
| Champs du classificateur, de version et de paramètres | Provenance de l'analyse en amont |

## Règles d'attribution réglables

Le bouton de l'interface propose des préréglages et des seuils modifiables. Ce sont des **règles empiriques initiales non validées**, et non des probabilités de confiance, des recommandations du fabricant ou des taux d'erreur mesurés. Des réglages plus permissifs réduisent généralement le travail manuel et permettent davantage d'attributions par les règles. Commencez prudemment et calibrez avec de vrais enregistrements.

| Préréglage | `MATCHING` minimal | `MATCH RATIO` minimal | Pourcentage de contrôle | Nombre minimal de contacts de contrôle |
|---|---:|---:|---:|---:|
| Prudent | 8 | 0,90 | 20 % | 5 |
| Équilibré | 5 | 0,80 | 10 % | 3 |
| Rapide | 3 | 0,70 | 5 % | 2 |

Les candidats d'espèces doivent atteindre les deux seuils. Les mesures absentes ou contradictoires, les alternatives ambiguës, les repères de fichier ou de nuit absents, les repères répétés et les étiquettes manuelles importées empêchent l'attribution automatique de ces contacts. Cette règle évite de deviner les étiquettes de lignes incomplètes ou contradictoires. Les `NoID` et les suggestions d'espèces plus faibles nécessitent des décisions manuelles individuelles.

Chaque groupe espèce/dossier/nuit nécessite son contact de référence classé en premier **et** un contrôle des contacts admissibles hors référence. La taille du contrôle est le maximum entre le nombre minimal de contacts et le pourcentage du sous-ensemble admissible, arrondi à l'entier supérieur, sans dépasser le nombre de contacts disponibles. Le contrôle combine des contacts admissibles parmi les moins forts et une sélection pseudo-aléatoire reproductible ; un nouveau tirage n'est pas réalisé à chaque ouverture. Les petits groupes peuvent donc nécessiter une vérification complète. Tant que les contrôles requis sont en attente, les autres candidats attendent. Ce n'est que lorsque chaque contrôle requis confirme l'espèce suggérée que les contacts admissibles restants reçoivent cet `AUTO-ID` comme étiquette **déduite par les règles**. Une étiquette manuelle différente, une décision de bruit ou une incertitude à n'importe quel endroit du groupe annule ses attributions et envoie les contacts restants en validation manuelle. Un seul contact de référence confirmé ne suffit pas à libérer un grand groupe.

Le contrôle du bruit par échantillonnage dispose d'un interrupteur distinct. Lorsqu'il est activé, seules les lignes `Noise` dont `PULSES` vaut explicitement zéro peuvent être admissibles, sous réserve de données valides et d'un périmètre d'enregistrement défini. Si une colonne `N` existe, elle doit aussi valoir explicitement zéro. Un échantillon obligatoire par dossier/nuit doit confirmer le bruit avant que les autres lignes admissibles puissent recevoir une exclusion déduite comme bruit. Des nombres de cris absents, invalides ou positifs imposent un contrôle individuel. Désactiver cet échantillonnage envoie toutes les lignes `Noise` en validation manuelle. Zéro cri détecté ou classé **ne prouve pas qu'aucune chauve-souris n'était présente** : les paramètres de détection peuvent rejeter de vrais cris. Une étiquette de bruit déduite constitue une exclusion selon ces règles, et non une observation d'absence vérifiée ([guide 2024, p. 39](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope11112024.pdf)).

Modifier les règles recalcule l'admissibilité, les échantillons, les étiquettes déduites et les totaux. Les décisions manuelles sont conservées ; une ligne auparavant attribuée par les règles peut revenir dans la file obligatoire. Enregistrer un projet conserve les règles et le travail manuel ; les résultats déduits sont recalculés à la réouverture.

## Contrôles manuels obligatoires

La file indique les contacts de référence et de contrôle requis, ainsi que les contacts exclus de l'attribution par les règles. Pour le contact sélectionné, retrouvez le nom de fichier, le canal et le décalage dans Kaleidoscope, puis examinez le spectrogramme, l'écoute et les mesures. Confirmez la suggestion uniquement si les éléments la soutiennent, ou saisissez une espèce/un groupe corrigé. Utilisez `Myotis sp.` ou un résultat de chauve-souris non identifiée lorsqu'une espèce ne peut pas être justifiée. Enregistrez le bruit uniquement après examen ; documentez les enregistrements mixtes ou ambigus dans les notes. Les étiquettes manuelles importées sont conservées, mais doivent être vérifiées dans ce projet.

Vérifier chaque `NoID` reste approprié : `NoID` signifie que la classification a échoué, et non que les chauves-souris sont absentes. Le bruit est conservé et contrôlé par échantillonnage ou vérifié manuellement. Chaque ligne est conservée, y compris les repères d'enregistrements répétés ; l'outil ne supprime jamais silencieusement des contacts.

Wildlife Acoustics recommande la vérification manuelle des identifications suggérées ([conseils Auto-ID](https://www.wildlifeacoustics.com/products/kaleidoscope/automatic-bat-identification)). Ses tests publiés excluent les enregistrements de mauvaise qualité, ambigus ou comportant plusieurs chauves-souris simultanées et peuvent surestimer les performances pour de telles données de terrain ([limites](https://answers.wildlifeacoustics.com/r/en-US/Bat-Auto-ID-Performance-and-Supported-Species/About-the-Kaleidoscope-Classifier-Performance-Table)). Notre déduction par échantillonnage est une procédure propre au projet pour réduire l'effort de contrôle ; elle ne transforme pas les contacts non examinés en contacts vérifiés manuellement et n'établit pas de taux d'erreur certifié. Des erreurs systématiques répétées peuvent échapper à un échantillon.

Avant de vous fier aux nombres de contacts par espèce déduits par les règles, validez-les sur un sous-ensemble des déploiements réels, identifié indépendamment par un expert contact par contact, incluant des enregistrements faibles, ambigus et classés comme bruit. Comparez les erreurs par espèce et les vrais contacts de chauves-souris exclus, puis adaptez les règles au taux d'erreur acceptable pour l'étude. La version installée, le classificateur et ses paramètres en amont, ainsi que le véritable CSV, n'ont pas encore été fournis. Une calibration reste nécessaire.

## Bilan et traçabilité

Le bilan par espèce indique **contacts manuels + contacts déduits = total des contacts attribués** pour chaque étiquette. Le bruit, les résultats en attente et les identifications non résolues sont séparés ; les résultats en attente incluent les contacts obligatoires actuellement et les candidats attendant les contrôles de leur groupe. Les nombres sont provisoires tant que des contrôles obligatoires restent à réaliser. Terminer la file termine cette procédure, mais les lignes déduites conservent cette provenance et les identifications incertaines restent non résolues. La catégorie d'export `taxon` couvre les espèces et les étiquettes de genre/groupe ; leur texte exact est conservé sans supposer un niveau de précision. Chaque ligne source contribue une seule fois au bilan ; celui-ci n'estime pas le nombre de chauves-souris individuelles et ne répartit pas un enregistrement mixte entre plusieurs espèces.

Gardez l'`AUTO-ID`, la décision manuelle et le résultat déduit distincts. Le CSV destiné à Kaleidoscope écrit uniquement les décisions manuelles enregistrées dans `MANUAL ID`. L'export distinct des contacts classés contient les étiquettes calculées, les statuts, les raisons et les règles ; l'export du bilan conserve la séparation entre nombres manuels et déduits. Conservez le journal des contrôles et la sauvegarde du projet avec ces exports. Un rang, une identification de groupe et une espèce vérifiée constituent des éléments de preuve différents.

## Sources primaires

Toutes les sources ont été vérifiées le 10 octobre 2026. Les liens ci-dessus renvoient aux publications de Wildlife Acoustics :

- [Fonctionnalités de Kaleidoscope](https://www.wildlifeacoustics.com/products/kaleidoscope-pro).
- [Guide utilisateur Kaleidoscope du 19 mars 2025](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope03192025.pdf).
- [Guide utilisateur Kaleidoscope Pro du 11 novembre 2024](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope11112024.pdf).
- [Documentation Kaleidoscope 4.3.1 de 2017](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope.pdf), pour le tri historique et les définitions des champs.
- [Spécification des métadonnées GUANO de Wildlife Acoustics](https://www.wildlifeacoustics.com/SCHEMA/GUANO.html).
- [Espèces prises en charge et codes abrégés](https://answers.wildlifeacoustics.com/r/en-US/Bat-Auto-ID-Performance-and-Supported-Species/Bat-Auto-ID-Supported-Species-and-Abbreviated-Codes).
- [Conseils sur l'identification automatique des chauves-souris](https://www.wildlifeacoustics.com/products/kaleidoscope/automatic-bat-identification).
- [Interprétation et limites du tableau de performances du classificateur](https://answers.wildlifeacoustics.com/r/en-US/Bat-Auto-ID-Performance-and-Supported-Species/About-the-Kaleidoscope-Classifier-Performance-Table).
