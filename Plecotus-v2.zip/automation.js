(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BatClassification = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  // These are workflow heuristics, not estimated identification accuracy.
  const VERSION = 1;
  const presets = Object.freeze({
    cautious: Object.freeze({ minMatching: 8, minRatio: 0.9, auditPercent: 20, auditMinimum: 5 }),
    balanced: Object.freeze({ minMatching: 5, minRatio: 0.8, auditPercent: 10, auditMinimum: 3 }),
    faster: Object.freeze({ minMatching: 3, minRatio: 0.7, auditPercent: 5, auditMinimum: 2 })
  });
  const MANUAL = new Set(['confirmed', 'corrected', 'uncertain', 'noise']);
  const identity = value => String(value == null ? '' : value).trim().replace(/\s+/g, ' ').toUpperCase();
  const headerIdentity = value => identity(value).replace(/[^A-Z0-9]/g, '');
  const specialIdentity = value => identity(value).replace(/[\s_-]+/g, '');

  function normalizePolicy(input) {
    if (typeof input === 'string') input = { preset: input };
    const source = input == null ? {} : input;
    if (typeof source !== 'object' || Array.isArray(source)) throw new TypeError('Les règles de classification doivent être un objet.');
    const preset = source.preset || 'cautious';
    if (!presets[preset] && preset !== 'custom') throw new Error('Choisissez le mode prudent, équilibré, rapide ou personnalisé.');
    if (source.version != null && source.version !== VERSION) throw new Error('Version des règles de classification non prise en charge.');
    const defaults = presets[preset] || presets.cautious;
    const policy = { version: VERSION, preset, enableSpecies: true, enableNoise: true };
    for (const name of ['enableSpecies', 'enableNoise']) {
      if (source[name] != null) {
        if (typeof source[name] !== 'boolean') throw new Error((name === 'enableSpecies' ? 'L’attribution automatique des espèces' : 'L’attribution automatique du bruit') + ' doit être activée ou désactivée.');
        policy[name] = source[name];
      }
    }
    for (const [name, minimum, maximum, integer] of [
      ['minMatching', 1, 1000000, true], ['minRatio', 0, 1, false],
      ['auditPercent', 0, 100, false], ['auditMinimum', 1, 1000000, true]
    ]) {
      const value = source[name] == null ? defaults[name] : source[name];
      if (typeof value !== 'number' || !Number.isFinite(value) || value < minimum || value > maximum || (integer && !Number.isInteger(value))) {
        const label = { minMatching: 'Le seuil MATCHING', minRatio: 'Le seuil MATCH RATIO', auditPercent: 'Le pourcentage de contrôle', auditMinimum: 'Le nombre minimum de contrôles' }[name];
        throw new Error(label + ' doit être ' + (integer ? 'un entier' : 'un nombre') + ' entre ' + minimum + ' et ' + maximum + '.');
      }
      policy[name] = value;
    }
    return policy;
  }

  function savedDecision(review) {
    if (!review || !MANUAL.has(review.status) || typeof review.label !== 'string' || !review.label.trim()) return null;
    if (review.status === 'noise' && specialIdentity(review.label) !== 'NOISE') return null;
    return review;
  }
  function valueAt(collection, id) {
    return collection instanceof Map ? collection.get(id) : collection && collection[id];
  }
  function agreed(decision, label) {
    return Boolean(decision && decision.status !== 'uncertain' && identity(decision.label) === identity(label));
  }

  function validDate(value) {
    const text = String(value || '').trim();
    let match = /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/.exec(text);
    if (!match) match = /^(\d{4})(\d{2})(\d{2})$/.exec(text);
    if (match) return calendarDate(Number(match[1]), Number(match[2]), Number(match[3]));
    // Grouping retains the exact source date. For slash/dash dates with the year
    // last, accept a real calendar date in either exporter convention.
    match = /^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/.exec(text);
    return Boolean(match && (calendarDate(Number(match[3]), Number(match[1]), Number(match[2])) || calendarDate(Number(match[3]), Number(match[2]), Number(match[1]))));
  }
  function calendarDate(year, month, day) {
    if (year < 1900 || year > 2200 || month < 1 || month > 12 || day < 1) return false;
    const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    return day <= [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  }
  function numericLocator(value, integer) {
    const text = String(value == null ? '' : value).trim().replace(',', '.');
    if (!/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(text)) return false;
    const number = Number(text);
    return Number.isFinite(number) && number >= 0 && (!integer || Number.isInteger(number));
  }
  function locatorReasons(row, columns) {
    const reasons = [];
    if (!String(row.file || '').trim()) reasons.push('Nom du fichier d’enregistrement manquant.');
    if (!validDate(row.night)) reasons.push('Nuit/date d’enregistrement manquante ou invalide.');
    for (const name of ['date', 'date12']) {
      if (String(row[name] || '').trim() && !validDate(row[name])) reasons.push((name === 'date12' ? 'DATE-12' : 'DATE') + ' invalide.');
    }
    for (const name of ['offset', 'channel']) {
      if (columns[name] >= 0 && !numericLocator(row[name], name === 'channel')) reasons.push(name.toUpperCase() + ' manquant ou invalide dans le repère d’enregistrement.');
    }
    for (const issue of row.issues || []) {
      // Accept both current French issues and older analyzed English records.
      if (/repère|fichier d’enregistrement|nuit\/date|DATE-12|MATCH RATIO diffère|MATCHING dépasse|locator|filename|night\/date|MATCH RATIO differs|MATCHING exceeds/i.test(String(issue))) reasons.push(String(issue));
    }
    return [...new Set(reasons)];
  }
  function alternateReasons(row, legacyColumns) {
    const alternatives = [row.alternate1, row.alternate2];
    for (const index of legacyColumns) alternatives.push((row.raw || [])[index]);
    const labels = alternatives.flatMap(value => String(value || '').split(/[,;|\r\n]+/)).map(value => value.trim()).filter(Boolean);
    return labels.some(label => identity(label) !== identity(row.autoId)) ? ['Identification alternative différente ; vérifiez l’ambiguïté ou la présence de plusieurs chauves-souris.'] : [];
  }
  function eligibility(row, decision, policy, columns, legacyColumns, nColumns) {
    const reasons = [...locatorReasons(row, columns), ...alternateReasons(row, legacyColumns)];
    if (String(row.manualId || '').trim() && !decision) reasons.push('L’identification manuelle importée doit être explicitement vérifiée dans ce projet.');
    if (row.kind === 'species') {
      if (!policy.enableSpecies) reasons.push('L’attribution automatique des espèces est désactivée.');
      if (!Number.isInteger(row.pulses) || row.pulses <= 0) reasons.push('L’attribution d’une espèce par les règles exige un nombre PULSES valide et positif.');
      if (!Number.isInteger(row.matching) || row.matching < policy.minMatching) reasons.push('MATCHING est manquant, invalide ou inférieur au seuil des règles (' + policy.minMatching + ').');
      if (typeof row.ratio !== 'number' || !Number.isFinite(row.ratio) || row.ratio < policy.minRatio || row.ratio > 1) reasons.push('MATCH RATIO est manquant, invalide ou inférieur au seuil des règles (' + policy.minRatio + ').');
      if (row.matching > row.pulses) reasons.push('MATCHING dépasse PULSES.');
    } else if (row.kind === 'noise') {
      if (!policy.enableNoise) reasons.push('L’attribution automatique du bruit est désactivée.');
      if (row.pulses !== 0) reasons.push('L’attribution au bruit par les règles exige PULSES = 0 ; des impulsions détectées ou un nombre manquant imposent une vérification manuelle.');
      for (const index of nColumns) {
        const value = String((row.raw || [])[index] == null ? '' : row.raw[index]).trim();
        if (!/^\+?0+$/.test(value)) reasons.push('L’attribution au bruit par les règles exige un N = 0 explicite lorsque le total des détections est exporté ; un N positif, manquant ou invalide impose une vérification manuelle.');
      }
    } else reasons.push('Les contacts sans identification (NoID) ou non classés exigent toujours une identification manuelle.');
    return [...new Set(reasons)];
  }

  function hash(text) {
    let value = 2166136261;
    for (let index = 0; index < text.length; index++) { value ^= text.charCodeAt(index); value = Math.imul(value, 16777619); }
    return value >>> 0;
  }
  function seed(row) {
    return hash(JSON.stringify([row.groupKey, row.indir, row.rawFolder, row.file, row.channel, row.offset, row.id]));
  }
  function auditSample(candidates, policy) {
    if (!candidates.length) return [];
    const count = Math.min(candidates.length, Math.max(policy.auditMinimum, Math.ceil(candidates.length * policy.auditPercent / 100)));
    const decorated = candidates.map(row => ({ row, seed: seed(row) }));
    const numeric = value => typeof value === 'number' && Number.isFinite(value) ? value : 0;
    // Deliberately inspect the weakest eligible contact, then spread the rest
    // through deterministic hashes. Reopening never silently changes a sample.
    decorated.sort((a, b) => numeric(a.row.ratio) - numeric(b.row.ratio) || numeric(a.row.matching) - numeric(b.row.matching) || a.seed - b.seed || a.row.index - b.row.index);
    const weakest = decorated.shift();
    decorated.sort((a, b) => a.seed - b.seed || a.row.index - b.row.index);
    return [weakest.row, ...decorated.slice(0, count - 1).map(item => item.row)];
  }

  function classify(data, reviews, inputPolicy, drafts) {
    if (!data || !Array.isArray(data.rows)) throw new TypeError('La classification exige des lignes CSV analysées.');
    const policy = normalizePolicy(inputPolicy);
    const columns = data.columns || {};
    const legacyColumns = (data.headers || []).reduce((indices, header, index) => {
      if (['ALTERNATES', 'ALTERNATIVES', 'AUTOIDALTERNATES'].includes(headerIdentity(header))) indices.push(index);
      return indices;
    }, []);
    if (Number.isInteger(columns.alternates) && columns.alternates >= 0 && !legacyColumns.includes(columns.alternates)) legacyColumns.push(columns.alternates);
    const nColumns = (data.headers || []).reduce((indices, header, index) => { if (headerIdentity(header) === 'N') indices.push(index); return indices; }, []);
    const metadata = new Map((data.groups || []).map(group => [group.key, group]));
    const groupsByKey = new Map();
    const info = new Map();
    for (const row of data.rows) {
      if (!row || typeof row.id !== 'string' || info.has(row.id)) throw new Error('Chaque contact analysé doit avoir un identifiant de ligne source unique.');
      const review = valueAt(reviews, row.id);
      const decision = savedDecision(review);
      const reasons = eligibility(row, decision, policy, columns, legacyColumns, nColumns);
      if (review && MANUAL.has(review.status) && !decision) reasons.push('Décision enregistrée invalide ; vérifiez à nouveau ce contact.');
      info.set(row.id, { decision, draft: valueAt(drafts, row.id), reasons, eligible: !reasons.length });
      if (!groupsByKey.has(row.groupKey)) groupsByKey.set(row.groupKey, []);
      groupsByKey.get(row.groupKey).push(row);
    }

    const byId = new Map();
    const groups = [];
    for (const [key, rows] of groupsByKey) {
      const first = rows[0];
      const speciesGroup = first.kind === 'species';
      const noiseGroup = first.kind === 'noise';
      const enabled = speciesGroup ? policy.enableSpecies : noiseGroup ? policy.enableNoise : false;
      const ordered = rows.slice().sort((a, b) => (a.rank || Infinity) - (b.rank || Infinity) || a.index - b.index);
      const anchor = speciesGroup ? ordered.find(row => row.isAnchor) || ordered[0] : null;
      const eligible = rows.filter(row => info.get(row.id).eligible);
      const sample = enabled ? auditSample(eligible.filter(row => !anchor || row.id !== anchor.id), policy) : [];
      const auditIds = new Set(sample.map(row => row.id));
      const validation = [...(anchor && enabled ? [anchor] : []), ...sample];
      const pendingValidation = validation.filter(row => !agreed(info.get(row.id).decision, first.autoId)).map(row => row.id);
      const blockingIds = [];
      const blockReasons = [];
      if (speciesGroup || noiseGroup) {
        for (const row of rows) {
          const item = info.get(row.id);
          if (item.decision && !agreed(item.decision, first.autoId)) {
            blockingIds.push(row.id);
            blockReasons.push('Ligne ' + (row.index + 1) + ' : ' + (item.decision.status === 'uncertain' ? 'une identification manuelle incertaine' : 'une identification manuelle différente de l’AUTO-ID') + ' bloque l’attribution par les règles pour ce groupe dossier/nuit/identification.');
          } else if (!item.decision && String(row.manualId || '').trim() && identity(row.manualId) !== identity(first.autoId)) {
            blockingIds.push(row.id);
            blockReasons.push('Ligne ' + (row.index + 1) + ' : une identification manuelle importée contradictoire doit être explicitement vérifiée avant toute attribution par les règles dans ce groupe.');
          }
        }
      }
      const blocked = blockingIds.length > 0;
      const canInfer = enabled && !blocked && pendingValidation.length === 0;
      const group = {
        ...(metadata.get(key) ? { folder: metadata.get(key).folder, indir: metadata.get(key).indir, night: metadata.get(key).night } : { folder: first.folder, indir: first.indir, night: first.night }),
        key, groupKey: key, autoId: first.autoId, kind: first.kind, count: rows.length, total: rows.length,
        anchorId: anchor ? anchor.id : null, auditIds: [...auditIds], candidateIds: eligible.map(row => row.id),
        eligibleCount: eligible.length, auditCount: sample.length, enabled, blocked, groupBlocked: blocked,
        blockingIds, blockReasons, reasons: blockReasons.slice(), pendingValidation, pendingValidationCount: pendingValidation.length,
        canInfer, validated: canInfer,
        state: !enabled ? (speciesGroup || noiseGroup ? 'disabled' : 'manual') : blocked ? 'blocked' : pendingValidation.length ? 'validation' : 'ready',
        manualCount: 0, inferredCount: 0, requiredCount: 0, waitingCount: 0
      };
      for (const row of rows) {
        const item = info.get(row.id);
        let role = anchor && row.id === anchor.id ? 'reference' : auditIds.has(row.id) ? 'audit' : 'exception';
        let assignment;
        if (item.decision) {
          assignment = { status: item.decision.status, label: item.decision.label.trim(), origin: 'manual', requiresReview: false,
            role: role === 'exception' ? 'manual' : role,
            reasons: [item.decision.status === 'uncertain' ? 'Vérification manuelle enregistrée ; l’identification reste non résolue.' : 'Décision manuelle enregistrée pour ce contact.'] };
          group.manualCount++;
        } else {
          const reasons = item.reasons.slice();
          if (role === 'reference') reasons.unshift('Le contact de référence le mieux classé doit être vérifié manuellement par rapport à son AUTO-ID.');
          if (role === 'audit') reasons.unshift('Échantillon de contrôle obligatoire et reproductible ; vérifiez manuellement ce contact par rapport à son AUTO-ID.');
          if (blocked) reasons.push('L’attribution par les règles dans le groupe est bloquée par une décision manuelle différente ou incertaine, ou par une identification importée contradictoire.');
          const mandatory = role === 'reference' || role === 'audit' || !item.eligible || blocked || Boolean(item.draft);
          if (item.draft) reasons.push('Un brouillon non enregistré nécessite une décision manuelle validée ; il ne peut pas recevoir une attribution par les règles.');
          if (!mandatory && canInfer) {
            assignment = { status: noiseGroup ? 'inferred-noise' : 'inferred', label: first.autoId, origin: 'inferred', requiresReview: false,
              role: 'inferred', reasons: [noiseGroup ? 'Contact admissible selon les règles ; l’échantillon de contrôle du bruit est validé sans désaccord. Cette exclusion est attribuée par les règles et n’a pas été vérifiée manuellement pour ce contact.' : 'Contact admissible selon les règles ; la référence et tous les contrôles sont validés sans désaccord. L’identification est attribuée par les règles et n’a pas été vérifiée manuellement pour ce contact.'] };
            group.inferredCount++;
          } else {
            if (!mandatory) { role = 'waiting'; reasons.push('En attente de ' + pendingValidation.length + (noiseGroup ? ' contrôle(s) obligatoire(s) sur l’échantillon de bruit de ce groupe.' : ' décision(s) obligatoire(s) sur la référence ou les contrôles de ce groupe.')); group.waitingCount++; }
            assignment = { status: item.draft ? 'draft' : String(row.manualId || '').trim() ? 'imported' : 'needs-review',
              label: item.draft ? String(item.draft.label || '') : String(row.manualId || ''), origin: 'pending', requiresReview: mandatory, role, reasons };
            if (mandatory) group.requiredCount++;
          }
        }
        assignment = { id: row.id, row, ...assignment, reason: assignment.reasons.join(' '), groupBlocked: blocked, groupKey: key };
        byId.set(row.id, assignment);
      }
      groups.push(group);
    }

    const assignments = data.rows.map(row => byId.get(row.id));
    const metrics = { total: assignments.length, manual: 0, inferred: 0, required: 0, waiting: 0, uncertain: 0, unresolved: 0, pending: 0, noise: 0, classified: 0, taxon: 0, blockedGroups: groups.filter(group => group.blocked).length };
    const summaryMap = new Map();
    for (const assignment of assignments) {
      let label = assignment.label;
      // Free-form labels can name a species, genus or acoustic species group.
      // Preserve their specificity without guessing it from text or codes.
      let category = 'taxon';
      if (assignment.origin === 'pending') { label = 'Pending classification'; category = 'pending'; metrics.pending++; metrics.unresolved++; }
      else if (assignment.status === 'uncertain') { label = 'Uncertain / unresolved'; category = 'uncertain'; metrics.uncertain++; metrics.unresolved++; }
      else if (specialIdentity(label) === 'NOISE') { label = 'Noise'; category = 'noise'; metrics.noise++; metrics.classified++; }
      else if (['UNIDENTIFIEDBAT', 'CHAUVESOURISNONIDENTIFIÉE', 'CHAUVESOURISNONIDENTIFIEE', 'NOID', 'UNCLASSIFIED', 'UNRESOLVED', 'UNKNOWN'].includes(specialIdentity(label))) { category = 'unresolved'; metrics.unresolved++; }
      else { metrics.taxon++; metrics.classified++; }
      if (assignment.origin === 'manual') metrics.manual++;
      if (assignment.origin === 'inferred') metrics.inferred++;
      if (assignment.requiresReview) metrics.required++;
      if (assignment.role === 'waiting') metrics.waiting++;
      const key = JSON.stringify([category, identity(label)]);
      if (!summaryMap.has(key)) summaryMap.set(key, { label, category, manual: 0, inferred: 0, pending: 0, total: 0, uncertain: 0 });
      const entry = summaryMap.get(key);
      entry.total++;
      entry[assignment.origin === 'pending' ? 'pending' : assignment.origin]++;
      if (assignment.status === 'uncertain') entry.uncertain++;
    }
    const categoryOrder = { taxon: 0, noise: 1, unresolved: 2, uncertain: 3, pending: 4 };
    const summary = [...summaryMap.values()].sort((a, b) => categoryOrder[a.category] - categoryOrder[b.category] || a.label.localeCompare(b.label));
    metrics.complete = metrics.unresolved === 0;
    return { assignments, byId, summary, metrics, groups, policy };
  }

  return { VERSION, presets, PRESETS: presets, normalizePolicy, classify };
});
