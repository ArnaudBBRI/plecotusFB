const test = require('node:test');
const assert = require('node:assert/strict');
const Core = require('../core.js');
const Automation = require('../automation.js');

const species = 'Pipistrellus pipistrellus';
const headers = ['IN FILE', 'FOLDER', 'DATE', 'DATE-12', 'AUTO ID', 'PULSES', 'MATCHING', 'MATCH RATIO', 'MARGIN', 'OFFSET', 'CHANNEL', 'MANUAL ID', 'ALTERNATE 1', 'ALTERNATE 2', 'ALTERNATES', 'N'];
const policy = { preset: 'balanced', auditMinimum: 2, auditPercent: 0 };
function contact(index, changes = {}) {
  const values = { 'IN FILE': `call-${index}.wav`, FOLDER: 'Forest', DATE: '2026-09-02', 'DATE-12': '2026-09-01', 'AUTO ID': species, PULSES: '10', MATCHING: '9', 'MATCH RATIO': '0.9', MARGIN: '', OFFSET: '0', CHANNEL: '0', 'MANUAL ID': '', 'ALTERNATE 1': '', 'ALTERNATE 2': '', ALTERNATES: '', N: '10', ...changes };
  return headers.map(header => values[header]);
}
function data(count = 12, changes = {}) {
  const records = Array.from({ length: count }, (_, index) => contact(index, { ...(index === 0 ? { PULSES: '30', MATCHING: '30', 'MATCH RATIO': '1' } : {}), ...changes }));
  return { headers, ...Core.analyze(headers, records) };
}
function withChanges(source, index, changes) {
  const records = source.rows.map(row => row.raw.slice());
  for (const [name, value] of Object.entries(changes)) records[index][source.headers.indexOf(name)] = value;
  return { headers: source.headers, ...Core.analyze(source.headers, records) };
}
function gates(result, reviews = {}) {
  for (const group of result.groups) {
    for (const id of [...(group.anchorId ? [group.anchorId] : []), ...group.auditIds]) {
      reviews[id] = { status: group.kind === 'noise' ? 'noise' : 'confirmed', label: group.autoId };
    }
  }
  return reviews;
}
function conservation(result) {
  assert.equal(result.metrics.manual + result.metrics.inferred + result.metrics.pending, result.metrics.total);
  assert.equal(result.metrics.required + result.metrics.waiting, result.metrics.pending);
  assert.equal(result.summary.reduce((sum, item) => sum + item.total, 0), result.metrics.total);
  assert.equal(result.assignments.length, result.byId.size);
  for (const item of result.summary) assert.equal(item.manual + item.inferred + item.pending, item.total);
}

test('normalizes editable workflow presets and rejects invalid policy values', () => {
  assert.deepEqual(Automation.normalizePolicy(), { version: 1, preset: 'cautious', enableSpecies: true, enableNoise: true, minMatching: 8, minRatio: 0.9, auditPercent: 20, auditMinimum: 5 });
  assert.equal(Automation.normalizePolicy('balanced').minMatching, 5);
  assert.equal(Automation.normalizePolicy({ preset: 'faster', minRatio: 0.95 }).minRatio, 0.95);
  for (const bad of [{ auditMinimum: 0 }, { auditPercent: 101 }, { minRatio: -1 }, { minMatching: 2.5 }, { enableNoise: 'false' }, { version: 2 }, { preset: 'unknown' }, { minMatching: '8' }]) assert.throws(() => Automation.normalizePolicy(bad));
});

test('no species contact is inferred before the exact reference and all sample contacts agree', () => {
  const source = data();
  const first = Automation.classify(source, {}, policy);
  assert.equal(first.metrics.inferred, 0);
  assert.equal(first.metrics.required, 3);
  assert.equal(first.metrics.waiting, 9);
  assert.equal(first.groups[0].anchorId, source.rows[0].id);
  const reviews = gates(first);
  delete reviews[first.groups[0].auditIds[0]];
  assert.equal(Automation.classify(source, reviews, policy).metrics.inferred, 0);
  reviews[first.groups[0].auditIds[0]] = { status: 'confirmed', label: species };
  const final = Automation.classify(source, reviews, policy);
  assert.equal(final.metrics.manual, 3);
  assert.equal(final.metrics.inferred, 9);
  assert.equal(final.metrics.required, 0);
  assert.equal(final.metrics.complete, true);
  assert.deepEqual(final.summary, [{ label: species, category: 'taxon', manual: 3, inferred: 9, pending: 0, total: 12, uncertain: 0 }]);
  conservation(first); conservation(final);
});

test('small groups may require every contact, even under the faster policy', () => {
  const source = data(3);
  const result = Automation.classify(source, {}, 'faster');
  assert.equal(result.metrics.required, 3);
  const complete = Automation.classify(source, gates(result), 'faster');
  assert.equal(complete.metrics.inferred, 0);
  assert.equal(complete.metrics.manual, 3);
  conservation(complete);
});

test('weakest eligible ratio/matching contact is audited and sampling is deterministic', () => {
  const source = withChanges(data(25), 8, { PULSES: '10', MATCHING: '8', 'MATCH RATIO': '0.8' });
  const result = Automation.classify(source, {}, policy);
  assert.equal(result.groups[0].auditIds[0], source.rows[8].id);
  assert.deepEqual(result.groups[0].auditIds, Automation.classify(source, {}, policy).groups[0].auditIds);
  assert.deepEqual(result.groups[0].auditIds, Automation.classify(source, gates(result), policy).groups[0].auditIds);
});

test('audit size follows the larger of the minimum and rounded-up percentage', () => {
  const source = data(42);
  const result = Automation.classify(source, {}, { ...policy, auditMinimum: 2, auditPercent: 10 });
  assert.equal(result.groups[0].auditIds.length, 5); // ceil(41 * 10%)
  const all = Automation.classify(source, {}, { ...policy, auditPercent: 100 });
  assert.equal(all.metrics.required, 42);
  assert.equal(all.metrics.waiting, 0);
});

test('a manual disagreement on any contact immediately invalidates group inference without propagating a correction', () => {
  const source = data();
  const reviews = gates(Automation.classify(source, {}, policy));
  const initial = Automation.classify(source, reviews, policy);
  const candidate = initial.assignments.find(item => item.origin === 'inferred');
  reviews[candidate.id] = { status: 'corrected', label: 'Myotis daubentonii' };
  const failed = Automation.classify(source, reviews, policy);
  assert.equal(failed.metrics.inferred, 0);
  assert.equal(failed.groups[0].blocked, true);
  assert.equal(failed.metrics.required, source.rows.length - Object.keys(reviews).length);
  assert.equal(failed.summary.find(item => item.label === 'Myotis daubentonii').total, 1);
  assert.ok(failed.assignments.filter(item => item.origin === 'pending').every(item => item.groupBlocked && item.requiresReview && item.label === ''));
  conservation(failed);
  delete reviews[candidate.id];
  assert.equal(Automation.classify(source, reviews, policy).metrics.inferred, initial.metrics.inferred);
});

test('an uncertain saved decision remains unresolved even if its label equals AUTO-ID', () => {
  const source = data();
  const reviews = gates(Automation.classify(source, {}, policy));
  reviews[source.rows[0].id] = { status: 'uncertain', label: species };
  const result = Automation.classify(source, reviews, policy);
  assert.equal(result.metrics.inferred, 0);
  assert.equal(result.metrics.uncertain, 1);
  assert.equal(result.metrics.unresolved, result.metrics.pending + 1);
  assert.equal(result.summary.find(item => item.category === 'uncertain').total, 1);
  assert.equal(result.summary.find(item => item.category === 'taxon').total, 2);
  conservation(result);
});

test('stricter thresholds recompute eligibility and gates without changing submitted manual reviews', () => {
  const source = data();
  const reviews = gates(Automation.classify(source, {}, policy));
  const before = JSON.stringify(reviews);
  const strict = Automation.classify(source, reviews, { ...policy, minRatio: 1, minMatching: 20 });
  assert.equal(strict.metrics.inferred, 0);
  assert.equal(strict.metrics.manual, 3);
  assert.equal(strict.metrics.required, 9);
  assert.equal(JSON.stringify(reviews), before);
  assert.equal(Automation.classify(source, reviews, policy).metrics.inferred, 9);
});

test('a policy with a larger mandatory sample withdraws inference until its new samples are checked', () => {
  const source = data(30);
  const reviews = gates(Automation.classify(source, {}, policy));
  const expanded = Automation.classify(source, reviews, { ...policy, auditMinimum: 6 });
  assert.equal(expanded.metrics.inferred, 0);
  assert.equal(expanded.groups[0].pendingValidation.length, 4);
  assert.equal(expanded.metrics.required, 4);
  const finished = Automation.classify(source, gates(expanded, reviews), { ...policy, auditMinimum: 6 });
  assert.equal(finished.metrics.inferred, 23);
  conservation(finished);
});

test('missing margin does not prevent inference but missing/invalid counts and contradictory ratio do', () => {
  const base = data(20);
  const modifications = [
    { PULSES: '' }, { PULSES: '0', MATCHING: '0', 'MATCH RATIO': '0' },
    { MATCHING: '11' }, { 'MATCH RATIO': '0.98' }, { 'MATCH RATIO': 'broken' }
  ];
  for (const change of modifications) {
    const source = withChanges(base, 10, change);
    const first = Automation.classify(source, {}, policy);
    const result = Automation.classify(source, gates(first), policy);
    const exception = result.byId.get(source.rows[10].id);
    assert.equal(exception.origin, 'pending');
    assert.equal(exception.requiresReview, true);
    assert.equal(exception.role, 'exception');
    assert.ok(result.metrics.inferred > 0);
    conservation(result);
  }
  const result = Automation.classify(base, gates(Automation.classify(base, {}, policy)), policy);
  assert.ok(result.metrics.inferred > 0);
});

test('thresholds are inclusive and a legitimately derived missing ratio is usable', () => {
  const source = withChanges(data(), 10, { MATCHING: '8', 'MATCH RATIO': '' });
  const result = Automation.classify(source, {}, { ...policy, minMatching: 8, minRatio: 0.8 });
  assert.ok(result.groups[0].candidateIds.includes(source.rows[10].id));
  assert.equal(source.rows[10].ratioSource, 'derived');
});

test('different modern or legacy alternates require manual checks, while repeated same-label alternates are accepted', () => {
  for (const alternate of ['ALTERNATE 1', 'ALTERNATE 2', 'ALTERNATES']) {
    const source = withChanges(data(), 10, { [alternate]: species + '; Myotis sp.' });
    const result = Automation.classify(source, {}, policy);
    assert.equal(result.byId.get(source.rows[10].id).requiresReview, true);
    assert.match(result.byId.get(source.rows[10].id).reason, /alternative/i);
  }
  const same = withChanges(data(), 10, { ALTERNATES: species + '; ' + species });
  assert.ok(Automation.classify(same, {}, policy).groups[0].candidateIds.includes(same.rows[10].id));
});

test('imported labels stay explicit-review-only and conflicting imports block their group until reviewed', () => {
  const source = withChanges(data(), 10, { 'MANUAL ID': 'Myotis sp.' });
  const initial = Automation.classify(source, {}, policy);
  const reviews = gates(initial);
  const pending = Automation.classify(source, reviews, policy);
  assert.equal(pending.byId.get(source.rows[10].id).status, 'imported');
  assert.equal(pending.byId.get(source.rows[10].id).label, 'Myotis sp.');
  assert.equal(pending.metrics.inferred, 0);
  reviews[source.rows[10].id] = { status: 'corrected', label: species };
  const next = Automation.classify(source, reviews, policy);
  const completed = Automation.classify(source, gates(next, reviews), policy);
  assert.ok(completed.metrics.inferred > 0);
  assert.equal(completed.byId.get(source.rows[10].id).origin, 'manual');
});

test('agreeing imported labels cannot be silently treated as submitted manual decisions', () => {
  const source = withChanges(data(), 10, { 'MANUAL ID': species });
  const initial = Automation.classify(source, {}, policy);
  const completed = Automation.classify(source, gates(initial), policy);
  assert.equal(completed.groups[0].blocked, false);
  assert.equal(completed.byId.get(source.rows[10].id).status, 'imported');
  assert.equal(completed.byId.get(source.rows[10].id).requiresReview, true);
  assert.ok(completed.metrics.inferred > 0);
});

test('pending low-quality exceptions do not prevent other eligible rows from being inferred, but their later disagreement does', () => {
  const source = withChanges(data(), 10, { MATCHING: '1', 'MATCH RATIO': '0.1' });
  const reviews = gates(Automation.classify(source, {}, policy));
  assert.ok(Automation.classify(source, reviews, policy).metrics.inferred > 0);
  reviews[source.rows[10].id] = { status: 'noise', label: 'Noise' };
  assert.equal(Automation.classify(source, reviews, policy).metrics.inferred, 0);
});

test('No ID and unclassified contacts are always manual-only, without losing their final corrected labels', () => {
  const source = data(10, { 'AUTO ID': 'No ID' });
  const result = Automation.classify(source, {}, policy);
  assert.equal(result.metrics.required, 10);
  assert.equal(result.metrics.inferred, 0);
  const reviews = { [source.rows[0].id]: { status: 'corrected', label: species } };
  assert.equal(Automation.classify(source, reviews, policy).summary.find(item => item.label === species).total, 1);
  const unknown = data(4, { 'AUTO ID': '' });
  assert.equal(Automation.classify(unknown, {}, policy).metrics.required, 4);
});

test('zero-pulse Noise needs its mandatory sample, and no Noise is inferred until every sample decision is Noise', () => {
  const source = data(12, { 'AUTO ID': 'Noise', PULSES: '0', MATCHING: '0', 'MATCH RATIO': '0', N: '0' });
  const first = Automation.classify(source, {}, policy);
  assert.equal(first.groups[0].anchorId, null);
  assert.equal(first.metrics.required, 2);
  assert.equal(first.metrics.waiting, 10);
  const result = Automation.classify(source, gates(first), policy);
  assert.equal(result.metrics.inferred, 10);
  assert.equal(result.metrics.noise, 12);
  assert.ok(result.assignments.filter(item => item.origin === 'inferred').every(item => item.status === 'inferred-noise'));
  conservation(result);
});

test('any bat or uncertain decision in a Noise group blocks all remaining noise inference', () => {
  const source = data(12, { 'AUTO ID': 'Noise', PULSES: '0', MATCHING: '0', 'MATCH RATIO': '0', N: '0' });
  for (const decision of [{ status: 'corrected', label: species }, { status: 'uncertain', label: 'Noise' }]) {
    const initial = Automation.classify(source, {}, policy);
    const reviews = gates(initial);
    const id = initial.assignments.find(item => item.role === 'waiting').id;
    reviews[id] = decision;
    const failed = Automation.classify(source, reviews, policy);
    assert.equal(failed.metrics.inferred, 0);
    assert.ok(failed.assignments.filter(item => item.origin === 'pending').every(item => item.requiresReview));
    conservation(failed);
  }
});

test('positive/missing Noise PULSES and positive/missing/invalid raw N never qualify for noise inference', () => {
  const base = data(12, { 'AUTO ID': 'Noise', PULSES: '0', MATCHING: '0', 'MATCH RATIO': '0', N: '0' });
  for (const change of [{ PULSES: '1' }, { PULSES: '' }, { PULSES: '-1' }, { N: '3' }, { N: '' }, { N: 'broken' }]) {
    const source = withChanges(base, 10, change);
    const first = Automation.classify(source, {}, policy);
    const result = Automation.classify(source, gates(first), policy);
    assert.equal(result.byId.get(source.rows[10].id).requiresReview, true);
    assert.equal(result.byId.get(source.rows[10].id).origin, 'pending');
    assert.ok(result.metrics.inferred > 0);
  }
});

test('disabling species or noise inference keeps saved decisions and makes other contacts mandatory', () => {
  for (const kind of ['species', 'noise']) {
    const source = kind === 'species' ? data() : data(12, { 'AUTO ID': 'Noise', PULSES: '0', MATCHING: '0', 'MATCH RATIO': '0', N: '0' });
    const reviews = gates(Automation.classify(source, {}, policy));
    const result = Automation.classify(source, reviews, { ...policy, [kind === 'species' ? 'enableSpecies' : 'enableNoise']: false });
    assert.equal(result.metrics.inferred, 0);
    assert.equal(result.metrics.required, source.rows.length - Object.keys(reviews).length);
    conservation(result);
  }
});

test('drafts cannot silently become inferred outcomes; existing submitted decisions remain the active outcome', () => {
  const source = data();
  const initial = Automation.classify(source, {}, policy);
  const reviews = gates(initial);
  const candidate = initial.assignments.find(item => item.role === 'waiting');
  const drafts = { [candidate.id]: { status: 'corrected', label: 'Myotis sp.' } };
  const result = Automation.classify(source, reviews, policy, drafts);
  assert.equal(result.byId.get(candidate.id).status, 'draft');
  assert.equal(result.byId.get(candidate.id).origin, 'pending');
  assert.equal(result.byId.get(candidate.id).requiresReview, true);
  assert.equal(result.metrics.inferred, 8);
  assert.equal(result.metrics.manual, 3);
  drafts[source.rows[0].id] = { status: 'uncertain', label: 'Myotis sp.' };
  assert.equal(Automation.classify(source, reviews, policy, drafts).byId.get(source.rows[0].id).status, 'confirmed');
  conservation(result);
});

test('source date/folder groups cannot validate each other', () => {
  const base = data(24);
  let records = base.rows.map(row => row.raw.slice());
  for (let index = 12; index < 24; index++) records[index][headers.indexOf('DATE-12')] = '2026-09-02';
  const source = { headers, ...Core.analyze(headers, records) };
  const initial = Automation.classify(source, {}, policy);
  const first = initial.groups[0];
  const reviews = {};
  for (const id of [first.anchorId, ...first.auditIds]) reviews[id] = { status: 'confirmed', label: species };
  const result = Automation.classify(source, reviews, policy);
  assert.equal(result.groups[0].canInfer, true);
  assert.equal(result.groups[1].canInfer, false);
  assert.equal(result.metrics.inferred, 9);
  conservation(result);
});

test('invalid dates, locators and repeated source locators are manual exceptions', () => {
  for (const change of [{ 'DATE-12': '' }, { 'DATE-12': '2026-02-30' }, { DATE: 'invalid' }, { OFFSET: '-1' }, { CHANNEL: 'x' }, { 'IN FILE': '' }]) {
    const source = withChanges(data(), 10, change);
    const result = Automation.classify(source, {}, policy);
    assert.equal(result.byId.get(source.rows[10].id).requiresReview, true);
    assert.ok(result.byId.get(source.rows[10].id).reason.length);
  }
  const base = data();
  const repeated = withChanges(base, 10, { 'IN FILE': base.rows[11].file });
  const result = Automation.classify(repeated, {}, policy);
  assert.equal(result.byId.get(repeated.rows[10].id).requiresReview, true);
  assert.equal(result.byId.get(repeated.rows[11].id).requiresReview, true);
});

test('final categories conserve all contacts, including manual genus labels, uncertainty, Noise and pending rows', () => {
  const source = data(6, { 'AUTO ID': 'No ID' });
  const reviews = {
    'contact-1': { status: 'corrected', label: species },
    'contact-2': { status: 'corrected', label: 'Myotis sp.' },
    'contact-3': { status: 'uncertain', label: species },
    'contact-4': { status: 'noise', label: 'Noise' },
    'contact-5': { status: 'corrected', label: 'Unidentified bat' }
  };
  const result = Automation.classify(source, reviews, policy);
  assert.equal(result.metrics.manual, 5);
  assert.equal(result.metrics.uncertain, 1);
  assert.equal(result.metrics.noise, 1);
  assert.equal(result.metrics.unresolved, 3);
  assert.equal(result.metrics.taxon, 2);
  assert.equal(result.summary.find(item => item.label === 'Myotis sp.').category, 'taxon');
  assert.equal(result.summary.find(item => item.label === 'Myotis sp.').total, 1);
  conservation(result);
});

test('specific species, genus and free-form group labels keep their exact specificity under a generic taxon category', () => {
  const labels = ['PIPPIP', species, 'Myotis sp.', 'Nyctalus / Eptesicus / Vespertilio group', 'Pipistrellus groupe'];
  const source = data(labels.length, { 'AUTO ID': 'No ID' });
  const reviews = Object.fromEntries(labels.map((label, index) => ['contact-' + (index + 1), { status: 'corrected', label }]));
  const result = Automation.classify(source, reviews, policy);
  assert.equal(result.metrics.taxon, labels.length);
  assert.equal(result.metrics.classified, labels.length);
  assert.equal(result.metrics.species, undefined, 'No counter claims genus/group contacts are resolved species.');
  for (const label of labels) {
    const outcome = result.summary.find(item => item.label === label);
    assert.equal(outcome.category, 'taxon');
    assert.equal(outcome.total, 1);
  }
  conservation(result);
});

test('French unidentified-bat labels remain unresolved and English project labels stay compatible', () => {
  const labels = ['Chauve-souris non identifiée', 'CHAUVE-SOURIS NON IDENTIFIÉE', 'Chauve-souris non identifiee', 'Unidentified bat'];
  const source = data(labels.length, { 'AUTO ID': 'No ID' });
  const reviews = Object.fromEntries(labels.map((label, index) => ['contact-' + (index + 1), { status: 'corrected', label }]));
  const result = Automation.classify(source, reviews, policy);
  assert.equal(result.metrics.unresolved, labels.length);
  assert.equal(result.metrics.taxon, 0);
  assert.equal(result.metrics.complete, false);
  assert.ok(result.summary.every(item => item.category === 'unresolved'));
  assert.deepEqual(result.assignments.map(item => item.label), labels);
  conservation(result);
});

test('classification is pure, preserves every row identity, and accepts Maps for decisions', () => {
  const source = data();
  const initial = Automation.classify(source, {}, policy);
  const reviews = new Map(Object.entries(gates(initial)));
  const before = JSON.stringify(source);
  const decisionBefore = JSON.stringify([...reviews]);
  const result = Automation.classify(source, reviews, policy, new Map());
  assert.equal(JSON.stringify(source), before);
  assert.equal(JSON.stringify([...reviews]), decisionBefore);
  assert.deepEqual(result.assignments.map(item => item.id), source.rows.map(row => row.id));
  for (const item of result.assignments) assert.equal(item.row, source.rows.find(row => row.id === item.id));
});
