// Verify real browser downloads against their saved project, without reproducing
// source CSV exports or relying on filenames as contact identities.
// node tests/export-check.cjs project.json reviewed.csv review-log.csv [summary.csv] [classified.csv]
const fs = require('node:fs');
const assert = require('node:assert/strict');
const Core = require('../core.js');
const Automation = require('../automation.js');

const [projectPath, reviewedPath, logPath, summaryPath, classifiedPath] = process.argv.slice(2);
if (!projectPath || !reviewedPath || !logPath) {
  process.stderr.write('Usage: node tests/export-check.cjs project.json reviewed.csv review-log.csv [summary.csv] [classified.csv]\n');
  process.exitCode = 1;
} else {
  const project = JSON.parse(fs.readFileSync(projectPath, 'utf8'));
  assert.equal(project.format, 'plecotus-review');
  assert.ok([1, 2].includes(project.version), 'Recognized saved-project version.');
  const source = Core.parseCSV(project.source.text);
  const analysis = Core.analyze(source.headers, source.records);
  analysis.headers = source.headers;
  const classification = project.version === 2 ? Automation.classify(analysis, project.reviews, project.policy, project.drafts) : null;
  const updated = Core.parseCSV(fs.readFileSync(reviewedPath, 'utf8'));
  const log = Core.parseCSV(fs.readFileSync(logPath, 'utf8'));
  const reviewedStatuses = new Set(['confirmed', 'corrected', 'uncertain', 'noise']);
  const originalManualColumn = analysis.columns.manualId;
  const expectedHeaders = source.headers.slice();
  let manualColumn = originalManualColumn;
  if (manualColumn < 0) { manualColumn = expectedHeaders.length; expectedHeaders.push('MANUAL ID'); }
  assert.deepEqual(updated.headers, expectedHeaders, 'Export preserves all source headers and their order.');
  assert.equal(updated.records.length, source.records.length, 'No source contact is removed or merged.');
  assert.equal(log.records.length, source.records.length, 'Review log contains every source contact.');
  assert.equal(updated.delimiter, source.delimiter, 'Export preserves the detected source CSV dialect.');

  const logHeaders = ['SOURCE ROW', 'INDIR', 'FOLDER', 'IN FILE', 'CHANNEL', 'OFFSET', 'DATE', 'TIME', 'NIGHT', 'AUTO ID', 'ORIGINAL MANUAL ID', 'REVIEW STATUS', 'REVIEW LABEL', 'REVIEWER', 'REVIEWED AT', 'NOTES', 'GROUP RANK', 'REFERENCE PICK', 'MATCHING', 'PULSES', 'MATCH RATIO', 'MARGIN', 'DATA ISSUES'];
  if (classification) logHeaders.push('ASSIGNED LABEL', 'ASSIGNMENT ORIGIN', 'ASSIGNMENT STATUS', 'REQUIRED MANUAL CHECK', 'CHECK ROLE', 'ASSIGNMENT REASON', 'CLASSIFICATION POLICY');
  assert.deepEqual(log.headers, logHeaders);
  const safe = value => /^[\t\r\n ]*[=+@-]/.test(String(value)) ? "'" + value : value;
  let changed = 0, checkedCount = 0, imported = 0;
  analysis.rows.forEach((row, index) => {
    const decision = project.reviews[row.id];
    const isReviewed = decision && reviewedStatuses.has(decision.status);
    const expected = row.raw.slice();
    while (expected.length < expectedHeaders.length) expected.push('');
    if (isReviewed) { expected[manualColumn] = decision.label; checkedCount++; }
    else if (row.manualId) imported++;
    assert.deepEqual(updated.records[index], expected, 'Only submitted MANUAL ID decisions may change source row ' + (index + 1) + '.');
    if (updated.records[index][manualColumn] !== (originalManualColumn < 0 ? '' : row.raw[originalManualColumn])) changed++;
    const status = isReviewed ? decision.status : row.manualId ? 'imported' : 'unreviewed';
    const expectedLogValues = [row.index + 1, row.indir, row.rawFolder, row.file, row.channel, row.offset, row.date, row.time, row.night, row.autoId, row.manualId, status, isReviewed ? decision.label : row.manualId || '', isReviewed ? decision.reviewer : '', isReviewed ? decision.timestamp : '', isReviewed ? decision.notes : '', row.rank, row.isAnchor ? 'yes' : 'no', row.matching ?? '', row.pulses ?? '', row.ratio ?? '', row.margin ?? '', row.issues.join(' | ')];
    if (classification) {
      const assignment = classification.byId.get(row.id);
      expectedLogValues.push(assignment.label, assignment.origin, assignment.status, assignment.requiresReview ? 'yes' : 'no', assignment.role, assignment.reason, JSON.stringify(classification.policy));
    }
    const expectedLog = expectedLogValues.map(value => String(safe(value == null ? '' : value)));
    assert.deepEqual(log.records[index], expectedLog, 'Audit record preserves contact identity and decision for source row ' + (index + 1) + '.');
  });
  if (classification) {
    const metrics = classification.metrics;
    assert.equal(metrics.manual + metrics.inferred + metrics.pending, source.records.length, 'Every contact has one current outcome.');
    assert.equal(metrics.required + metrics.waiting, metrics.pending, 'All pending contacts are mandatory or waiting.');
    assert.equal(classification.summary.reduce((sum, entry) => sum + entry.total, 0), source.records.length, 'Summary preserves all contacts.');
    for (const entry of classification.summary) assert.equal(entry.manual + entry.inferred + entry.pending, entry.total, 'Each summary outcome conserves contacts.');
  }
  if (summaryPath) {
    assert.ok(classification, 'Summary export verification requires a v2 project.');
    const summary = Core.parseCSV(fs.readFileSync(summaryPath, 'utf8'));
    const frenchSummary = summary.headers[0] === 'LIBELLÉ';
    const englishHeaders = ['LABEL', 'CATEGORY', 'MANUALLY CHECKED CONTACTS', 'INFERRED CONTACTS', 'TOTAL CONTACTS', 'SOURCE FILE', 'CHECKS COMPLETE', 'POLICY', 'GENERATED AT'];
    const frenchHeaders = ['LIBELLÉ','CATÉGORIE','CONTACTS VÉRIFIÉS MANUELLEMENT','CONTACTS ATTRIBUÉS PAR LES RÈGLES','TOTAL DES CONTACTS','FICHIER SOURCE','VÉRIFICATIONS TERMINÉES','RÈGLES','DATE DE GÉNÉRATION'];
    assert.deepEqual(summary.headers, frenchSummary ? frenchHeaders : englishHeaders);
    const translatedOutcomes = {'Noise':'Bruit','No ID':'Sans identification (NoID)','NoID':'Sans identification (NoID)','Unclassified':'Non classé','Unidentified bat':'Chauve-souris non identifiée','Pending classification':'Classification en attente','Uncertain / unresolved':'Identification incertaine / non résolue'};
    const translatedCategories = {taxon:'taxon',noise:'bruit',uncertain:'incertain',unresolved:'non résolu',pending:'en attente'};
    assert.equal(summary.records.length, classification.summary.length, 'No outcome category is omitted or duplicated.');
    const checksComplete = classification.metrics.required === 0 && classification.metrics.waiting === 0;
    let generatedAt;
    classification.summary.forEach((entry, index) => {
      const label = frenchSummary ? translatedOutcomes[entry.label] || entry.label : entry.label;
      const completion = frenchSummary ? (checksComplete ? 'oui' : 'non') : (checksComplete ? 'yes' : 'no');
      const category = frenchSummary ? translatedCategories[entry.category] : entry.category;
      const expected = [label, category, entry.manual, entry.inferred, entry.total, project.source.name, completion, JSON.stringify(classification.policy)].map(value => String(safe(value)));
      assert.deepEqual(summary.records[index].slice(0, 8), expected, 'Summary label, category, counts, source and policy agree for outcome ' + (index + 1) + '.');
      const timestamp = summary.records[index][8];
      assert.ok(Number.isFinite(Date.parse(timestamp)) && new Date(timestamp).toISOString() === timestamp, 'Generated timestamp is a UTC ISO time.');
      if (generatedAt) assert.equal(timestamp, generatedAt, 'One export shares one generated timestamp.');
      generatedAt = timestamp;
    });
    assert.equal(summary.records.reduce((sum, record) => sum + Number(record[4]), 0), source.records.length, 'Exported summary totals conserve all contacts.');
  }
  if (classifiedPath) {
    assert.ok(classification, 'Classified export verification requires a v2 project.');
    const classified = Core.parseCSV(fs.readFileSync(classifiedPath, 'utf8'));
    const metadataHeaders = ['PLECOTUS SOURCE ROW', 'PLECOTUS ASSIGNED LABEL', 'PLECOTUS ORIGIN', 'PLECOTUS STATUS', 'PLECOTUS CHECK REQUIRED', 'PLECOTUS CHECK ROLE', 'PLECOTUS REASON', 'PLECOTUS POLICY'];
    const classifiedHeaders = source.headers.slice();
    for (const name of metadataHeaders) {
      let unique = name;
      while (classifiedHeaders.some(header => header.toUpperCase() === unique.toUpperCase())) unique += ' (new)';
      classifiedHeaders.push(unique);
    }
    assert.deepEqual(classified.headers, classifiedHeaders, 'Original source headers and collision-safe provenance headers are preserved.');
    assert.equal(classified.delimiter, source.delimiter, 'Classified export keeps the source dialect.');
    assert.equal(classified.records.length, source.records.length, 'Every source contact is retained in original order.');
    analysis.rows.forEach((row, index) => {
      const assignment = classification.byId.get(row.id);
      assert.deepEqual(classified.records[index].slice(0, source.headers.length), row.raw, 'All source cells, including MANUAL ID and NOTES, are unchanged in classified row ' + (index + 1) + '.');
      const expected = [row.index + 1, assignment.label, assignment.origin, assignment.status, assignment.requiresReview ? 'yes' : 'no', assignment.role, assignment.reason, JSON.stringify(classification.policy)].map(value => String(safe(value)));
      assert.deepEqual(classified.records[index].slice(source.headers.length), expected, 'Provenance and current assignment agree for classified row ' + (index + 1) + '.');
    });
  }
  process.stdout.write('Verified ' + analysis.rows.length + ' contacts: ' + checkedCount + ' submitted decisions, ' + changed + ' manual-label changes, ' + imported + ' untouched imported manual labels. All other source fields, row identities, channel/offset values and review-log fields match.\n');
  if (classification) process.stdout.write('Verified classification conservation: ' + classification.metrics.manual + ' manual + ' + classification.metrics.inferred + ' inferred + ' + classification.metrics.pending + ' pending = ' + classification.metrics.total + ' contacts.' + (summaryPath ? ' Summary export verified.' : '') + (classifiedPath ? ' Classified export verified.' : '') + '\n');
}
