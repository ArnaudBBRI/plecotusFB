# Plecotus — classification des contacts de chauves-souris

Un outil local qui transforme les résultats CSV de Kaleidoscope, pour des enregistrements réalisés en Belgique, en **nombres de contacts par espèce**. Il classe les contacts par priorité, guide les contrôles manuels obligatoires, puis attribue aux contacts admissibles restants l'espèce déjà suggérée par leur `AUTO-ID`. Le bilan distingue les contacts vérifiés manuellement des contacts attribués par les règles. L'outil n'analyse pas les sons et n'exécute pas de nouveau classificateur acoustique.

L'interface et la documentation sont en français. Les noms de colonnes du CSV source, les codes `AUTO-ID` et les étiquettes d'espèces importées sont conservés tels quels pour assurer la compatibilité avec Kaleidoscope. Les colonnes du bilan destiné à l'utilisateur sont en français ; les catégories internes et les données techniques des exports restent compatibles avec le format du projet.

## Démarrer sans installation

1. Double-cliquez sur **`Plecotus.html`** pour l'ouvrir dans Microsoft Edge, Chrome ou un autre navigateur récent. Ce fichier contient toute l'application et fonctionne seul. Vous pouvez aussi ouvrir `index.html`, en conservant `styles.css`, `core.js`, `automation.js` et `app.js` dans le même dossier.
2. Cliquez sur **Importer un CSV** et choisissez votre fichier Kaleidoscope `id.csv`. **Découvrir un exemple** charge des contacts fictifs clairement signalés.
3. Ouvrez **Règles de classification** pour choisir le préréglage Prudent, Équilibré ou Rapide, ou régler le nombre minimal de cris correspondants, le ratio de correspondance, le pourcentage de contrôle et la taille minimale de l'échantillon. Le contrôle par échantillonnage du bruit peut être désactivé. Ces valeurs initiales sont des règles empiriques non validées ; commencez avec Prudent jusqu'à leur validation sur vos enregistrements.
4. Suivez la file des contrôles obligatoires. Examinez l'enregistrement sélectionné dans Kaleidoscope : **File → Open Results…**, choisissez votre CSV original, puis retrouvez le nom de fichier, le canal et le décalage du segment. **Copier les coordonnées du fichier** facilite cette recherche.
5. Choisissez **Confirmer la suggestion**, **Attribuer une étiquette**, **Identification incertaine** ou **Bruit / aucun cri de chauve-souris**. Ajoutez votre nom et des notes, puis cliquez sur **Enregistrer et suivant**. L'outil recalcule les attributions par les règles lorsque les contacts de référence et de contrôle sont validés. Les groupes d'espèces et les identifications non résolues sont acceptés.
6. Consultez le bilan par espèce : vérifiés manuellement, attribués par les règles et total. Les résultats en attente, le bruit et les identifications incertaines restent visibles. Une étiquette manuelle différente de l'`AUTO-ID`, ou une incertitude, bloque les attributions automatiques du groupe et augmente le travail manuel.
7. Utilisez régulièrement **Enregistrer le projet** pour créer une sauvegarde JSON durable. **Ouvrir un projet enregistré** restaure le CSV, les règles, les décisions enregistrées et les brouillons, puis recalcule les attributions.
8. **Exporter les résultats** fournit les contacts classés, le bilan par espèce, le CSV des identifications manuelles, le journal des vérifications et les contacts restant à vérifier. Conservez votre CSV original. Rouvrez le CSV des identifications manuelles dans Kaleidoscope pour vérifier quelques lignes.

Ce fonctionnement ne nécessite ni droits administrateur, ni installation d'un environnement d'exécution, ni compte, ni connexion Internet, ni serveur. Les liens vers la documentation du fabricant nécessitent une connexion Internet.

## Règles de contrôle et ordre de priorité

Chaque contact reçoit un résultat individuel ; seul un sous-ensemble peut être attribué sans examen direct. Chaque groupe espèce/dossier/nuit nécessite un contact de référence et un échantillon de contrôle avant que les suggestions fortes non vérifiées puissent être attribuées par les règles. L'échantillon comprend des contacts admissibles parmi les moins forts et d'autres choisis de manière reproductible. Les étiquettes manuelles existantes ont le statut **Importé** et doivent être vérifiées ici. Les `NoID`, les suggestions faibles, les alternatives ambiguës et les données problématiques nécessitent un contrôle individuel. Le bruit peut être attribué par les règles uniquement pour les lignes admissibles sans cris détectés, après validation de l'échantillon obligatoire ; cette exclusion ne prouve pas l'absence de chauves-souris.

| Préréglage | Nombre minimal de cris correspondants | Ratio minimal | Contrôle | Taille minimale de l'échantillon |
|---|---:|---:|---:|---:|
| Prudent | 8 | 0,90 | 20 % | 5 |
| Équilibré | 5 | 0,80 | 10 % | 3 |
| Rapide | 3 | 0,70 | 5 % | 2 |

Le contact de référence s'ajoute à cet échantillon ; celui-ci ne peut pas dépasser le nombre de contacts admissibles hors référence. Modifier les règles recalcule les attributions et les contrôles obligatoires sans supprimer le travail manuel. Une étiquette manuelle différente de l'`AUTO-ID`, ou une incertitude dans le groupe, annule les attributions par les règles. Terminer la file termine la procédure configurée ; les contacts attribués par les règles conservent cette provenance et les identifications incertaines restent non résolues. Les seuils et les taux de contrôle ne représentent pas des pourcentages de précision mesurés.

Dans chaque groupe **AUTO-ID + répertoire d'entrée + dossier + nuit**, l'ordre est :

1. `MATCHING`, du plus élevé au plus faible.
2. `MATCH RATIO`, du plus élevé au plus faible.
3. `MARGIN`, du plus élevé au plus faible, uniquement au sein de la même espèce.
4. Numéro de ligne source, du plus faible au plus élevé.

La nuit est définie par `DATE-12`, avec repli sur `DATE`. Les valeurs numériques absentes ou invalides sont placées en dernier. Le premier contact d'espèce de chaque groupe devient un **contact de référence**, sans que cela constitue une identification vérifiée ou une estimation de confiance. L'ordre guidé donne la priorité aux contrôles obligatoires. L'ordre original du CSV reste disponible. Les suggestions alternatives, les problèmes de données et les raisons des attributions apparaissent dans le volet du contact.

Les justifications, les règles exactes, les limites de calibration et le dictionnaire des champs sont dans [METHODS.md](METHODS.md). Avant de vous fier aux nombres attribués par les règles, comparez-les à un sous-ensemble de vos enregistrements identifié indépendamment par un expert et examinez les erreurs par espèce. Le fabricant recommande de vérifier manuellement les identifications suggérées ; cette procédure par échantillonnage est une règle expérimentale propre au projet.

## Fichiers et protections

- L'import accepte les CSV séparés par virgule, point-virgule ou tabulation, les cellules entre guillemets, les notes sur plusieurs lignes, les marques BOM UTF-8/UTF-16, les variantes courantes des en-têtes et les virgules décimales belges dans les CSV séparés par point-virgule. Un fichier UTF-8 invalide est décodé en Windows-1252 avec un avertissement. Les en-têtes dupliqués ou ambigus et les données mal formées sont rejetés.
- Chaque contact conserve son identité de ligne source. Les noms de fichiers répétés et les segments ne sont pas fusionnés.
- Le CSV des identifications manuelles conserve l'ordre des lignes source, les noms des en-têtes et les valeurs brutes des cellules. Seules les décisions enregistrées modifient `MANUAL ID` ; cette colonne est ajoutée si elle manque. Les guillemets, les sauts de ligne et l'encodage sont normalisés à l'export : le fichier n'est donc pas identique octet par octet. Les préambules, commentaires et lignes vides ne sont pas réémis. Conservez le fichier original.
- Le CSV destiné à Kaleidoscope contient uniquement les décisions manuelles ; aucune attribution par les règles n'est écrite dans `MANUAL ID`. Le **CSV des contacts classés**, distinct, enregistre un résultat par ligne source, avec sa provenance manuelle ou déduite, son statut et sa raison. Le **CSV du bilan par espèce** sépare les nombres manuels et déduits et distingue les résultats en attente, incertains et classés comme bruit. Conservez les règles, le projet JSON et le journal avec vos exports. Réimporter un CSV d'identifications manuelles donne à ses étiquettes le statut Importé ; rouvrir son projet préserve les états de vérification.
- Le texte des exports complémentaires est protégé contre l'interprétation en formules par les tableurs. Les valeurs originales du CSV destiné à Kaleidoscope sont conservées. Le journal utilise des horodatages ISO en UTC ; l'interface affiche l'heure locale du navigateur.
- Les fichiers audio, leurs métadonnées, le CSV original de Kaleidoscope et `settings.ini` ne sont pas modifiés. Recharger le CSV ne synchronise pas les étiquettes avec les métadonnées audio.
- Les données restent dans votre navigateur. Le stockage local facilite la reprise du dernier jeu de données et dépend du navigateur et de l'emplacement d'ouverture. Il peut être bloqué, vidé ou saturé ; utilisez **Enregistrer le projet** pour vos sauvegardes. Ouvrir un autre jeu de données propose une sauvegarde si des décisions ou des brouillons existent. Il n'y a pas de synchronisation dans le cloud.
- La taille d'entrée est limitée à 50 Mo. Chaque page de la file contient 50 contacts. Les très grands jeux de données peuvent rester lents et remplir le stockage du navigateur avant cette limite. L'outil vous invite à enregistrer un projet lorsque le stockage local échoue.

Kaleidoscope **Lite** permet la visualisation et la validation manuelle. Une nouvelle analyse Auto-ID des chauves-souris nécessite **Pro** ou sa version d'essai. Cet outil utilise les étiquettes déjà présentes dans votre CSV ; les CSV sans `AUTO-ID` restent utilisables pour une validation manuelle s'ils contiennent un champ de nom de fichier reconnu.

## Prévisualisation et vérifications facultatives pour le développement

Si Node.js est déjà disponible, lancez `node preview.cjs` depuis ce dossier et ouvrez `http://127.0.0.1:4173`. Le serveur écoute uniquement sur la boucle locale. Arrêtez-le avec Ctrl+C. Cette étape est facultative ; aucune installation n'est nécessaire pour ouvrir directement le HTML.

Lancez les tests des moteurs de données avec `node --test tests/core.test.cjs tests/automation.test.cjs`. Les vérifications d'import/export et des règles couvrent la lecture du CSV, la conservation des données source, le classement, les conditions de contrôle, les attributions par les règles et la conservation des totaux.

Après modification des fichiers source, lancez `node bundle.cjs` pour reconstruire `Plecotus.html`. `Plecotus-v2.zip` contient l'outil autonome, les instructions, la méthodologie et les fichiers source.

Les tests utilisent des données fictives. Aucun véritable fichier `id.csv` ni fichier audio de l'utilisateur n'a été fourni : la compatibilité avec votre export, un aller-retour dans votre version installée de Kaleidoscope et la précision des classifications restent à vérifier. Les nombres correspondent à des contacts — des lignes du CSV — et non à des chauves-souris individuelles. Les enregistrements mixtes ne sont pas automatiquement répartis entre plusieurs espèces.
