// Rebuild the standalone browser file after editing index.html / CSS / JS.
const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const read = name => fs.readFileSync(path.join(root,name),'utf8');
const script = name => '<script>\n'+read(name).replace(/<\/script/gi,'<\\/script')+'\n</script>';
let html=read('index.html');
html=html.replace('<link rel="stylesheet" href="styles.css">','<style>\n'+read('styles.css')+'\n</style>');
// Inline scripts execute after the body, equivalent to the source's defer.
html=html.replace('  <script defer src="core.js"></script>\n','').replace('  <script defer src="automation.js"></script>\n','').replace('  <script defer src="species.js"></script>\n','').replace('  <script defer src="app.js"></script>\n','');
html=html.replace('</body>',script('core.js')+'\n'+script('automation.js')+'\n'+script('species.js')+'\n'+script('app.js')+'\n</body>');
html=html.replace('href="index.html"','href="#"');
fs.writeFileSync(path.join(root,'Plecotus.html'),html,'utf8');
console.log('Built Plecotus.html: a standalone browser tool.');
