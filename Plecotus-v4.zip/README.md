# Plecotus — classification des contacts de chauves-souris

Un outil local, en français, qui transforme un CSV Kaleidoscope en **nombres de contacts par espèce**, avec le nom scientifique et le nom français. Il présente le meilleur contact de chaque `AUTO-ID`, organise les vérifications manuelles, puis remplit `SEMIMANUAL ID` selon la procédure choisie pour le projet : validation des suggestions Kaleidoscope ou répartition au prorata des identifications manuelles. Le bilan détaillé distingue toujours les contacts manuels des attributions calculées. L'outil utilise le CSV ; il n'analyse pas les sons.

Les champs source, codes d'espèces et étiquettes importées restent inchangés. Les règles précédentes Prudent/Équilibré/Rapide ont été remplacées par cette procédure.

## Démarrer sans installation

1. Double-cliquez sur **`Plecotus.html`** pour l'ouvrir dans Edge, Chrome ou un navigateur récent. Ce fichier contient toute l'application. L'autre point d'entrée, `index.html`, nécessite de conserver `styles.css`, `core.js`, `automation.js`, `species.js` et `app.js` dans le même dossier.
2. Cliquez sur **Importer un CSV** et choisissez votre `id.csv`. **Découvrir un exemple** charge des contacts fictifs. Une valeur existante de `MANUAL ID` est considérée comme une vérification humaine ; une décision enregistrée dans Plecotus la remplace pour ce contact. Renseignez votre nom ou vos initiales une fois avec le réglage de vérificateur en haut de l'écran ou dans la fiche d'un contact : ils seront repris pour les contacts suivants.
3. Commencez par le meilleur contact de chaque espèce suggérée. Retrouvez son fichier, son canal et son décalage dans Kaleidoscope, examinez-le, puis confirmez ou corrigez l'identification. **Copier les coordonnées du fichier** facilite cette recherche.
4. Si la référence confirme l'`AUTO-ID`, que strictement plus de la moitié des contacts de cet `AUTO-ID` ont un `MATCH RATIO` strictement supérieur à 0,6 et que le code n'est pas dans la liste d'exclusion du projet, tous les contacts reçoivent leur `AUTO-ID` dans `SEMIMANUAL ID`. Une autre décision humaine éventuellement renseignée sur une ligne conserve la priorité pour son résultat final et le bilan.
5. Sinon, la sélection proposée porte par défaut sur **20 % de tous les contacts de cet AUTO-ID**, arrondis à l'entier supérieur, référence comprise. Elle répartit les contrôles entre les classes de ratio. Le pourcentage est réglable ; vous pouvez ajouter, retirer ou remplacer des contacts, et **Adapter l’objectif à ma sélection** pour vérifier plus ou moins de lignes dans ce groupe. Retirer une ligne ne réduit pas automatiquement l'objectif : adaptez-le explicitement ou vérifiez d'autres contacts. **Objectif manuel en contacts** permet aussi de saisir directement la cible puis de cliquer sur **Appliquer l’objectif** ; **Reprendre la sélection proposée** restaure la recommandation et l'objectif par défaut.
6. Lorsque la référence et l'échantillon choisi sont renseignés, les contacts restants reçoivent des étiquettes **au prorata de toutes les vérifications manuelles du groupe**. Vous pouvez encore vérifier n'importe quel contact : les résultats calculés et les totaux sont recalculés en conservant les décisions humaines.
7. Consultez le tableau d'activité à trois colonnes : **Nom scientifique**, **Nom vernaculaire**, **Nombre de contacts**. Les comptes reprennent les décisions humaines en priorité, puis les attributions calculées. Le bilan détaillé conserve séparément le bruit, les résultats incertains et les contacts en attente. Les `NoID`, `Noise` et lignes sans `AUTO-ID` restent à vérifier individuellement dans cette version.
8. Utilisez régulièrement **Enregistrer le projet**. Le JSON conserve le CSV, les décisions, les brouillons, les règles et les choix d'échantillon. **Ouvrir un projet enregistré** recalcule les résultats ; les anciens projets v1/v2 conservent leur travail manuel en adoptant la nouvelle procédure.
9. Exportez le rapport d'activité **`activites_chiropteres.csv`** lorsque tous les contacts ont un résultat. Il contient uniquement les trois colonnes du tableau, séparées par des points-virgules, en UTF-8 avec BOM pour l'ouverture dans un tableur. Les identifications incertaines restent séparées du rapport et leur nombre est indiqué dans l'interface ; elles n'empêchent pas l'export lorsque plus aucun contact n'attend de résultat.
10. Dans **Exporter les résultats**, **Résultats avec SEMIMANUAL ID · CSV** produit un fichier dont le nom se termine par `-semi-manuel.csv`, avec les décisions humaines dans `MANUAL ID` et les attributions calculées dans `SEMIMANUAL ID`. Les autres exports fournissent les contacts classés avec leur provenance, le bilan détaillé, les seules identifications manuelles, le journal et les contrôles restant à vérifier. Gardez aussi le CSV original et la sauvegarde JSON.

Aucune installation, connexion Internet, compte ou droit administrateur n'est nécessaire. Seuls les liens vers les documents externes nécessitent Internet.

## Règles de la procédure

Le périmètre est **l'ensemble du CSV pour chaque espèce AUTO-ID**, même si les dossiers ou nuits diffèrent. Importez séparément les jeux de données que vous souhaitez traiter indépendamment. Chaque ligne reste un contact distinct ; les segments d'un même fichier ne sont pas fusionnés.

Le meilleur contact est déterminé par `MATCHING` décroissant, puis `MATCH RATIO` décroissant, puis `MARGIN` décroissant et enfin le numéro de ligne source croissant. Le classement est reproductible et ne garantit pas que l'espèce soit correcte. Les valeurs absentes ou invalides sont placées après les valeurs exploitables.

La liste d'exclusion de cette version est exactement celle fournie pour ce projet :

`BARBAR, RHIFER, RHIHIP, MYOBEC, MYODAS, MYOMYO, MYOEMA, NYCNOC, NYCLEI`.

Cette liste est fixe dans cette version ; le pourcentage, les cibles et la sélection des contacts restent réglables. Elle constitue le périmètre d'exclusion de la procédure, pas un inventaire réglementaire exhaustif. La [méthodologie](METHODS.md) donne les références et précise la différence entre cette liste et le tableau de sensibilité de la note DEMNA/DNF de 2012.

Pour le contrôle par échantillonnage, la référence compte dans la cible. La sélection initiale répartit les contrôles entre les classes de ratio 0–0,2, 0,2–0,4, 0,4–0,6, 0,6–0,8 et 0,8–1, ainsi qu'une classe pour les valeurs absentes ou invalides. Les quotas suivent les effectifs des classes, avec arrondi par les plus forts restes et présence obligatoire de la référence. Un petit échantillon peut laisser une classe sans contrôle. La sélection est reproductible. Une modification manuelle de l'échantillon peut réduire sa représentativité : les effectifs par classe restent consultables.

La répartition au prorata est une **estimation des effectifs**, matérialisée par une étiquette sur chaque ligne restante. Elle n'identifie pas acoustiquement chaque enregistrement non examiné. Par exemple, 10 % A / 80 % B / 10 % C parmi les vérifications donnent 8 A / 64 B / 8 C sur 80 lignes restantes. Pour les petits nombres, la méthode des plus forts restes conserve exactement le nombre de contacts à attribuer. Les incertitudes et groupes d'espèces restent explicites et peuvent eux aussi être propagés proportionnellement.

Les détails des conditions, du classement, de l'arrondi, de la provenance et des champs Kaleidoscope sont dans [METHODS.md](METHODS.md).

## Rapport d'activité et nom du vérificateur

Le rapport regroupe les formes reconnues d'une même espèce — code Kaleidoscope, nom scientifique ou nom français — en une seule ligne, en additionnant leurs contacts. Il utilise un catalogue des espèces européennes. La sérotine commune est affichée comme **Eptesicus serotinus** ; la forme **Cnephaeus serotinus** est reconnue comme un alias. Les groupes reconnus, tels que **Myotis sp. / Murin indéterminé**, restent des groupes et ne sont pas transformés en espèces précises. Une étiquette inconnue garde son texte avec **Nom non renseigné** dans la colonne française. Les complexes ou noms avec `cf.` ou `?` ne sont pas réduits à une seule espèce.

Le bruit, les contacts en attente et les identifications non résolues ou incertaines ne figurent pas parmi les espèces du tableau d'activité. Leurs effectifs restent indiqués à côté du tableau et dans le bilan détaillé. Le rapport peut contenir des contacts attribués statistiquement ; leur origine reste disponible dans les exports détaillés.

Le nom du vérificateur est mémorisé dans ce navigateur, y compris lorsque vous importez un autre CSV. Une modification du réglage global ou du champ de la fiche devient le nom proposé pour les prochaines décisions. Les auteurs des décisions déjà enregistrées sont conservés. À l'ouverture d'un projet, son nom de vérificateur est repris seulement si aucune préférence locale n'existe ; les sauvegardes JSON conservent aussi ce réglage.

## Fichiers et conservation des données

- L'import accepte les séparateurs virgule, point-virgule et tabulation, les cellules entre guillemets, les notes sur plusieurs lignes, les marques BOM UTF-8/UTF-16, les variantes courantes des en-têtes et les virgules décimales dans les CSV au point-virgule. Un fichier UTF-8 invalide est décodé en Windows-1252 avec un avertissement. Les en-têtes dupliqués ou ambigus et les données mal formées sont rejetés.
- L'ordre et les cellules source sont conservés. Le CSV des identifications manuelles écrit seulement les décisions enregistrées dans `MANUAL ID`, en ajoutant cette colonne si nécessaire. Les valeurs calculées restent distinctes dans `SEMIMANUAL ID` et les colonnes de provenance du CSV des contacts classés ; elles ne deviennent pas des décisions humaines.
- L'export du bilan détaillé sépare les nombres manuels et calculés, et compte chaque ligne une seule fois. Les incertitudes, le bruit et les résultats en attente restent visibles. Le rapport d'activité à trois colonnes totalise les étiquettes d'espèces ou de groupes et indique séparément les effectifs exclus dans l'interface. Un contrôle terminé peut conserver des identifications non résolues.
- L'export normalise les guillemets, sauts de ligne et encodages : il n'est pas identique octet par octet au fichier source. Les préambules, commentaires et lignes vides ne sont pas réémis. Conservez le fichier original.
- Le texte ajouté aux exports complémentaires est protégé contre l'interprétation comme formule par les tableurs. Les valeurs source restent intactes. Le journal utilise des horodatages ISO en UTC ; l'interface affiche l'heure locale du navigateur.
- Les fichiers audio, leurs métadonnées et `settings.ini` ne sont pas modifiés. L'outil n'écrit pas d'étiquettes dans les enregistrements.
- Les données restent dans le navigateur. Le stockage local facilite la reprise, mais peut être vidé, bloqué ou saturé. Utilisez les sauvegardes JSON pour conserver votre travail. Ouvrir un autre jeu de données propose une sauvegarde lorsque des décisions ou brouillons existent.
- L'entrée est limitée à 50 Mo, avec 50 contacts par page. Les grands jeux de données peuvent ralentir l'interface ou dépasser le stockage disponible avant cette limite.

Kaleidoscope **Lite** sert à visualiser et valider les sons ; une nouvelle analyse Auto-ID nécessite **Pro** ou sa version d'essai. Les CSV sans `AUTO-ID` restent utilisables pour une identification manuelle s'ils comportent un champ de nom de fichier reconnu.

## Développement facultatif

Si Node.js est disponible, lancez `node preview.cjs` et ouvrez `http://127.0.0.1:4173`. Le serveur écoute uniquement sur la boucle locale ; Ctrl+C l'arrête. Cette étape est facultative.

Lancez `node --test tests/core.test.cjs tests/automation.test.cjs tests/species.test.cjs` pour les tests de lecture, classement, contrôles, répartitions, regroupement des noms et conservation des totaux. `node bundle.cjs` reconstruit le fichier autonome. `Plecotus-v4.zip` contient l'application, ces documents, les fichiers source et les tests.

Les données de test sont fictives. Aucun véritable CSV ni son de l'utilisateur n'a encore été fourni ; la compatibilité avec votre version de Kaleidoscope et la qualité des effectifs estimés restent à mesurer sur vos enregistrements. Les comptes portent sur des contacts, pas sur le nombre de chauves-souris individuelles.
