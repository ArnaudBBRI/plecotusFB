(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./activity-chart.js'));
  else root.BatActivityExport = factory(root.BatActivityChart);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (Chart) {
  'use strict';

  const WIDTH = 1200, MAX_SIDE = 8192, MAX_PIXELS = 16000000;
  const counts = new Intl.NumberFormat('fr-BE');
  const percentages = new Intl.NumberFormat('fr-BE', { maximumFractionDigits: 1 });
  const escape = value => String(value == null ? '' : value)
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/g, '')
    .replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));

  // Hard-wrap even a single long CSV label. Conservative character limits fit
  // the column with common Unicode fonts; no row or legend is truncated.
  function wrap(value, limit) {
    const words = String(value).trim().split(/\s+/u), lines = [];
    let line = '';
    for (const word of words) {
      const chunks = Array.from(word);
      if (line && Array.from(line).length + 1 + chunks.length <= limit) {
        line += ' ' + word;
        continue;
      }
      if (line) { lines.push(line); line = ''; }
      while (chunks.length > limit) lines.push(chunks.splice(0, limit).join(''));
      line = chunks.join('');
    }
    if (line) lines.push(line);
    return lines.length ? lines : [''];
  }

  function text(x, y, value, size, attributes) {
    return `<text x="${x}" y="${y}" font-size="${size || 15}"${attributes ? ' ' + attributes : ''}>${escape(value)}</text>`;
  }

  function metadata(options, total) {
    const details = [`${counts.format(total)} contacts représentés (hors Noise).`];
    const counters = [];
    for (const [key, label] of [['ignoredNoise', 'Noise ignorés'], ['totalContacts', 'contacts dans le fichier'], ['pendingContacts', 'contacts en attente de classification']]) {
      if (options[key] == null) continue;
      if (typeof options[key] !== 'number' || !Number.isFinite(options[key]) || options[key] < 0) {
        throw new RangeError('Les compteurs du graphique doivent être des nombres positifs ou nuls.');
      }
      counters.push(`${counts.format(options[key])} ${label}`);
    }
    if (counters.length) details.push(counters.join(' · '));
    details.push(options.provisional || options.pendingContacts > 0
      ? 'Bilan provisoire : la classification comporte encore des contacts en attente.'
      : 'Bilan final.');
    return details;
  }

  function labels(row, limit) {
    const scientific = row.scientificName || row.frenchName || 'Identification non renseignée';
    return [
      ...wrap(scientific, limit).map(value => ({ value, scientific: true })),
      ...(row.scientificName && row.frenchName ? wrap(row.frenchName, limit).map(value => ({ value, scientific: false })) : [])
    ];
  }

  function tooltip(row) {
    return `${row.scientificName || row.frenchName} : ${counts.format(row.contacts)} contacts (${percentages.format(row.percentage)} %)`;
  }

  function rowLabels(row, lines, x, y) {
    return lines.map((line, index) => text(x, y + index * 22, line.value, line.scientific ? 15 : 14,
      `${line.scientific && row.isSpecies ? 'font-style="italic" ' : ''}fill="${line.scientific ? '#17352e' : '#607269'}"`)).join('');
  }

  function pie(data, top) {
    const parts = [], cx = 220, cy = top + 198, radius = 164;
    if (data.rows.length === 1) {
      parts.push(`<circle data-series="0" cx="${cx}" cy="${cy}" r="${radius}" fill="${data.rows[0].color}"><title>${escape(tooltip(data.rows[0]))}</title></circle>`);
    } else {
      let angle = -Math.PI / 2;
      data.rows.forEach((row, index) => {
        const end = index === data.rows.length - 1 ? Math.PI * 1.5 : angle + row.proportion * Math.PI * 2;
        const path = `M ${cx} ${cy} L ${cx + radius * Math.cos(angle)} ${cy + radius * Math.sin(angle)} A ${radius} ${radius} 0 ${end - angle > Math.PI ? 1 : 0} 1 ${cx + radius * Math.cos(end)} ${cy + radius * Math.sin(end)} Z`;
        parts.push(`<path data-series="${index}" d="${path}" fill="${row.color}" stroke="#fff" stroke-width="2" stroke-linejoin="round"><title>${escape(tooltip(row))}</title></path>`);
        angle = end;
      });
    }
    parts.push(text(cx, cy + radius + 34, 'Répartition hors Noise', 14, 'text-anchor="middle" fill="#607269"'));
    let y = top + 25;
    for (const row of data.rows) {
      const lines = labels(row, 34);
      parts.push(`<g data-legend="${escape(row.scientificName || row.frenchName)}"><rect x="442" y="${y - 13}" width="16" height="16" rx="3" fill="${row.color}"/>${rowLabels(row, lines, 476, y)}`);
      parts.push(text(1160, y, counts.format(row.contacts), 16, 'text-anchor="end" font-weight="700"'));
      parts.push(text(1160, y + 22, `${percentages.format(row.percentage)} %`, 14, 'text-anchor="end" fill="#607269"'));
      parts.push('</g>');
      y += Math.max(2, lines.length) * 22 + 22;
    }
    return { parts, bottom: Math.max(top + 425, y) };
  }

  function bars(data, top) {
    const parts = [];
    let y = top + 23;
    for (const [index, row] of data.rows.entries()) {
      const lines = labels(row, 53);
      parts.push(`<g data-legend="${escape(row.scientificName || row.frenchName)}"><rect x="40" y="${y - 13}" width="16" height="16" rx="3" fill="${row.color}"/>${rowLabels(row, lines, 74, y)}`);
      parts.push(text(1160, y, `${counts.format(row.contacts)} contacts · ${percentages.format(row.percentage)} %`, 15, 'text-anchor="end" font-weight="700"'));
      y += lines.length * 22;
      parts.push(`<rect x="40" y="${y}" width="1120" height="17" rx="4" fill="#edf2ef"/>`);
      parts.push(`<rect data-series="${index}" x="40" y="${y}" width="${1120 * row.proportion}" height="17" rx="4" fill="${row.color}"><title>${escape(tooltip(row))}</title></rect></g>`);
      y += 45;
    }
    return { parts, bottom: y };
  }

  function svg(rows, mode, options) {
    options = options || {};
    const data = Chart.prepare(rows), parts = [];
    const title = options.title || 'Répartition des contacts par espèce';
    let y = 54;
    for (const line of wrap(title, 38)) { parts.push(text(40, y, line, 28, 'font-weight="700"')); y += 34; }
    parts.push(text(40, y, mode === 'bar' ? 'Graphique en barres' : 'Camembert', 15, 'fill="#607269"')); y += 28;
    const details = metadata(options, data.total);
    for (const line of details.flatMap(value => wrap(value, 74))) {
      parts.push(text(40, y, line, 14, 'fill="#607269"')); y += 22;
    }
    y += 22;
    if (data.total) {
      const chart = mode === 'bar' ? bars(data, y) : pie(data, y);
      parts.push(...chart.parts); y = chart.bottom;
    } else {
      parts.push(text(40, y + 24, 'Aucun contact attribué à une espèce à afficher.', 16));
      y += 72;
    }
    const width = WIDTH, height = Math.ceil(y + 32);
    const description = [...details, ...data.rows.map(tooltip)].join(' ');
    return { width, height, svg: `<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-labelledby="activity-export-title activity-export-description"><title id="activity-export-title">${escape(title)}</title><desc id="activity-export-description">${escape(description)}</desc><rect width="${width}" height="${height}" fill="#fff"/><g font-family="Arial, Helvetica, sans-serif" fill="#17352e">${parts.join('')}</g></svg>` };
  }

  function formatInfo(format) {
    const name = String(format || 'svg').toLowerCase();
    if (name === 'svg') return { extension: 'svg', mimeType: 'image/svg+xml' };
    if (name === 'png') return { extension: 'png', mimeType: 'image/png' };
    if (name === 'jpeg' || name === 'jpg') return { extension: 'jpeg', mimeType: 'image/jpeg' };
    throw new RangeError('Format image non pris en charge. Choisissez PNG, JPEG ou SVG.');
  }

  async function rasterize(source, format, options) {
    const info = formatInfo(format);
    if (!source || typeof source.svg !== 'string' || !Number.isFinite(source.width) || !Number.isFinite(source.height) || source.width <= 0 || source.height <= 0) {
      throw new TypeError('Les dimensions du graphique à exporter sont invalides.');
    }
    if (info.extension === 'svg') return { ...source, ...info, blob: new Blob([source.svg], { type: info.mimeType }) };
    if (typeof document === 'undefined' || typeof Image === 'undefined' || !URL.createObjectURL) {
      throw new Error('L’export PNG ou JPEG nécessite un navigateur. Le format SVG reste disponible.');
    }
    const quality = options && options.quality != null ? options.quality : 0.92;
    if (typeof quality !== 'number' || !Number.isFinite(quality) || quality < 0 || quality > 1) throw new RangeError('La qualité JPEG doit être comprise entre 0 et 1.');
    const scale = Math.min(1, MAX_SIDE / source.width, MAX_SIDE / source.height, Math.sqrt(MAX_PIXELS / (source.width * source.height)));
    const width = Math.max(1, Math.floor(source.width * scale)), height = Math.max(1, Math.floor(source.height * scale));
    const url = URL.createObjectURL(new Blob([source.svg], { type: 'image/svg+xml' }));
    let picture, canvas;
    try {
      picture = new Image();
      await new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error('La préparation du graphique a pris trop de temps. Essayez le format SVG.')), 30000);
        picture.onload = () => { clearTimeout(timer); resolve(); };
        picture.onerror = () => { clearTimeout(timer); reject(new Error('Le graphique ne peut pas être converti en image. Essayez le format SVG.')); };
        try { picture.src = url; } catch (error) { clearTimeout(timer); reject(error); }
      });
      canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
      const context = canvas.getContext('2d');
      if (!context || !canvas.toBlob) throw new Error('L’export image n’est pas disponible dans ce navigateur. Essayez le format SVG.');
      context.fillStyle = '#fff'; context.fillRect(0, 0, width, height);
      context.drawImage(picture, 0, 0, width, height);
      const blob = await new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error('L’export image a pris trop de temps. Essayez le format SVG.')), 30000);
        try {
          canvas.toBlob(value => {
            clearTimeout(timer);
            if (!value) reject(new Error('L’export image a échoué. Essayez le format SVG.'));
            else resolve(value);
          }, info.mimeType, quality);
        } catch (error) { clearTimeout(timer); reject(error); }
      });
      if (blob.type !== info.mimeType) throw new Error('Ce navigateur ne prend pas en charge ce format image. Essayez PNG ou SVG.');
      return { blob, ...info, width, height };
    } finally {
      URL.revokeObjectURL(url);
      if (picture) { picture.onload = null; picture.onerror = null; picture.src = ''; }
      if (canvas) { canvas.width = 1; canvas.height = 1; }
    }
  }

  async function exportBlob(rows, mode, format, options) {
    return rasterize(svg(rows, mode, options), format, options);
  }

  return Object.freeze({ svg, rasterize, exportBlob });
});
