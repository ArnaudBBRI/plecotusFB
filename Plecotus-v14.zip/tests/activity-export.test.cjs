const test = require('node:test');
const assert = require('node:assert/strict');
const Chart = require('../activity-chart.js');
const Export = require('../activity-export.js');

const sample = [
  { scientificName: 'Pipistrellus pipistrellus', frenchName: 'Pipistrelle commune', contacts: 80, isSpecies: true },
  { scientificName: 'Myotis dasycneme', frenchName: 'Murin des marais', contacts: 10, isSpecies: true },
  { scientificName: 'Myotis sp.', frenchName: 'Murin indéterminé', contacts: 10 }
];

test('autonomous pie SVG preserves every label, count and palette without mutating activity rows', () => {
  const original = structuredClone(sample);
  const result = Export.svg(sample, 'pie', { ignoredNoise: 7, totalContacts: 107, pendingContacts: 0 });
  assert.equal(result.width, 1200);
  assert.ok(result.height > 500);
  assert.match(result.svg, /xmlns="http:\/\/www.w3.org\/2000\/svg"/);
  assert.match(result.svg, new RegExp(`viewBox="0 0 ${result.width} ${result.height}"`));
  assert.match(result.svg, /fill="#fff"/);
  assert.match(result.svg, /100 contacts représentés \(hors Noise\)/);
  assert.match(result.svg, /7 Noise ignorés · 107 contacts dans le fichier/);
  assert.match(result.svg, /Bilan final/);
  assert.equal((result.svg.match(/data-series=/g) || []).length, 3);
  assert.equal((result.svg.match(/data-legend=/g) || []).length, 3);
  for (const row of Chart.prepare(sample).rows) {
    assert.ok(result.svg.includes(row.scientificName));
    assert.ok(result.svg.includes(row.frenchName));
    assert.ok(result.svg.includes(`fill="${row.color}"`));
    assert.ok(result.svg.includes(`${row.contacts} contacts (${row.percentage} %)`));
  }
  assert.match(result.svg, /font-style="italic"/);
  assert.doesNotMatch(result.svg, /foreignObject|<style|<script|https:\/\//);
  assert.deepEqual(sample, original);
});

test('bars share the pie denominator and include all original scientific and French labels', () => {
  const result = Export.svg(sample, 'bar');
  assert.match(result.svg, /Graphique en barres/);
  assert.equal((result.svg.match(/data-series=/g) || []).length, 3);
  for (const [index, row] of Chart.prepare(sample).rows.entries()) {
    assert.ok(result.svg.includes(`data-series="${index}"`));
    assert.ok(result.svg.includes(`width="${1120 * row.proportion}"`));
    assert.ok(result.svg.includes(row.frenchName));
  }
  assert.match(result.svg, /80 contacts · 80 %/);
  assert.match(result.svg, /10 contacts · 10 %/);
  assert.doesNotMatch(result.svg, /<path|NaN|Infinity/);
});

test('single species draws a full circle and empty or all Noise inputs have a clear empty state', () => {
  assert.match(Export.svg([sample[0]]).svg, /<circle data-series="0"/);
  assert.match(Export.svg([sample[0]]).svg, /80 contacts \(100 %\)/);
  for (const mode of ['pie', 'bar']) {
    const result = Export.svg([{ scientificName: 'Noise', contacts: 99 }], mode);
    assert.match(result.svg, /0 contacts représentés \(hors Noise\)/);
    assert.match(result.svg, /Aucun contact attribué à une espèce/);
    assert.doesNotMatch(result.svg, /data-series=|data-legend=|NaN|Infinity/);
    assert.ok(result.height > 200);
  }
});

test('Noise and zero counts never enter percentages, totals or species legends', () => {
  const input = [...sample, { scientificName: 'Noise', contacts: 500 }, { scientificName: 'Bruit', contacts: 30 }, { scientificName: 'ignored', category: 'noise', contacts: 20 }, { scientificName: 'zero', contacts: 0 }];
  for (const mode of ['pie', 'bar']) {
    const result = Export.svg(input, mode);
    assert.equal((result.svg.match(/data-legend=/g) || []).length, 3);
    assert.match(result.svg, /100 contacts représentés/);
    assert.match(result.svg, /80 contacts \(80 %\)/);
    assert.doesNotMatch(result.svg, /500 contacts|30 contacts|20 contacts|data-legend="zero"/);
  }
});

test('untrusted labels and titles cannot add markup, event handlers or external resources', () => {
  const row = { scientificName: '<script>bad & "quoted"</script>', frenchName: "<img onerror='bad'>", contacts: 3 };
  for (const mode of ['pie', 'bar']) {
    const result = Export.svg([row], mode, { title: '<image href="https://invalid.example"/>\u0001' });
    assert.doesNotMatch(result.svg, /<script|<img|<image|\u0001/);
    assert.match(result.svg, /&lt;script&gt;bad &amp; &quot;quoted&quot;&lt;\/script&gt;/);
    assert.match(result.svg, /&lt;img onerror=&#39;bad&#39;&gt;/);
    assert.match(result.svg, /&lt;image href=&quot;https:\/\/invalid\.example&quot;\/&gt;/);
  }
});

test('large legends grow instead of dropping rows and long words wrap without losing text', () => {
  const longWord = 'W'.repeat(160);
  const rows = Array.from({ length: 65 }, (_, i) => ({ scientificName: `${longWord} taxon${i}`, frenchName: `Dénomination française complète pour l’espèce numéro ${i}`, contacts: i + 1 }));
  for (const mode of ['pie', 'bar']) {
    const result = Export.svg(rows, mode);
    assert.equal((result.svg.match(/data-series=/g) || []).length, rows.length);
    assert.equal((result.svg.match(/data-legend=/g) || []).length, rows.length);
    assert.ok(result.height > 6000);
    for (let i = 0; i < rows.length; i++) assert.ok(result.svg.includes(`taxon${i}`));
    assert.doesNotMatch(result.svg, /…/);
    const ys = [...result.svg.matchAll(/\by="([0-9.]+)"/g)].map(match => Number(match[1]));
    assert.ok(Math.max(...ys) < result.height);
    assert.match(result.svg, /2\s145 contacts représentés/);
  }
});

test('provisional and imported Noise counters are included without changing chart geometry', () => {
  const final = Export.svg(sample, 'bar');
  const pending = Export.svg(sample, 'bar', { ignoredNoise: 4, totalContacts: 110, pendingContacts: 6, provisional: true });
  assert.match(pending.svg, /Bilan provisoire/);
  assert.match(pending.svg, /6 contacts en attente de classification/);
  assert.match(pending.svg, /100 contacts représentés/);
  const widths = output => [...output.matchAll(/data-series="\d+"[^>]*width="([^\"]+)"/g)].map(match => match[1]);
  assert.deepEqual(widths(pending.svg), widths(final.svg));
  for (const ignoredNoise of [-1, NaN, Infinity, '2']) assert.throws(() => Export.svg(sample, 'pie', { ignoredNoise }), RangeError);
});

test('SVG download works without canvas and raster errors do not prevent a later SVG export', async () => {
  const result = await Export.exportBlob(sample, 'pie', 'svg');
  assert.equal(result.mimeType, 'image/svg+xml');
  assert.equal(result.extension, 'svg');
  assert.equal(result.blob.type, 'image/svg+xml');
  assert.match(await result.blob.text(), /Pipistrellus pipistrellus/);
  await assert.rejects(() => Export.exportBlob(sample, 'pie', 'png'), /nécessite un navigateur/);
  await assert.rejects(() => Export.exportBlob(sample, 'bar', 'gif'), /Format image non pris en charge/);
  assert.equal((await Export.exportBlob(sample, 'bar', 'svg')).extension, 'svg');
});
