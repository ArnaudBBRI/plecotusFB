﻿# Tests sans Pester, sans ouverture de Kaleidoscope, compatibles PowerShell 5.1.
$ErrorActionPreference = 'Stop'
. (Join-Path (Split-Path $PSScriptRoot -Parent) 'plecotus-local.ps1') -LibraryOnly
$script:TestCount = 0

function Assert-Equal {
    param($Actual, $Expected, [string]$Description)
    if ($Actual -cne $Expected) { throw "$Description : attendu [$Expected], obtenu [$Actual]." }
    $script:TestCount++
}

function Assert-Throws {
    param([scriptblock]$Action, [string]$Description)
    $thrown = $false
    try { & $Action | Out-Null }
    catch { $thrown = $true }
    if (-not $thrown) { throw "$Description : un rejet était attendu." }
    $script:TestCount++
}

function Parse-TestRequest {
    param([string]$Text)
    $stream = New-Object System.IO.MemoryStream
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $stream.Write($bytes, 0, $bytes.Length)
    $stream.Position = 0
    try { return Read-PlecotusRequest -Stream $stream }
    finally { $stream.Dispose() }
}

$testDirectory = Join-Path $PSScriptRoot ('windows-launcher-fixture-' + [Guid]::NewGuid().ToString('N'))
[void][System.IO.Directory]::CreateDirectory($testDirectory)
$exePath = Join-Path $testDirectory 'kaleidoscope.exe'
$wavPath = Join-Path $testDirectory "contact de l'étang & accent é.wav"
[System.IO.File]::WriteAllText($exePath, 'fichier fictif, ne pas executer')
[System.IO.File]::WriteAllText($wavPath, 'fichier fictif')
try {
    Assert-Equal (Get-PlecotusAbsolutePath $exePath executable) $exePath 'Chemin exe absolu existant'
    Assert-Equal (Get-PlecotusAbsolutePath $wavPath audio) $wavPath 'Chemin WAV avec espaces et accent'
    Assert-Equal (Get-PlecotusAbsolutePath ($wavPath.Replace('\', '/')) audio) $wavPath 'Separateurs Windows normalises'
    Assert-Equal (Get-PlecotusWavArgument $wavPath) ('"' + $wavPath + '"') 'Un seul argument WAV entre guillemets'
    foreach ($path in @('contact.wav', '.\contact.wav', 'C:contact.wav', '\contact.wav',
        'https://example.org/contact.wav', 'file:///C:/contact.wav',
        '\\?\C:\contact.wav', '\\.\C:\contact.wav', 'C:\NUL.wav',
        'C:\contact.wav:flux', 'C:\contact".wav', "C:\contact`n.wav", "C:\contact`0.wav", 'C:\*.wav')) {
        Assert-Throws { Get-PlecotusAbsolutePath $path audio } "Chemin refuse : $path"
    }
    Assert-Throws { Get-PlecotusAbsolutePath (Join-Path $testDirectory 'cmd.exe') executable } 'Executables differents refuses'
    Assert-Throws { Get-PlecotusAbsolutePath (Join-Path $testDirectory 'kaleidoscope-cli.exe') executable } 'CLI batch refusee'
    Assert-Throws { Get-PlecotusAbsolutePath $exePath audio } 'Audio non WAV refuse'
    Assert-Throws { Get-PlecotusAbsolutePath (Join-Path $testDirectory 'absent.wav') audio } 'WAV absent refuse'
    Assert-Throws { Get-PlecotusAbsolutePath '\\serveur-inexistant-plecotus\partage\contact.wav' audio } 'Partage absent refuse'

    $request = Parse-TestRequest "GET /api/status HTTP/1.1`r`nHost: 127.0.0.1:4174`r`n`r`n"
    Assert-Equal $request.Target '/api/status' 'Route HTTP lue'
    $status = (Invoke-PlecotusRequest $request).Body | ConvertFrom-Json
    Assert-Equal $status.app 'plecotus-local' 'Marqueur de compagnon'
    Assert-Equal $status.launchAvailable $true 'Etat disponible'
    $request.Headers.host = 'malicious.example:4174'
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 403 'Protection Host / DNS rebinding'
    Assert-Throws { Parse-TestRequest "GET / HTTP/1.1`r`nHost: 127.0.0.1:4174`r`nHost: example.org`r`n`r`n" } 'En-tetes doubles refuses'
    Assert-Throws { Parse-TestRequest "POST /api/kaleidoscope HTTP/1.1`r`nHost: 127.0.0.1:4174`r`nTransfer-Encoding: chunked`r`n`r`n" } 'Transfer-Encoding refuse'
    Assert-Throws { Parse-TestRequest "POST /api/kaleidoscope HTTP/1.1`r`nHost: 127.0.0.1:4174`r`nContent-Length: 32769`r`n`r`n" } 'Corps borne'
    Assert-Throws { Parse-TestRequest "POST /api/kaleidoscope HTTP/1.1`r`nHost: 127.0.0.1:4174`r`nContent-Length: -1`r`n`r`n" } 'Longueur negative refusee'
    Assert-Throws { Parse-TestRequest "POST /api/kaleidoscope HTTP/1.1`r`nHost: 127.0.0.1:4174`r`nContent-Length: 5`r`n`r`n{}" } 'Corps incomplet refuse'
    Assert-Throws { Parse-TestRequest ('GET / HTTP/1.1' + "`r`nX-Long: " + ('a' * 16384)) } 'En-tetes bornes'

    $script:PlecotusToken = 'jeton-fictif'
    $request = @{ Method = 'POST'; Target = '/api/kaleidoscope'; Body = '{}'; Headers = @{ host = '127.0.0.1:4174'; 'content-type' = 'application/json' } }
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 403 'Absence Origin / jeton refusee'
    $request.Headers.origin = 'http://127.0.0.1:4174'
    $request.Headers['x-plecotus-token'] = 'mauvais-jeton'
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 403 'Mauvais jeton refuse'
    $request.Headers['x-plecotus-token'] = $script:PlecotusToken
    $request.Headers.origin = 'http://example.org'
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 403 'Autre Origin refusee'
    $request.Headers.origin = 'http://127.0.0.1:4174'
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 422 'Champs JSON obligatoires'
    $request.Body = '{invalid'
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 422 'JSON invalide refuse'
    $request.Body = '{"executable":"cmd.exe","file":"contact.wav"}'
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 422 'Commande arbitraire refusee sans lancement'
    $request.Headers['content-type'] = 'text/plain'
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 415 'Content-Type verifie'
    $request.Target = '/api/stop'
    Assert-Equal (Invoke-PlecotusRequest $request).Stop $true 'Arret authentifie'
    $request.Headers['x-plecotus-token'] = 'autre'
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 403 'Arret protege par jeton'

    $request = @{ Method = 'GET'; Target = '/Plecotus.html'; Body = ''; Headers = @{ host = '127.0.0.1:4174' } }
    $htmlResult = Invoke-PlecotusRequest $request
    Assert-Equal $htmlResult.StatusCode 200 'HTML autonome servi'
    Assert-Equal ($htmlResult.Body.Contains('<meta name="plecotus-local-token" content="jeton-fictif">')) $true 'Jeton injecte'
    $request.Target = '/METHODS.md'
    $methodsResult = Invoke-PlecotusRequest $request
    Assert-Equal $methodsResult.StatusCode 200 'Guide local accessible'
    Assert-Equal $methodsResult.ContentType 'text/plain; charset=utf-8' 'Guide Markdown servi comme texte'
    $request.Target = '/app.js'
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 404 'Autres fichiers non exposes'
    $request.Target = '/../README.md'
    Assert-Equal (Invoke-PlecotusRequest $request).StatusCode 404 'Parcours des dossiers refuse'
    $stream = New-Object System.IO.MemoryStream
    try {
        Write-PlecotusResponse -Stream $stream -Result (New-PlecotusResult -Data @{ ok = $true })
        $response = [System.Text.Encoding]::UTF8.GetString($stream.ToArray())
        Assert-Equal ($response.Contains("X-Frame-Options: DENY`r`n")) $true 'Protection contre les frames'
        Assert-Equal ($response.Contains("X-Content-Type-Options: nosniff`r`n")) $true 'Protection MIME'
        Assert-Equal ($response.Contains('Access-Control-Allow-Origin')) $false 'Pas de CORS permissif'
    }
    finally { $stream.Dispose() }
    Write-Output "$script:TestCount tests du compagnon Windows réussis ; aucun lancement natif."
}
finally {
    [System.IO.File]::Delete($wavPath)
    [System.IO.File]::Delete($exePath)
    [System.IO.Directory]::Delete($testDirectory)
}
