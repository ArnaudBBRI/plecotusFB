# Bat contact review: method for version 1

This helper organizes a Kaleidoscope CSV into a guided manual review. The current goal is **a reviewed outcome for every contact recorded in Belgium**, including contacts marked Noise or NoID. It does not identify a bat from the CSV measurements alone. The reviewer inspects the recording in Kaleidoscope and records the result here.

## What Kaleidoscope supplies

Kaleidoscope Lite is free and supports spectrogram viewing, measurements, manual labels, conversion and bat noise filtering. Generating new bat species Auto-ID results requires Pro. An existing Auto-ID CSV can be used for this review workflow; the helper does not generate or replace the Pro classifier. See the official [feature comparison](https://www.wildlifeacoustics.com/products/kaleidoscope-pro).

For Belgium, check that any upstream automatic analysis used the European classifier and an appropriate region/species selection. Preserve the classifier version and processing settings, ideally the original `settings.ini`. The official [European species-code list](https://answers.wildlifeacoustics.com/r/en-US/Bat-Auto-ID-Performance-and-Supported-Species/Bat-Auto-ID-Supported-Species-and-Abbreviated-Codes) describes classifier coverage; inclusion in that list does not establish occurrence at the recording location.

An `id.csv` contact can represent an entire recording **or a segment**. Consequently, a filename is not a unique contact identifier: channel and offset also matter. The helper retains each source row separately, including repeated recording locators. Zero-crossing measurements summarize detected pulses; they do not describe every detail visible in a full-spectrum spectrogram. These are official format characteristics described in the [2025 user guide](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope03192025.pdf).

## Ranking: the proposed review order

Version 1 groups contacts by **input directory + folder + night + suggested AUTO-ID**. It uses `DATE-12` as the night key, then `DATE` if unavailable. A missing date creates an explicit unknown-night group. Folder is a practical deployment proxy; it should contain one site/deployment if site separation matters. This grouping is our workflow choice, not a Kaleidoscope identification rule. Using `DATE` can divide one night at midnight; the tool flags this fallback.

Within each group, compare the following keys in order:

1. `MATCHING`, descending.
2. `MATCH RATIO`, descending.
3. `MARGIN`, descending.
4. Original contact row, ascending, for a reproducible tie.

The first differing key decides the order; this is not a weighted score. Kaleidoscope's historical native sorting used AUTO-ID followed by descending matching pulses and match ratio ([official 4.3.1 guide, p. 50](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope.pdf)). The night/folder groups, margin tiebreaker and stable row tiebreaker are our additions. Margin comparisons stay within one suggested species.

The first species contact in a group is an **anchor**: a useful recording to inspect early and establish a visual reference. Its rank means strongest evidence according to these fields, not a guaranteed correct identification or best acoustic recording. For example, 20 matching pulses out of 40 rank ahead of 2 out of 2. The first has more supporting pulses but may contain mixed bats; inspect both its ratio and alternates.

Missing numeric fields sort after usable values; remaining keys still apply. A missing ratio can be calculated for ranking when both counts are usable, pulses are positive and matching does not exceed pulses. The source cell stays unchanged. Malformed values and inconsistent counts receive data flags. No universal pulse count, ratio cutoff, margin threshold or confidence percentage is asserted.

## Field reference

Headers vary by Kaleidoscope version and user MetaForm. The helper recognizes common spelling variants, preserves original columns, and displays additional fields without interpreting them. The following describes common `id.csv` fields, not an exhaustive list of every customizable schema field.

**Location and time** — official meanings from the [2025 user guide](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope03192025.pdf). These locate/group contacts; none is a confidence score.

| Field | Meaning |
|---|---|
| `INDIR`, `OUTDIR` | Input/output root paths |
| `FOLDER` | Input subfolder relative to root |
| `IN FILE` | Input filename |
| `CHANNEL` | Input channel; 0 left, 1 right |
| `OFFSET` | Segment start, seconds into input |
| `DURATION` | File/segment length, seconds |
| `OUT FILE FS`, `OUT FILE ZC` | Full-spectrum / zero-crossing output filename |
| `DATE`, `TIME`, `HOUR` | Recording date, time, hour |
| `DATE-12`, `TIME-12`, `HOUR-12` | Recording timestamp shifted back 12 hours |

**Identification and call measurements** — definitions from the [official legacy guide, pp. 19–22](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope.pdf) and [Wildlife Acoustics metadata specification](https://www.wildlifeacoustics.com/SCHEMA/GUANO.html). Ranking direction is our stated implementation unless specified as an official interpretation.

| Field | Meaning | Review use |
|---|---|---|
| `AUTO-ID` / `AUTO ID` | File-level species suggestion | Group only |
| `PULSES` | Pulse count used by classifier summary | Context; ratio denominator |
| `MATCHING` | Pulses supporting AUTO-ID | Descending |
| `MATCH RATIO` | MATCHING divided by PULSES | Descending |
| `MARGIN` | Uncalibrated confidence indicator | Descending within species only |
| `ALTERNATE 1`, `ALTERNATE 2`, legacy `ALTERNATES` | Other candidates; potentially multiple bats | Inspect ambiguity |
| `N` | Detected pulses underlying averages | Context |
| `Fc` | Characteristic frequency, kHz | Call shape |
| `Sc` | Body slope, octaves/second | Call shape |
| `Dur` | Mean pulse duration, ms | Call shape |
| `Fmax`, `Fmin` | Mean pulse maximum/minimum frequency, kHz | Call shape |
| `Fmean` | Mean pulse time-weighted frequency, kHz | Call shape |
| `TBC` | Mean start-to-start interval, ms | Call sequence |
| `Fk`, `Tk` | Knee frequency, kHz / time, ms | Call shape |
| `S1` | Initial slope, octaves/second | Call shape |
| `Tc` | Time to characteristic point | Call shape; check units |
| `Qual` | Call smoothness measure | Lower means smoother; unused in ranking |
| `FILES` | Constant 1 for counting | Counting only |
| `MANUAL ID` | Human-assigned identification | Preserve/review |

Frequency, duration, slope and timing have **no universal better direction**. They vary with species and call behavior. `Qual` is not a percent probability of a correct ID. `DURATION` and `Dur` describe different things.

The guides inconsistently describe `PULSES` as all usable detected pulses versus species-classified pulses; `N` explicitly denotes total detections. Do not assume equality. Legacy CSV/metadata documents give `Tc` in milliseconds, while newer database schema labels can use seconds. Preserve the header and value; verify units before comparison. These discrepancies are why version 1 does not build further scores from acoustic averages.

**Other common metadata** — official [metadata definitions](https://www.wildlifeacoustics.com/SCHEMA/GUANO.html). These provide provenance or recording context; none affects ranking.

| Fields / variants | Meaning |
|---|---|
| `LAT`, `LON`, `LATITUDE`, `LONGITUDE` | Recording coordinates |
| `MODEL`, `SERIAL`, `FIRMWARE`, `PREFIX` | Recorder identity/version/file prefix |
| `NOTES` / `NOTE` | Free-form recording notes |
| `ORGID`, `USERID` | Source organization/user |
| `REVIEW ORGID`, `REVIEW USERID` | Review organization/user |
| `INPATHMD5` | Internal input-path lookup hash |
| Classifier/version/settings fields | Upstream analysis provenance |

## Review every contact

The guided queue highlights anchors and contacts requiring an identification, while allowing every row to be opened. Filtered views are navigation aids. Completing the anchor view does not complete the dataset.

For each contact:

1. Locate the recording, channel and segment offset in Kaleidoscope. Inspect the spectrogram and use playback/measurements as appropriate.
2. Accept the suggested species only if the recording supports it, or enter a corrected identification.
3. If species cannot be resolved, record a defensible group, such as `Myotis sp.`, or an unresolved bat outcome. A reviewed uncertainty is useful evidence.
4. For actual non-bat noise, record a reviewed Noise outcome. Flag ambiguous or mixed recordings and explain the reason in notes.
5. Save the decision and proceed. Imported manual labels remain available; verify their provenance before treating them as completed work.

Reviewing all **NoID** contacts is appropriate here: NoID is the classifier declining an identification, not proof of absent bats. Reviewing all **Noise** contacts is also part of this project's scope. Wildlife Acoustics explains that Noise depends on signal settings and can include bat calls too poor for usable zero-crossing detection ([2024 guide, p. 39](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope11112024.pdf)). Neither category is deleted or silently treated as manually confirmed.

Confirming one anchor never assigns its label to other contacts. Each remaining row retains its individual review status. Wildlife Acoustics recommends manually verifying suggested IDs because call similarity, noise and environmental context cause errors ([Auto-ID guidance](https://www.wildlifeacoustics.com/products/kaleidoscope/automatic-bat-identification)). Its published performance tests excluded ambiguous, poor-quality and simultaneous multi-bat recordings ([performance limitations](https://answers.wildlifeacoustics.com/r/en-US/Bat-Auto-ID-Performance-and-Supported-Species/About-the-Kaleidoscope-Classifier-Performance-Table)).

Sampling could be explored later for a separately specified presence-only study, with a justified audit design. It is not the completion criterion for this version, whose goal is labeling every contact.

## Interpretation and audit trail

Keep suggested AUTO-ID, manual outcome and review status distinct. Preserve source rows and numerical values; export reviewed results with their provenance. A rank, a reviewed species group and a verified species are different outputs. Recordings do not directly count individual bats, and a file can contain multiple bats. The helper accelerates the ordering and bookkeeping; the recording and the reviewer's judgment provide the identification evidence.

## Primary sources

All sources were checked on 10 October 2026. Source links above point to Wildlife Acoustics publications:

- [Kaleidoscope product features](https://www.wildlifeacoustics.com/products/kaleidoscope-pro).
- [Kaleidoscope User Guide, 19 March 2025](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope03192025.pdf).
- [Kaleidoscope Pro User Guide, 11 November 2024](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope11112024.pdf).
- [Kaleidoscope 4.3.1 documentation, 2017](https://www.wildlifeacoustics.com/uploads/user-guides/Kaleidoscope.pdf), historical sorting and field definitions.
- [Wildlife Acoustics GUANO metadata specification](https://www.wildlifeacoustics.com/SCHEMA/GUANO.html).
- [Supported species and abbreviated codes](https://answers.wildlifeacoustics.com/r/en-US/Bat-Auto-ID-Performance-and-Supported-Species/Bat-Auto-ID-Supported-Species-and-Abbreviated-Codes).
- [Automatic bat identification guidance](https://www.wildlifeacoustics.com/products/kaleidoscope/automatic-bat-identification).
- [Classifier performance-table interpretation and limitations](https://answers.wildlifeacoustics.com/r/en-US/Bat-Auto-ID-Performance-and-Supported-Species/About-the-Kaleidoscope-Classifier-Performance-Table).
