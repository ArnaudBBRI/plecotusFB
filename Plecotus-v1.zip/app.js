/* Browser-only review UI. No recording or CSV is transmitted. */
(() => {
  'use strict';
  const C = window.BatReviewCore;
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const checked = status => ['confirmed','corrected','uncertain','noise'].includes(status);
  const state = {source:null,data:null,parsed:null,rowById:new Map(),guided:[],speciesLabels:[],labelOptions:[],reviews:{},drafts:{},reviewer:'',tab:'pending',species:'',search:'',sort:'guided',selected:null,page:0,autoNext:true,undo:[],encodingWarning:''};
  const STORAGE = 'plecotus.project.v1';
  const PAGE_SIZE = 50;
  let toastTimer, saveTimer, pendingOpen;
  const num = n => n == null ? '—' : Number(n).toLocaleString('en-GB', {maximumFractionDigits:3});
  const ratio = n => n == null ? '—' : (n * 100).toFixed(1) + '%';
  const review = row => state.reviews[row.id] || {status:row.manualId ? 'imported' : 'unreviewed',label:row.manualId || '',notes:'',reviewer:'',timestamp:''};
  function toast(message) { $('toast').textContent=message; $('toast').hidden=false; clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('toast').hidden=true,5000); }
  function project() { return {format:'plecotus-review',version:1,source:state.source,reviews:state.reviews,drafts:state.drafts,reviewer:state.reviewer,encodingWarning:state.encodingWarning,exportedAt:new Date().toISOString()}; }
  function persist() {
    if (!state.source) return;
    try { localStorage.setItem(STORAGE,JSON.stringify(project())); $('save-status').textContent='Saved in this browser'; }
    catch { $('save-status').textContent='Save a project backup'; toast('Browser storage is unavailable or full. Use Save project to keep your decisions.'); }
  }
  function schedulePersist() { clearTimeout(saveTimer); $('save-status').textContent='Saving draft…'; saveTimer=setTimeout(persist,350); }
  function download(name,body,type) {
    const url=URL.createObjectURL(new Blob([body],{type})); const a=document.createElement('a'); a.href=url; a.download=name; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  const baseName = () => (state.source?.name || 'id.csv').replace(/\.[^.]+$/,'');
  function saveProject() { if(!state.source) return; download(baseName()+'.plecotus.json',JSON.stringify(project(),null,2),'application/json'); toast('Project backup downloaded. It includes the CSV, decisions and drafts.'); }
  function requestOpen(callback) {
    if(state.source && (Object.keys(state.reviews).length || Object.keys(state.drafts).length)) {pendingOpen=callback;$('replace-dialog').showModal();} else callback();
  }
  function acceptSource(source,extras={}) {
    if(!source || typeof source.text!=='string' || typeof source.name!=='string') throw new Error('The project has no valid source CSV.');
    const parsed=C.parseCSV(source.text); const data=C.analyze(parsed.headers,parsed.records);
    if(!data.rows.length) throw new Error('This CSV contains no contacts.');
    if(data.columns.file < 0) throw new Error('Could not find IN FILE (or File) in the CSV. Import an id.csv or a compatible Kaleidoscope export.');
    const reviews={}; const drafts={}; const rowById=new Map(data.rows.map(r=>[r.id,r]));
    for(const [id,r] of Object.entries(extras.reviews || {})) {
      if(!rowById.has(id) || !r || !checked(r.status) || typeof r.label!=='string' || !r.label.trim()) throw new Error('The project contains an invalid review decision.');
      const row=rowById.get(id);
      if(r.status==='confirmed' && (row.kind!=='species' || r.label.trim()!==row.autoId)) throw new Error('A confirmed project label does not match the source suggestion.');
      if(r.status==='noise' && r.label!=='Noise') throw new Error('A Noise decision has an inconsistent label.');
      reviews[id]={status:r.status,label:r.label,notes:String(r.notes || ''),reviewer:String(r.reviewer || ''),timestamp:String(r.timestamp || '')};
    }
    for(const [id,d] of Object.entries(extras.drafts || {})) if(rowById.has(id) && d && typeof d==='object') drafts[id]={status:['confirmed','corrected','uncertain','noise'].includes(d.status)?d.status:'',label:String(d.label || ''),notes:String(d.notes || ''),reviewer:String(d.reviewer || '')};
    const priority=r=>r.isAnchor?0:['noid','unclassified'].includes(r.kind)?1:r.kind==='species'?2:3;
    const guided=[...data.rows].sort((a,b)=>priority(a)-priority(b)||a.autoId.localeCompare(b.autoId)||a.groupKey.localeCompare(b.groupKey)||a.rank-b.rank||a.index-b.index);
    const speciesLabels=[...new Set(data.rows.filter(r=>r.kind==='species').map(r=>r.autoId))].sort();
    const labelOptions=[...new Set([...speciesLabels,'Unidentified bat','Myotis sp.','Plecotus sp.','Pipistrellus sp.','Nyctalus / Eptesicus / Vespertilio group'])].sort();
    Object.assign(state,{source,parsed,data,rowById,guided,speciesLabels,labelOptions,reviews,drafts,reviewer:String(extras.reviewer || ''),encodingWarning:String(extras.encodingWarning || ''),tab:'pending',species:'',search:'',selected:null,page:0,undo:[]});
    state.selected=visibleRows()[0]?.id || data.rows[0].id;
    $('search').value=''; $('sort').value=state.sort; $('welcome').hidden=true; $('workspace').hidden=false;
    ['save-project','export'].forEach(id=>$(id).disabled=false); render(); persist();
  }
  async function loadCSV(file) {
    if(!file) return;
    try {
      if(file.size>50*1024*1024) throw new Error('Please use a CSV smaller than 50 MB for this browser-only version.');
      const bytes=new Uint8Array(await file.arrayBuffer()); let text,warning='';
      if(bytes[0]===255 && bytes[1]===254) text=new TextDecoder('utf-16le').decode(bytes);
      else if(bytes[0]===254 && bytes[1]===255) text=new TextDecoder('utf-16be').decode(bytes);
      else { try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{text=new TextDecoder('windows-1252').decode(bytes);warning='CSV decoded as Windows-1252. Exports use UTF-8; check accented text before reopening.';} }
      acceptSource({name:file.name,text},{encodingWarning:warning});
      toast(`Imported ${state.data.rows.length.toLocaleString()} contacts. Every contact still needs its own review.`);
    } catch(error) {toast(error.message);} finally {$('csv-file').value='';}
  }
  async function loadProject(file) {
    if(!file) return;
    try {
      if(file.size>75*1024*1024) throw new Error('This project is too large for the first version.');
      const p=JSON.parse(await file.text()); if(p.format!=='plecotus-review'||p.version!==1) throw new Error('Choose a version 1 Plecotus project JSON.');
      acceptSource(p.source,p);toast('Project opened with its decisions and drafts.');
    }catch(error){toast(error.message);}finally{$('project-file').value='';}
  }
  function visibleRows() {
    if(!state.data) return [];
    const query=state.search.toLowerCase();
    return (state.sort==='source'?state.data.rows:state.guided).filter(r=>{
      const rev=review(r);
      if(state.species && r.autoId!==state.species) return false;
      if(query && ![r.file,r.folder,r.autoId,rev.label,rev.notes,r.date,r.time,r.offset].join(' ').toLowerCase().includes(query)) return false;
      if(state.tab==='pending') return !checked(rev.status);
      if(state.tab==='reviewed') return checked(rev.status);
      if(state.tab==='anchors') return r.isAnchor;
      if(state.tab==='noid') return ['noid','unclassified'].includes(r.kind);
      if(state.tab==='noise') return r.kind==='noise';
      return true;
    });
  }
  function render() {
    if(!state.data) return;
    const rows=state.data.rows; const done=rows.filter(r=>checked(review(r).status)).length; const unsure=rows.filter(r=>review(r).status==='uncertain').length;
    const species=state.speciesLabels;
    const counts=new Map();for(const row of rows){if(!counts.has(row.autoId))counts.set(row.autoId,{total:0,pending:0});const count=counts.get(row.autoId);count.total++;if(!checked(review(row).status))count.pending++;}
    $('dataset-name').textContent=state.source.name;
    $('dataset-caption').textContent=`${state.source.name} · ${rows.length.toLocaleString()} contacts · ${state.source.name==='example-id.csv'?'Synthetic example data · ':''}all contacts require review`;
    $('sidebar-count').textContent=rows.length.toLocaleString(); $('progress-label').textContent=`${done.toLocaleString()} / ${rows.length.toLocaleString()}`; $('progress-fill').style.width=(100*done/rows.length)+'%';
    $('pending-count').textContent=rows.length-done;
    $('stats').innerHTML=[['Contacts',rows.length,'≋',''],['Automatic species labels',species.length,'◇',''],['Reference picks',rows.filter(r=>r.isAnchor).length,'↗',''],['Uncertain decisions',unsure,'?','amber']].map(([label,value,symbol,cls])=>`<div class="stat ${cls}"><div><div class="value">${value.toLocaleString()}</div><div class="label">${label}</div></div><span class="symbol">${symbol}</span></div>`).join('');
    const labels=[...species,...[...new Set(rows.filter(r=>r.kind!=='species').map(r=>r.autoId))].sort()];
    $('species-list').innerHTML=labels.map(label=>{const count=counts.get(label);return `<button class="nav-button ${state.species===label?'active':''}" data-species="${esc(label)}"><b>${esc(label)}</b><span>${count.pending} / ${count.total}</span></button>`;}).join('');
    $('all-groups').classList.toggle('active',!state.species);
    document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===state.tab));
    const warnings=[...(state.parsed.warnings || []),...(state.data.warnings || []),...(state.encodingWarning?[state.encodingWarning]:[])].map(w=>typeof w==='string'?w:JSON.stringify(w));
    const imported=rows.filter(r=>review(r).status==='imported').length;
    if(imported) warnings.push(`${imported} existing manual labels were preserved as imported; they are not counted as checked in this project.`);
    $('data-banner').hidden=!warnings.length;
    if(warnings.length) $('data-banner').innerHTML=`<details><summary>${warnings.length} import / data notices — inspect before relying on the ranking</summary><ul>${warnings.slice(0,50).map(w=>`<li>${esc(w)}</li>`).join('')}</ul>${warnings.length>50?'<p>Showing the first 50 notices. Contact-specific flags are available on each contact and in the review log.</p>':''}</details>`;
    renderQueue();renderDetail();
  }
  function renderQueue() {
    const rows=visibleRows(); const pages=Math.max(1,Math.ceil(rows.length/PAGE_SIZE)); state.page=Math.min(state.page,pages-1);
    $('queue-count').textContent=`${rows.length.toLocaleString()} contacts${state.species?' · '+state.species:''}`;
    $('page-label').textContent=rows.length?`${state.page*PAGE_SIZE+1}–${Math.min((state.page+1)*PAGE_SIZE,rows.length)} of ${rows.length.toLocaleString()}`:'No contacts in this filter';
    $('prev-page').disabled=state.page===0; $('next-page').disabled=state.page>=pages-1;
    $('queue-body').innerHTML=rows.slice(state.page*PAGE_SIZE,(state.page+1)*PAGE_SIZE).map(r=>{const rev=review(r);return `<tr class="${state.selected===r.id?'selected':''}" data-row="${r.id}"><td><button class="contact-button" data-select="${r.id}" title="${esc(r.file)}">${esc(r.file)}</button><div class="row-meta">${esc(r.autoId)} ${r.isAnchor?'<span class="pick-dot">REFERENCE</span>':''}${r.issues.length?'<span title="Data needs inspection">⚑</span>':''}</div><div class="row-sub">Row ${r.index+1} · ${esc(r.night || 'date missing')} · ch ${esc(r.channel || '—')} · offset ${esc(r.offset || '0')} s</div></td><td>${num(r.matching)}</td><td title="Matching / pulses; not an ID confidence">${ratio(r.ratio)}</td><td><span class="badge ${esc(rev.status)}">${esc(rev.status==='unreviewed'?'To review':rev.status[0].toUpperCase()+rev.status.slice(1))}</span>${state.drafts[r.id]?'<div class="row-sub">Draft</div>':''}</td></tr>`;}).join('') || '<tr><td colspan="4"><div class="empty-state">No contacts here. Choose another filter to continue.</div></td></tr>';
  }
  function locator(row) {
    const indir=state.data.columns.indir>=0?row.raw[state.data.columns.indir]:'';
    const folder=row.rawFolder || '';
    const separator=indir.includes('/') && !indir.includes('\\')?'/':'\\';
    const parts=[indir,folder,row.file].filter(Boolean);
    // Preserve leading UNC \\server and never duplicate the display fallback folder.
    return parts.map((part,i)=>i===0?part.replace(/[\\/]+$/,''):part.replace(/^[\\/]+|[\\/]+$/g,'')).join(separator);
  }
  function draft(row) {
    if(state.drafts[row.id]) return state.drafts[row.id];
    const rev=review(row);return {status:checked(rev.status)?rev.status:'',label:rev.label,notes:rev.notes,reviewer:rev.reviewer || state.reviewer};
  }
  function renderDetail() {
    const row=state.rowById.get(state.selected);
    if(!row){$('detail').innerHTML='<div class="empty-state">Select a contact to review.</div>';return;}
    const rev=review(row); const d=draft(row);
    const options=state.labelOptions;
    const issues=row.issues.map(i=>typeof i==='string'?i:JSON.stringify(i));
    const alternate=[row.alternate1,row.alternate2].filter(Boolean);
    $('detail').innerHTML=`<div class="detail-top"><span class="eyebrow">CONTACT ${row.index+1} · GROUP RANK ${row.rank}</span><span class="badge ${esc(rev.status)}">${esc(rev.status==='unreviewed'?'To review':rev.status)}</span></div><h2 class="detail-file">${esc(row.file)}</h2><div class="locator">${esc(row.folder || '(input root)')}<br>${esc(row.date || 'Date missing')} ${esc(row.time || '')} · channel ${esc(row.channel || '—')} · offset ${esc(row.offset || '0')} s</div><div class="locator-actions"><button id="copy-locator">Copy file locator ↗</button><button id="inspect-guide">How to inspect</button></div>${row.isAnchor?'<div class="detail-callout">Reference pick for this automatic label, folder and night. Inspect this contact to orient your review; other contacts still need checking.</div>':''}${alternate.length?`<div class="detail-callout warning">Alternative suggestions: ${alternate.map(esc).join(', ')}. Check for ambiguity or multiple bats.</div>`:''}${issues.length?`<div class="detail-callout warning">${issues.map(esc).join('<br>')}</div>`:''}<div class="metrics"><div><strong>${num(row.matching)}</strong><small>Matching pulses</small></div><div><strong>${num(row.pulses)}</strong><small>Pulses</small></div><div><strong>${ratio(row.ratio)}</strong><small>Match ratio${row.ratioSource==='derived'?' (derived)':''}</small></div><div><strong>${num(row.margin)}</strong><small>Margin</small></div></div><div class="suggestion"><div><span class="label">AUTOMATIC SUGGESTION</span><strong>${esc(row.autoId)}</strong></div><span>Not yet a verified species</span></div><div class="form-heading">Your manual decision</div><div class="decision-grid"><button type="button" data-decision="confirmed" class="${d.status==='confirmed'?'chosen':''}" ${row.kind!=='species'?'disabled':''}>✓ Confirm suggestion</button><button type="button" data-decision="corrected" class="${d.status==='corrected'?'chosen':''}">↗ Assign a label</button><button type="button" data-decision="uncertain" class="${d.status==='uncertain'?'chosen':''}">? Uncertain bat ID</button><button type="button" data-decision="noise" class="${d.status==='noise'?'chosen':''}">∅ Noise / no bat</button></div><label class="field-label" for="manual-label">Manual label · species, group or unresolved</label><input id="manual-label" list="species-options" value="${esc(d.label)}" placeholder="Choose a decision, then enter a label" ${['confirmed','noise'].includes(d.status)?'readonly':''}><datalist id="species-options">${options.map(o=>`<option value="${esc(o)}"></option>`).join('')}</datalist><div class="form-row"><label><span class="field-label">Reviewer</span><input id="reviewer" value="${esc(d.reviewer)}" placeholder="Name / initials"></label></div><label class="field-label" for="notes">Review notes</label><textarea id="notes" placeholder="Call shape, ambiguity, additional species…">${esc(d.notes)}</textarea><p class="draft-note">Save only after inspecting this contact in Kaleidoscope. “Uncertain” keeps the contact unresolved.</p><button class="primary detail-save" id="save-decision">Save decision${state.autoNext?' & next':''}</button><div class="detail-options"><label><input id="auto-next" type="checkbox" ${state.autoNext?'checked':''}>Advance after saving</label><button class="text-button" id="undo" ${state.undo.length?'':'disabled'}>Undo last save</button><button class="text-button" id="reset-decision">Return to review</button></div>${state.drafts[row.id]?'<p class="unsaved">Draft saved locally · decision not submitted yet</p>':''}${rev.timestamp?`<p class="draft-note">Saved ${esc(new Date(rev.timestamp).toLocaleString())}${rev.reviewer?' · '+esc(rev.reviewer):''}</p>`:''}<details class="raw-fields"><summary>All original CSV fields (${state.parsed.headers.length})</summary><dl>${state.parsed.headers.map((h,i)=>`<dt>${esc(h)}</dt><dd>${esc(row.raw[i]) || '—'}</dd>`).join('')}</dl></details>`;
    $('copy-locator').onclick=async()=>{const value=`${locator(row)}\nCSV data row: ${row.index+1}\nChannel: ${row.channel || '(missing)'}\nOffset: ${row.offset || '0'} s`;
      try{await navigator.clipboard.writeText(value);toast('File path, CSV row, channel and offset copied.');}catch{const input=document.createElement('textarea');input.value=value;document.body.append(input);input.select();const copied=document.execCommand('copy');input.remove();toast(copied?'File locator copied.':'Clipboard unavailable. Read the locator and original fields above.');}};
    $('inspect-guide').onclick=()=>{toast('In Kaleidoscope: File → Open Results… → your original CSV. Find this filename, then match its channel and offset. Inspect the spectrogram and zero-crossing view.');};
    document.querySelectorAll('[data-decision]').forEach(b=>b.onclick=()=>{
      captureDraft(); const selected=state.drafts[row.id];selected.status=b.dataset.decision;
      if(selected.status==='confirmed') selected.label=row.autoId;
      else if(selected.status==='noise') selected.label='Noise';
      else if(selected.status==='uncertain') selected.label='Unidentified bat';
      else if(['Noise','NoID','Unidentified bat',row.autoId].includes(selected.label)) selected.label='';
      renderDetail();schedulePersist();
      if(['corrected','uncertain'].includes(selected.status)) $('manual-label').focus();
    });
    ['manual-label','notes','reviewer'].forEach(id=>$(id).addEventListener('input',()=>{captureDraft();schedulePersist();}));
    $('auto-next').onchange=()=>{state.autoNext=$('auto-next').checked;$('save-decision').textContent='Save decision'+(state.autoNext?' & next':'');};
    $('save-decision').onclick=saveDecision; $('undo').onclick=undo;
    $('reset-decision').onclick=()=>{state.undo.push({id:row.id,previous:state.reviews[row.id] || null});delete state.reviews[row.id];delete state.drafts[row.id];render();persist();toast('Returned to review. Any original imported manual label is preserved.');};
  }
  function captureDraft() {
    const row=state.rowById.get(state.selected);if(!row || !$('manual-label')) return;
    const existing=draft(row);
    state.drafts[row.id]={status:existing.status,label:$('manual-label').value,notes:$('notes').value,reviewer:$('reviewer').value};
    state.reviewer=$('reviewer').value;
  }
  function saveDecision() {
    const row=state.rowById.get(state.selected);if(!row) return;
    captureDraft();const d=state.drafts[row.id];
    if(!checked(d.status)){toast('Choose a manual decision before saving.');return;}
    if(!d.label.trim()){toast('Enter a species, group or unresolved label.');$('manual-label').focus();return;}
    if(d.status==='confirmed' && row.kind!=='species'){toast('This contact has no species suggestion to confirm. Assign a label instead.');return;}
    const visible=visibleRows();const at=visible.findIndex(r=>r.id===row.id);const next=visible.slice(at+1).find(r=>!checked(review(r).status)) || visible.slice(0,at).find(r=>!checked(review(r).status));
    state.undo.push({id:row.id,previous:state.reviews[row.id] || null});
    state.reviews[row.id]={...d,label:d.status==='confirmed'?row.autoId:d.status==='noise'?'Noise':d.label.trim(),timestamp:new Date().toISOString()};delete state.drafts[row.id];
    if(state.autoNext && next) {state.selected=next.id;const remaining=visibleRows();state.page=Math.floor(Math.max(0,remaining.findIndex(r=>r.id===next.id))/PAGE_SIZE);}
    render();persist();toast(d.status==='uncertain'?'Saved as reviewed but unresolved.':'Decision saved for this contact.');
  }
  function undo() {const item=state.undo.pop();if(!item) return;if(item.previous) state.reviews[item.id]=item.previous;else delete state.reviews[item.id];delete state.drafts[item.id];state.selected=item.id;render();persist();toast('Last save undone.');}
  function selectRow(id) {state.selected=id;renderQueue();renderDetail();}
  function filterChanged() {state.page=0;const rows=visibleRows();if(!rows.some(r=>r.id===state.selected)) state.selected=rows[0]?.id || null;render();}
  const sidecarHeaders=['SOURCE ROW','INDIR','FOLDER','IN FILE','CHANNEL','OFFSET','DATE','TIME','NIGHT','AUTO ID','ORIGINAL MANUAL ID','REVIEW STATUS','REVIEW LABEL','REVIEWER','REVIEWED AT','NOTES','GROUP RANK','REFERENCE PICK','MATCHING','PULSES','MATCH RATIO','MARGIN','DATA ISSUES'];
  function sidecarRecord(row) {const rev=review(row);return [row.index+1,state.data.columns.indir>=0?row.raw[state.data.columns.indir]:'',row.rawFolder || '',row.file,row.channel,row.offset,row.date,row.time,row.night,row.autoId,row.manualId,rev.status,rev.label,rev.reviewer,rev.timestamp,rev.notes,row.rank,row.isAnchor?'yes':'no',row.matching??'',row.pulses??'',row.ratio??'',row.margin??'',row.issues.join(' | ')];}
  // Spreadsheet-safe text in sidecars; source CSV values must remain unchanged.
  const safe = value => /^[\t\r\n ]*[=+@-]/.test(String(value)) ? "'"+value : value;
  function exportSidecar(pending=false) {const rows=pending?state.data.rows.filter(r=>!checked(review(r).status)):state.data.rows;download(baseName()+(pending?'-remaining.csv':'-review-log.csv'),'\ufeff'+C.stringifyCSV(sidecarHeaders,rows.map(r=>sidecarRecord(r).map(safe)),','),'text/csv;charset=utf-8');}
  function exportID() {
    const headers=[...state.parsed.headers];let col=state.data.columns.manualId;if(col<0){col=headers.length;headers.push('MANUAL ID');}
    const records=state.data.rows.map(row=>{const raw=[...row.raw];while(raw.length<headers.length)raw.push('');const rev=review(row);if(checked(rev.status))raw[col]=rev.label;return raw;});
    download(baseName()+'-reviewed.csv','\ufeff'+C.stringifyCSV(headers,records,state.parsed.delimiter),'text/csv;charset=utf-8');toast('Reviewed CSV exported. Keep the original and verify this copy in Kaleidoscope.');
  }
  function demo() {
    const headers=['INDIR','FOLDER','IN FILE','CHANNEL','OFFSET','DURATION','DATE','TIME','DATE-12','AUTO ID','PULSES','MATCHING','MATCH RATIO','MARGIN','ALTERNATE 1','ALTERNATE 2','MANUAL ID','Fc','Sc','Dur','Fmax','Fmin','Qual'];
    const specs=[['PIPPIP',32,28,.875,1.8,''],['PIPPIP',12,10,.833,1.1,'PIPNAT'],['PIPPIP',3,3,1,.7,''],['PIPNAT',22,18,.818,1.3,'PIPPIP'],['PIPNAT',8,5,.625,.9,''],['NYCNOC',19,15,.789,1.6,'EPTSER'],['NYCNOC',6,2,.333,.2,'NYCLEI'],['MYODAU',14,9,.643,.8,'MYOMYS'],['MYODAU',4,2,.5,.3,''],['NoID',8,0,0,0,''],['NoID',15,0,0,0,''],['Noise',0,0,'',0,''],['Noise',1,0,0,0,''],['',5,'','','',''],['PIPPIP',24,20,.833,1.5,''],['PIPPIP',7,5,.714,.5,'']];
    const records=specs.map(([id,p,m,r,margin,alt],i)=>['C:\\BatSurvey\\Example',i<14?'site-A':'site-B',`REC_${i===15?'0015':String(i+1).padStart(4,'0')}_20260918_21${String(i*3).padStart(2,'0')}00.wav`,0,i===15?5:0,5,'2026-09-18',`21:${String(i*3).padStart(2,'0')}:00`,'2026-09-18',id,p,m,r,margin,alt,'',i===8?'Myotis sp.':'',id==='PIPPIP'?45.2:'',.5,3.2,72,41,8]);
    acceptSource({name:'example-id.csv',text:C.stringifyCSV(headers,records,',')});toast('Synthetic example loaded. These numbers are illustrative, not real recordings.');
  }
  $('upload').onclick=$('welcome-import').onclick=()=>requestOpen(()=>$('csv-file').click());
  $('csv-file').onchange=e=>loadCSV(e.target.files[0]);$('project-file').onchange=e=>loadProject(e.target.files[0]);
  $('open-project').onclick=()=>requestOpen(()=>$('project-file').click());
  $('load-demo').onclick=$('welcome-demo').onclick=()=>requestOpen(demo);
  $('save-project').onclick=saveProject;$('method').onclick=()=>$('guide-dialog').showModal();
  $('export').onclick=()=>{const done=state.data.rows.filter(r=>checked(review(r).status)).length;const drafts=Object.keys(state.drafts).length;$('export-caption').textContent=`${done} / ${state.data.rows.length} contacts reviewed. ${state.data.rows.length-done} still need checking.${drafts?' '+drafts+' drafts are not included as submitted decisions.':''}`;$('export-dialog').showModal();};
  $('export-id').onclick=exportID;$('export-audit').onclick=()=>exportSidecar();$('export-pending').onclick=()=>exportSidecar(true);
  document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$(b.dataset.close).close());
  $('cancel-replace').onclick=()=>{pendingOpen=null;$('replace-dialog').close();};
  function continueOpen(backup){if(backup)saveProject();const fn=pendingOpen;pendingOpen=null;$('replace-dialog').close();fn?.();}
  $('backup-replace').onclick=()=>continueOpen(true);$('continue-replace').onclick=()=>continueOpen(false);
  document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;filterChanged();});
  $('species-list').onclick=e=>{const button=e.target.closest('[data-species]');if(button){state.species=button.dataset.species;filterChanged();}};
  $('all-groups').onclick=()=>{state.species='';filterChanged();};
  $('search').oninput=e=>{state.search=e.target.value;filterChanged();};$('sort').onchange=e=>{state.sort=e.target.value;filterChanged();};
  $('queue-body').onclick=e=>{const row=e.target.closest('[data-row]');if(row)selectRow(row.dataset.row);};
  $('prev-page').onclick=()=>{state.page--;renderQueue();};$('next-page').onclick=()=>{state.page++;renderQueue();};
  document.addEventListener('keydown',e=>{
    if(!state.data || document.querySelector('dialog[open]'))return;
    if(e.ctrlKey && e.key==='Enter'){e.preventDefault();saveDecision();return;}
    if(e.ctrlKey||e.altKey||e.metaKey||['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))return;
    if(e.key.toLowerCase()==='j'||e.key.toLowerCase()==='k'){const rows=visibleRows();const at=rows.findIndex(r=>r.id===state.selected);const next=rows[at+(e.key.toLowerCase()==='j'?1:-1)];if(next){e.preventDefault();state.page=Math.floor(rows.indexOf(next)/PAGE_SIZE);selectRow(next.id);}}
  });
  window.addEventListener('pagehide',()=>{clearTimeout(saveTimer);if(state.source)persist();});
  try{const saved=localStorage.getItem(STORAGE);if(saved){const p=JSON.parse(saved);if(p.format==='plecotus-review'&&p.version===1){acceptSource(p.source,p);toast('Restored your last local project. Save a project file for a durable backup.');}}}catch(error){$('save-status').textContent='Browser restore unavailable';}
})();
