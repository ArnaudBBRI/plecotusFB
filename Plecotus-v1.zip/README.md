# Plecotus — bat contact review

A first version of a local helper for reviewing Kaleidoscope contacts from Belgium. It ranks existing CSV results, shows what still needs checking, and records each manual decision. It does not identify species from audio or CSV measurements.

## Start without installing anything

1. Double-click **`Plecotus.html`** to open it in Microsoft Edge, Chrome or another current browser. This file includes the app, so it works on its own. Alternatively open `index.html`, keeping `styles.css`, `core.js` and `app.js` beside it.
2. Click **Import CSV** and choose your Kaleidoscope `id.csv`. **Explore an example** loads clearly marked synthetic contacts.
3. Inspect each selected recording in Kaleidoscope: **File → Open Results…**, choose your original CSV, then match the filename, channel and segment offset. **Copy file locator** helps locate the recording.
4. Choose **Confirm suggestion**, **Assign a label**, **Uncertain bat ID**, or **Noise / no bat**. Add a reviewer and notes, then **Save decision & next**. Species groups and unresolved labels are allowed.
5. Use **Save project** regularly to download a durable JSON backup. **Open saved project** restores its original CSV, submitted decisions and unfinished drafts.
6. **Export results** provides an updated CSV, a complete review log and a remaining-contact queue. Keep the source CSV and reopen the reviewed copy in Kaleidoscope to verify a few entries.

No administrator privileges, runtime installation, account, internet connection or server are needed for this workflow. The built-in documentation has links to manufacturer references, which need internet access.

## Review policy and ranking

Every contact needs its own review, including NoID and Noise. Existing manual labels are retained with **Imported** status and are not assumed to have been checked in this project. The progress counter includes uncertain decisions as reviewed; the separate uncertain count shows those still unresolved.

Within each **AUTO-ID + input directory + folder + night** group, order by:

1. `MATCHING`, highest first.
2. `MATCH RATIO`, highest first.
3. `MARGIN`, highest first, used only within that species.
4. Original data row, lowest first.

Night uses `DATE-12`, falling back to `DATE`. Missing/invalid numeric values sort last. The first species contact in each group becomes a **reference pick**, not a verified ID or a confidence estimate. Guided order shows reference picks first, then unidentified contacts, remaining species contacts and Noise. CSV order remains available. Alternate suggestions and data problems appear in the contact pane.

The source-backed rationale, workflow assessment and field dictionary are in [METHODS.md](METHODS.md). There is no automatic propagation of one checked label to other recordings.

## Files and safeguards

- Import accepts comma, semicolon or tab CSVs, quoted cells, multiline notes, UTF-8/UTF-16 BOMs, common header variants and Belgian decimal commas in semicolon CSVs. Invalid UTF-8 is decoded as Windows-1252 with a notice. Duplicate/ambiguous headers or malformed data are rejected.
- Contacts retain their own source-row identity. Repeated filenames and segments are not collapsed.
- The updated CSV retains source row order, header names and raw cell values. Only submitted decisions change `MANUAL ID`; that column is added if absent. Quoting, newlines and encoding are normalized on export, so the file is not byte-for-byte identical. Preamble/comments and blank rows are not re-emitted. Keep the original file.
- The reviewed CSV contains no review-status columns. Keep the **review log** or **project JSON** to distinguish imported, unresolved and confirmed labels. Reimporting a reviewed CSV treats its labels as imported; reopening its project preserves review states.
- Sidecar CSV text is escaped for spreadsheet formula safety. The original values in the updated Kaleidoscope CSV are preserved. The review log uses UTC ISO timestamps; the interface displays the browser's local time.
- Audio files, audio metadata, Kaleidoscope's original CSV and `settings.ini` are not modified. CSV reloading does not synchronize labels into audio metadata.
- Data stays in your browser. Local storage is a convenience for the most recent dataset, tied to the browser and opening location. It may be blocked, cleared or full; use **Save project** for backups. Opening another dataset offers a backup when decisions/drafts exist. There is no cloud sync.
- Input size is limited to 50 MB. Queue pages contain 50 contacts. Very large datasets may still be slow, and browser storage can fill before this limit. The tool says to save a project when local storage fails.

Kaleidoscope **Lite** can be used for viewing and manual review. New bat Auto-ID analysis requires **Pro** or its trial. This helper uses whatever labels are already in your CSV; CSVs without AUTO-ID remain manually reviewable when they contain a recognized filename field.

## Optional developer preview and checks

If Node.js is already available, run `node preview.cjs` from this directory and open `http://127.0.0.1:4173`. The server listens only on loopback. Stop it with Ctrl+C. This is optional; no installation is needed to open the HTML directly.

Run the data-engine checks with `node --test tests/core.test.cjs`. They cover real import/export risks: dialects, quoting, original-value preservation, ranking, malformed counts, aliases, segment identity and missing values.

Run `node bundle.cjs` after changing source files to rebuild `Plecotus.html`. `Plecotus-v1.zip` contains the standalone tool, instructions, methodology and source files.

Version 1 has been checked with synthetic data and browser review interactions, including semicolon imports with decimal commas, quoted multiline notes, network-share paths, segment offsets, every review state, undo, local restore and project backups. No actual user `id.csv` or audio was supplied, so compatibility with your exact export and an end-to-end round trip through your installed Kaleidoscope version remains to be checked.
