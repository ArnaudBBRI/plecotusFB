// Verify real browser downloads against their saved project, without reproducing
// source CSV exports or relying on filenames as contact identities.
// node tests/export-check.cjs project.json reviewed.csv review-log.csv
const fs = require('node:fs');
const assert = require('node:assert/strict');
const Core = require('../core.js');

const [projectPath, reviewedPath, logPath] = process.argv.slice(2);
if (!projectPath || !reviewedPath || !logPath) {
  process.stderr.write('Usage: node tests/export-check.cjs project.json reviewed.csv review-log.csv\n');
  process.exitCode = 1;
} else {
  const project = JSON.parse(fs.readFileSync(projectPath, 'utf8'));
  assert.equal(project.format, 'plecotus-review');
  assert.equal(project.version, 1);
  const source = Core.parseCSV(project.source.text);
  const analysis = Core.analyze(source.headers, source.records);
  const updated = Core.parseCSV(fs.readFileSync(reviewedPath, 'utf8'));
  const log = Core.parseCSV(fs.readFileSync(logPath, 'utf8'));
  const reviewedStatuses = new Set(['confirmed', 'corrected', 'uncertain', 'noise']);
  const originalManualColumn = analysis.columns.manualId;
  const expectedHeaders = source.headers.slice();
  let manualColumn = originalManualColumn;
  if (manualColumn < 0) { manualColumn = expectedHeaders.length; expectedHeaders.push('MANUAL ID'); }
  assert.deepEqual(updated.headers, expectedHeaders, 'Export preserves all source headers and their order.');
  assert.equal(updated.records.length, source.records.length, 'No source contact is removed or merged.');
  assert.equal(log.records.length, source.records.length, 'Review log contains every source contact.');
  assert.equal(updated.delimiter, source.delimiter, 'Export preserves the detected source CSV dialect.');

  const logHeaders = ['SOURCE ROW', 'INDIR', 'FOLDER', 'IN FILE', 'CHANNEL', 'OFFSET', 'DATE', 'TIME', 'NIGHT', 'AUTO ID', 'ORIGINAL MANUAL ID', 'REVIEW STATUS', 'REVIEW LABEL', 'REVIEWER', 'REVIEWED AT', 'NOTES', 'GROUP RANK', 'REFERENCE PICK', 'MATCHING', 'PULSES', 'MATCH RATIO', 'MARGIN', 'DATA ISSUES'];
  assert.deepEqual(log.headers, logHeaders);
  const safe = value => /^[\t\r\n ]*[=+@-]/.test(String(value)) ? "'" + value : value;
  let changed = 0, checkedCount = 0, imported = 0;
  analysis.rows.forEach((row, index) => {
    const decision = project.reviews[row.id];
    const isReviewed = decision && reviewedStatuses.has(decision.status);
    const expected = row.raw.slice();
    while (expected.length < expectedHeaders.length) expected.push('');
    if (isReviewed) { expected[manualColumn] = decision.label; checkedCount++; }
    else if (row.manualId) imported++;
    assert.deepEqual(updated.records[index], expected, 'Only submitted MANUAL ID decisions may change source row ' + (index + 1) + '.');
    if (updated.records[index][manualColumn] !== (originalManualColumn < 0 ? '' : row.raw[originalManualColumn])) changed++;
    const status = isReviewed ? decision.status : row.manualId ? 'imported' : 'unreviewed';
    const expectedLog = [row.index + 1, row.indir, row.rawFolder, row.file, row.channel, row.offset, row.date, row.time, row.night, row.autoId, row.manualId, status, isReviewed ? decision.label : row.manualId || '', isReviewed ? decision.reviewer : '', isReviewed ? decision.timestamp : '', isReviewed ? decision.notes : '', row.rank, row.isAnchor ? 'yes' : 'no', row.matching ?? '', row.pulses ?? '', row.ratio ?? '', row.margin ?? '', row.issues.join(' | ')].map(value => String(safe(value == null ? '' : value)));
    assert.deepEqual(log.records[index], expectedLog, 'Audit record preserves contact identity and decision for source row ' + (index + 1) + '.');
  });
  process.stdout.write('Verified ' + analysis.rows.length + ' contacts: ' + checkedCount + ' submitted decisions, ' + changed + ' manual-label changes, ' + imported + ' untouched imported manual labels. All other source fields, row identities, channel/offset values and review-log fields match.\n');
}
