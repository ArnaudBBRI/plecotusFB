(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BatReviewPlan = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const valueAt = (collection, key) => collection instanceof Map ? collection.get(key) : collection && collection[key];

  // This describes the human workload without changing the classifier's
  // current queue. A reference may unlock a sample after it is checked; count
  // that sample now whenever direct validation is already impossible.
  function summarize(classification) {
    if (!classification || !Array.isArray(classification.groups) || !classification.byId) {
      throw new TypeError('Le plan de vérification exige un résultat de classification.');
    }
    const groups = classification.groups.map(group => {
      const required = new Set();
      for (const row of group.rows) {
        const assignment = valueAt(classification.byId, row.id);
        if (assignment && assignment.requiresReview) required.add(row.id);
      }
      const awaitingReference = group.mode === 'reference';
      const conditional = awaitingReference && group.kind === 'species' && group.majorityPass && !group.excluded;
      const sampling = group.kind === 'species' && (group.mode === 'proportion' && !group.canInfer || awaitingReference && !conditional);
      let remaining = required.size;
      if (sampling) {
        // Explicit sample picks remain mandatory even when imported labels or
        // additional reviews have already fulfilled the numeric quota.
        for (const id of group.selectedIds) {
          const assignment = valueAt(classification.byId, id);
          if (assignment && assignment.origin === 'pending') required.add(id);
        }
        // A user can remove picks while retaining a larger target. Preserve
        // that deficit in the plan instead of claiming the task is finished.
        remaining = Math.max(required.size, group.remainingSampleCount);
      }
      // Excluded Noise contacts are neither completed human reviews nor
      // remaining work. Genuine human decisions in their group still count.
      const completed = group.manualCount;
      return {
        key: group.key, autoId: group.autoId, kind: group.kind,
        completed, remaining, total: completed + remaining,
        awaitingReference, conditional
      };
    });
    const completed = groups.reduce((sum, group) => sum + group.completed, 0);
    const remaining = groups.reduce((sum, group) => sum + group.remaining, 0);
    return { groups, completed, remaining, total: completed + remaining };
  }

  return { summarize };
});
