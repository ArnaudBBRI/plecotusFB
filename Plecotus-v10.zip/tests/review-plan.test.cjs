const test = require('node:test');
const assert = require('node:assert/strict');
const Core = require('../core.js');
const A = require('../automation.js');
const Plan = require('../review-plan.js');

const headers = ['IN FILE', 'AUTO ID', 'MATCHING', 'MATCH RATIO', 'MANUAL ID'];
function data(count = 50, changes = {}) {
  const records = Array.from({ length: count }, (_, index) => {
    const values = { 'IN FILE': `contact-${index}.wav`, 'AUTO ID': 'NYCNOC', MATCHING: String(count - index), 'MATCH RATIO': '0.9', 'MANUAL ID': '', ...(typeof changes === 'function' ? changes(index) : changes) };
    return headers.map(header => values[header]);
  });
  return { headers, ...Core.analyze(headers, records) };
}
const checked = (label = 'NYCNOC') => ({ status: 'confirmed', label });
function plan(source, reviews = {}, policy = {}, drafts = {}, selections = {}) {
  return Plan.summarize(A.classify(source, reviews, policy, drafts, selections));
}

test('eligible references show one conditional check, while known exclusions expose the future sample', () => {
  const eligible = plan(data(50, { 'AUTO ID': 'PIPPIP' }));
  assert.equal(eligible.remaining, 1);
  assert.equal(eligible.total, 1);
  assert.equal(eligible.groups[0].conditional, true);
  assert.equal(eligible.groups[0].awaitingReference, true);
  const excluded = plan(data());
  assert.equal(excluded.completed, 0);
  assert.equal(excluded.remaining, 10);
  assert.equal(excluded.groups[0].conditional, false);
  assert.equal(excluded.groups[0].awaitingReference, true);
});

test('failed strict ratio majority exposes sampling before the reference is checked', () => {
  const source = data(50, index => ({ 'AUTO ID': 'PIPPIP', 'MATCH RATIO': index < 25 ? '0.9' : '0.6' }));
  const summary = plan(source);
  assert.equal(summary.remaining, 10);
  assert.equal(summary.groups[0].conditional, false);
  assert.equal(summary.groups[0].awaitingReference, true);
});

test('a confirmed excluded reference advances one of ten manual checks', () => {
  const source = data();
  const anchor = A.classify(source, {}).groups[0].anchorId;
  const summary = plan(source, { [anchor]: checked() });
  assert.equal(summary.completed, 1);
  assert.equal(summary.remaining, 9);
  assert.equal(summary.total, 10);
  assert.equal(summary.groups[0].awaitingReference, false);
});

test('an eligible reference correction expands the conditional plan to the actual sample', () => {
  const source = data(50, { 'AUTO ID': 'PIPPIP' });
  const anchor = A.classify(source, {}).groups[0].anchorId;
  const before = plan(source);
  const after = plan(source, { [anchor]: { status: 'corrected', label: 'MYODAU' } });
  assert.equal(before.total, 1);
  assert.equal(after.completed, 1);
  assert.equal(after.remaining, 9);
  assert.equal(after.total, 10);
  assert.equal(after.groups[0].conditional, false);
});

test('completed direct and proportional groups retain their human check counts with no remaining work', () => {
  const direct = data(50, { 'AUTO ID': 'PIPPIP' });
  const directAnchor = A.classify(direct, {}).groups[0].anchorId;
  const directPlan = plan(direct, { [directAnchor]: checked('PIPPIP') });
  assert.equal(directPlan.completed, 1);
  assert.equal(directPlan.remaining, 0);
  assert.equal(directPlan.groups.length, 1);
  const proportional = data();
  const reviews = Object.fromEntries(A.classify(proportional, {}).groups[0].selectedIds.map(id => [id, checked()]));
  const proportionalPlan = plan(proportional, reviews);
  assert.equal(proportionalPlan.completed, 10);
  assert.equal(proportionalPlan.remaining, 0);
  assert.equal(proportionalPlan.total, 10);
});

test('imported human labels and extra reviews count as completed, while unchecked selected contacts remain mandatory', () => {
  const source = data(10, index => ({ 'MANUAL ID': index < 3 ? 'NYCNOC' : '' }));
  const group = A.classify(source, {}).groups[0];
  const unchecked = source.rows.filter(row => !row.manualId).map(row => row.id);
  const selectedIds = [group.anchorId, unchecked[0], unchecked[1]];
  const summary = plan(source, { [unchecked[2]]: checked() }, {}, {}, { [group.key]: { selectedIds, sampleTarget: 2 } });
  assert.equal(summary.completed, 4, 'Three imported decisions plus the extra project check.');
  assert.equal(summary.remaining, 2, 'Quota is met, but both explicit pending picks still require reviews.');
  assert.equal(summary.total, 6);
});

test('explicit under-quota selections preserve the deficit after all selected contacts are checked', () => {
  const source = data();
  const group = A.classify(source, {}).groups[0];
  const selections = { [group.key]: { selectedIds: [group.anchorId] } };
  assert.equal(plan(source, {}, {}, {}, selections).remaining, 10);
  const summary = plan(source, { [group.anchorId]: checked() }, {}, {}, selections);
  assert.equal(summary.completed, 1);
  assert.equal(summary.remaining, 9);
  assert.equal(summary.total, 10);
});

test('drafts and invalid decisions outside the selected sample are counted without double counting selected drafts', () => {
  const source = data();
  const group = A.classify(source, {}).groups[0];
  const extra = source.rows.filter(row => !group.selectedIds.includes(row.id));
  const drafts = { [group.anchorId]: { label: 'NYCNOC' }, [extra[0].id]: { label: 'NYCNOC' } };
  const reviews = { [extra[1].id]: { status: 'confirmed', label: '' } };
  const summary = plan(source, reviews, {}, drafts);
  assert.equal(summary.remaining, 12, 'Ten selected contacts plus two separate mandatory repairs.');
  assert.equal(summary.completed, 0);
});

test('ready inference groups retain mandatory draft checks outside the finished sample', () => {
  const source = data();
  const group = A.classify(source, {}).groups[0];
  const reviews = Object.fromEntries(group.selectedIds.map(id => [id, checked()]));
  const extra = source.rows.find(row => !group.selectedIds.includes(row.id));
  const summary = plan(source, reviews, {}, { [extra.id]: { label: 'MYODAU' } });
  assert.equal(summary.completed, 10);
  assert.equal(summary.remaining, 1);
  assert.equal(summary.total, 11);
});

test('NoID and unclassified contacts retain individual checks while Noise is ignored by default', () => {
  const source = data(5, index => ({ 'AUTO ID': ['NoID', 'Noise', '', 'NoID', 'Noise'][index] }));
  const summary = plan(source, { [source.rows[0].id]: { status: 'corrected', label: 'PIPPIP' } });
  assert.deepEqual(summary.groups.map(group => group.kind), ['noid', 'noise', 'unclassified']);
  assert.deepEqual(summary.groups.map(group => [group.completed, group.remaining]), [[1, 1], [0, 0], [0, 1]]);
  assert.equal(summary.completed, 1);
  assert.equal(summary.remaining, 2);
  assert.equal(summary.total, 3);
  assert.ok(summary.groups.every(group => !group.conditional && !group.awaitingReference));
});

test('opting into Noise reviews restores every ignored contact to the human workload', () => {
  const source = data(5, index => ({ 'AUTO ID': ['NoID', 'Noise', '', 'NoID', 'Noise'][index] }));
  const summary = plan(source, { [source.rows[0].id]: { status: 'corrected', label: 'PIPPIP' } }, { ignoreNoise: false });
  assert.deepEqual(summary.groups.map(group => [group.completed, group.remaining]), [[1, 1], [0, 2], [0, 1]]);
  assert.equal(summary.completed, 1);
  assert.equal(summary.remaining, 4);
  assert.equal(summary.total, 5);
});

test('ignored Noise does not advance human progress or enlarge the planned denominator', () => {
  const source = data(102, index => ({ 'AUTO ID': index < 100 ? 'Noise' : 'PIPPIP' }));
  const classification = A.classify(source, {});
  const species = classification.groups.find(group => group.kind === 'species');
  const before = Plan.summarize(classification);
  assert.equal(before.completed, 0);
  assert.equal(before.remaining, 1);
  assert.equal(before.total, 1, 'One hundred ignored contacts do not become human checks.');
  const after = plan(source, { [species.anchorId]: checked('PIPPIP') });
  assert.equal(after.completed, 1);
  assert.equal(after.remaining, 0);
  assert.equal(after.total, 1);
  const noise = after.groups.find(group => group.kind === 'noise');
  assert.deepEqual([noise.completed, noise.remaining, noise.total], [0, 0, 0]);
});

test('actual manual decisions on Noise still count as completed while other Noise is ignored', () => {
  const source = data(4, index => ({ 'AUTO ID': 'Noise', 'MANUAL ID': index === 0 ? 'PIPPIP' : '' }));
  const summary = plan(source, { [source.rows[1].id]: { status: 'corrected', label: 'MYODAU' } });
  assert.equal(summary.completed, 2, 'Imported and saved acoustic corrections are real human reviews.');
  assert.equal(summary.remaining, 0);
  assert.equal(summary.total, 2);
  assert.deepEqual([summary.groups[0].completed, summary.groups[0].remaining], [2, 0]);
});

test('deliberate Noise drafts and invalid decisions remain mandatory without counting ignored rows', () => {
  const source = data(4, { 'AUTO ID': 'Noise' });
  const summary = plan(source, { [source.rows[1].id]: { status: 'corrected', label: '' } }, {}, { [source.rows[0].id]: { label: 'MYODAU' } });
  assert.equal(summary.completed, 0);
  assert.equal(summary.remaining, 2);
  assert.equal(summary.total, 2);
});

test('changing the per-species quota changes the workload without changing the classifier queue', () => {
  const source = data();
  const initial = A.classify(source, {});
  const group = initial.groups[0];
  const larger = A.classify(source, {}, {}, {}, { [group.key]: { sampleTarget: 17 } });
  assert.equal(initial.metrics.required, 1);
  assert.equal(larger.metrics.required, 1);
  assert.equal(Plan.summarize(initial).remaining, 10);
  assert.equal(Plan.summarize(larger).remaining, 17);
  assert.equal(larger.metrics.required, 1, 'Summarizing must not alter the classifier result.');
});
