const test = require('node:test');
const assert = require('node:assert/strict');
const Names = require('../species.js');

test('the requested scientific and French names are resolved from Kaleidoscope codes', () => {
  assert.equal(Names.resolve('EPTSER').scientificName, 'Eptesicus serotinus');
  assert.equal(Names.resolve('EPTSER').frenchName, 'Sérotine commune');
  assert.equal(Names.resolve('MYODAS').scientificName, 'Myotis dasycneme');
  assert.equal(Names.resolve('MYODAS').frenchName, 'Murin des marais');
  assert.equal(Names.SPECIES.length, 31);
  assert.equal(new Set(Names.SPECIES.map(item => item.code)).size, 31);
  for (const item of Names.SPECIES) {
    assert.match(item.scientificName, /^[A-Z][a-z]+ [a-z]+$/);
    assert.equal(Names.resolve(item.scientificName).key, item.code);
    assert.equal(Names.resolve(item.frenchName).key, item.code);
    assert.equal(Names.resolve(item.code).isSpecies, true);
  }
});

test('the nine excluded species all have scientific and French display names', () => {
  const pairs = {
    BARBAR: ['Barbastella barbastellus', 'Barbastelle d’Europe'],
    RHIFER: ['Rhinolophus ferrumequinum', 'Grand rhinolophe'],
    RHIHIP: ['Rhinolophus hipposideros', 'Petit rhinolophe'],
    MYOBEC: ['Myotis bechsteinii', 'Murin de Bechstein'],
    MYODAS: ['Myotis dasycneme', 'Murin des marais'],
    MYOMYO: ['Myotis myotis', 'Grand murin'],
    MYOEMA: ['Myotis emarginatus', 'Murin à oreilles échancrées'],
    NYCNOC: ['Nyctalus noctula', 'Noctule commune'],
    NYCLEI: ['Nyctalus leisleri', 'Noctule de Leisler']
  };
  for (const [code, expected] of Object.entries(pairs)) {
    const actual = Names.resolve(code);
    assert.deepEqual([actual.scientificName, actual.frenchName], expected);
  }
});

test('French accents, apostrophes, case and accepted scientific synonyms merge safely', () => {
  for (const alias of [' eptser ', 'eptesicus SEROTINUS', 'SEROTINE COMMUNE', 'Cnephaeus serotinus', 'Eptesicus serotinus (Schreber, 1774)']) assert.equal(Names.resolve(alias).key, 'EPTSER');
  for (const alias of ["Murin d'Alcathoe", 'murin d’alcathoé', 'MYOALC']) assert.equal(Names.resolve(alias).key, 'MYOALC');
  assert.equal(Names.resolve('Myotis bechsteini').key, 'MYOBEC');
  assert.equal(Names.resolve('Myotis daubentoni').key, 'MYODAU');
  assert.equal(Names.resolve('Vespertilion bicolore').key, 'VESMUR');
});

test('groups, complexes and unknown labels never become an invented certain species', () => {
  const group = Names.resolve('Myotis sp');
  assert.equal(group.scientificName, 'Myotis sp.');
  assert.equal(group.frenchName, 'Murin indéterminé');
  assert.equal(group.isSpecies, false);
  assert.equal(group.category, 'group');
  for (const label of ['EPTSER/PIPPIP', 'Myotis myotis / Myotis blythii', 'Myotis cf. myotis', 'Myotis myotis ?', 'Espèce A', '<script>label</script>']) {
    const actual = Names.resolve(label);
    assert.equal(actual.scientificName, label);
    assert.equal(actual.frenchName, 'Nom non renseigné');
    assert.equal(actual.isSpecies, false);
    assert.equal(actual.known, false);
  }
});

test('activity totals merge code, Latin and French aliases and count summary totals once', () => {
  const rows = Names.activityRows([
    { category: 'taxon', label: 'EPTSER', total: 10, manual: 2, inferred: 8 },
    { category: 'taxon', label: 'Eptesicus serotinus', total: 5, manual: 1, inferred: 4 },
    { category: 'taxon', label: 'Sérotine commune', total: 3, manual: 3, inferred: 0 },
    { category: 'taxon', label: 'Cnephaeus serotinus', total: 2 },
    { category: 'taxon', label: 'MYODAS', total: 7 }
  ]);
  assert.deepEqual(rows.map(row => [row.scientificName, row.frenchName, row.contacts]), [
    ['Eptesicus serotinus', 'Sérotine commune', 20],
    ['Myotis dasycneme', 'Murin des marais', 7]
  ]);
  assert.equal(rows.reduce((total, row) => total + row.contacts, 0), 27);
});

test('activity report excludes pending, noise and unresolved categories, preserving groups and unknown taxa', () => {
  const rows = Names.activityRows([
    { category: 'noise', label: 'Noise', total: 10 },
    { category: 'pending', label: 'Pending classification', total: 5 },
    { category: 'uncertain', label: 'Uncertain / unresolved', total: 3 },
    { category: 'unresolved', label: 'NoID', total: 2 },
    { category: 'taxon', label: 'Bruit', total: 1 },
    { category: 'taxon', label: 'No ID', total: 1 },
    { category: 'taxon', label: 'Myotis sp.', total: 4 },
    { category: 'taxon', label: 'Myotis sp', total: 2 },
    { category: 'taxon', label: 'Complexe local A / B', total: 7 },
    { category: 'taxon', label: 'NYCNOC', total: 0 }
  ]);
  assert.equal(rows.length, 2);
  assert.equal(rows.find(row => row.category === 'group').contacts, 6);
  const unknown = rows.find(row => row.category === 'unknown');
  assert.equal(unknown.scientificName, 'Complexe local A / B');
  assert.equal(unknown.frenchName, 'Nom non renseigné');
  assert.equal(unknown.contacts, 7);
  assert.equal(unknown.known, false);
});

test('activity report rejects invalid counts rather than concatenating or inventing contacts', () => {
  assert.deepEqual(Names.activityRows([]), []);
  assert.throws(() => Names.activityRows(null), /tableau/);
  for (const total of ['5', -1, NaN, 2.5]) assert.throws(() => Names.activityRows([{ category: 'taxon', label: 'EPTSER', total }]), /entier/);
});

test('chart filter defaults to the complete activity table and always returns a new array', () => {
  const rows = Object.freeze(Names.activityRows([
    { category: 'taxon', label: 'PIPPIP', total: 150 },
    { category: 'taxon', label: 'PIPNAT', total: 7 }
  ]).map(Object.freeze));
  for (const include of [undefined, true]) {
    const result = Names.chartRows(rows, include);
    assert.notEqual(result.rows, rows);
    assert.deepEqual(result.rows, rows);
    assert.equal(result.omittedContacts, 0);
    assert.ok(result.rows.every((row, index) => row === rows[index]));
  }
  const filtered = Names.chartRows(rows, false);
  assert.deepEqual(filtered.rows.map(row => row.key), ['PIPNAT']);
  assert.equal(filtered.omittedContacts, 150);
  assert.equal(rows.length, 2);
  assert.equal(rows.find(row => row.key === 'PIPPIP').contacts, 150);
});

test('common pipistrelle code, Latin and French aliases are merged before filtering', () => {
  const rows = Names.activityRows([
    { category: 'taxon', label: 'pippip', total: 50 },
    { category: 'taxon', label: 'Pipistrellus pipistrellus', total: 30 },
    { category: 'taxon', label: 'PIPISTRELLE COMMUNE', total: 20 },
    { category: 'taxon', label: 'Pipistrellus pipistrellus (Schreber, 1774)', total: 5 },
    { category: 'taxon', label: 'PIPPYG', total: 4 }
  ]);
  const result = Names.chartRows(rows, false);
  assert.equal(result.omittedContacts, 105);
  assert.deepEqual(result.rows.map(row => [row.key, row.contacts]), [['PIPPYG', 4]]);
  assert.equal(rows.find(row => row.key === 'PIPPIP').contacts, 105);
});

test('chart filter recognizes exact primary identities but preserves other pipistrelles and ambiguous labels', () => {
  const omitted = [
    { key: 'pippip', contacts: 1 },
    { scientificName: ' Pipistrellus pipistrellus ', contacts: 2 },
    { frenchName: 'PIPISTRELLE COMMUNE', contacts: 3 }
  ];
  const preserved = [
    'PIPNAT', 'PIPPYG', 'Pipistrellus sp.', 'PIPPIP/PIPNAT',
    'Pipistrellus cf. pipistrellus', 'Pipistrellus pipistrellus ?',
    'NoID PIPPIP', 'Pipistrelle commune à vérifier'
  ].map(scientificName => ({ scientificName, contacts: 1 }));
  preserved.push({ scientificName: 'PIPPIP/PIPPYG', frenchName: 'Pipistrelle commune', contacts: 1 });
  preserved.push({ key: 'group:Pipistrellus sp.', scientificName: 'Pipistrelle commune', contacts: 1 });
  const rows = [...omitted, ...preserved], snapshot = structuredClone(rows);
  const result = Names.chartRows(rows, false);
  assert.equal(result.omittedContacts, 6);
  assert.deepEqual(result.rows, preserved);
  assert.deepEqual(rows, snapshot);
});

test('absent common pipistrelle, zero counts and only common pipistrelle are handled without invented rows', () => {
  assert.deepEqual(Names.chartRows([], false), { rows: [], omittedContacts: 0 });
  const other = [{ scientificName: 'Myotis myotis', contacts: 3 }];
  assert.deepEqual(Names.chartRows(other, false), { rows: other, omittedContacts: 0 });
  assert.notEqual(Names.chartRows(other, false).rows, other);
  assert.deepEqual(Names.chartRows([{ key: 'PIPPIP', contacts: 0 }], false), { rows: [], omittedContacts: 0 });
  assert.deepEqual(Names.chartRows([{ key: 'PIPPIP', contacts: 5 }], false), { rows: [], omittedContacts: 5 });
});

test('chart filter rejects invalid activity rows and counts in either visibility mode', () => {
  assert.throws(() => Names.chartRows(null), /tableau/);
  for (const include of [true, false]) {
    assert.throws(() => Names.chartRows([null], include), /ligne/);
    for (const contacts of [-1, NaN, Infinity, '5', 1.5, Number.MAX_SAFE_INTEGER + 1]) {
      assert.throws(() => Names.chartRows([{ key: 'PIPPIP', contacts }], include), /entier/);
    }
  }
});
